# حزمة Paperclip AI-OS لـ Claude Code — التثبيت والتحقق

هذه الحزمة v2.4.4 تجهّز Claude Code للعمل على مشروع Paperclip وفق قواعد مشروعك: شركة AI بالكامل، موافقة المالك قبل الإطلاق، مرحلة تحليل للقراءة فقط، وحماية قدر الإمكان من التغييرات غير المصرّح بها.

**الحزمة لا تعدّل Paperclip Backend أو قاعدة البيانات أو Git baseline أو Docker أو الوكيل `ayoub` أو إعدادات Gemini.** أداة التثبيت تضيف ملفات محلية فقط داخل المستودع وتدمج Hook في إعدادات Claude Code المحلية.

## 1. قبل التثبيت

- لا تفك الحزمة مباشرة فوق ملفات المشروع قبل مراجعتها. استخرجها أولًا في مجلد مؤقت خارج المستودع، مثل `C:\AI\pc-claude-kit-v2.4.4`.
- تأكد أن Node.js وGit وClaude Code متاحة في PowerShell.
- يتطلب `onFailure: "block"` إصدار Claude Code 2.1.295+، كما تتطلب حدود القراءة/الكتابة الأصلية إصدار **2.1.314 أو أحدث**؛ لذلك يتحقق المثبت من 2.1.314 كحد أدنى. أداة التثبيت تتحقق من الإصدار وتتوقف إذا كان أقدم.
- الحارس طبقة سياسة، وليس Sandbox أو جدار حماية على مستوى نظام التشغيل. اترك تأكيدات صلاحيات Claude Code مفعّلة.
- لا تستخدم النسخة الحية من Paperclip لاختبار سلوك دورة حياة الموظفين. لا تشغّل أو توقف أو تستأنف أو تغيّر الوكيل `ayoub` أو شركته.
- لا تغيّر أي إعدادات تخص Gemini.

## 2. خطوات التثبيت على Windows

قبل الاستخراج، تحقق من بصمة ملف ZIP باستخدام ملف `.sha256` المرفق. المثبت يتحقق أيضًا من `PACKAGE-MANIFEST.sha256` داخليًا، لكنه ليس توقيعًا رقميًا للناشر؛ بصمة ZIP هي التي تتحقق من أن الحزمة المستلمة مطابقة للملف المنشور.

افتح PowerShell جديدًا ونفّذ:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
Set-Location C:\AI\pc-claude-kit-v2.4.4
.\INSTALL.ps1 -RepoPath 'C:\AI\Paperclip-LF' -ValidateOnly
```

ابدأ بوضع `-ValidateOnly` فقط. راجع الرسائل ولا تنفذ التثبيت الفعلي إذا ظهر تعارض أو تحذير. بعد نجاح الفحص ومراجعة النتيجة، يكون أمر التثبيت:

```powershell
.\INSTALL.ps1 -RepoPath 'C:\AI\Paperclip-LF'
```

إذا كانت ملفات kit سابقة (مثل v2.1) مثبتة بالفعل، شغّل الفحص مع `-UpdateExistingKitFiles` أيضًا، ثم استخدم الخيار نفسه في التثبيت بعد مراجعة النتيجة:

```powershell
.\INSTALL.ps1 -RepoPath 'C:\AI\Paperclip-LF' -UpdateExistingKitFiles -ValidateOnly
# بعد نجاح الفحص والمراجعة:
.\INSTALL.ps1 -RepoPath 'C:\AI\Paperclip-LF' -UpdateExistingKitFiles
```

**استثناء مقصود:** لا يستبدل المثبت `CLAUDE.local.md` مختلفًا حتى مع خيار التحديث؛ ادمج تعليماته يدويًا بعد حفظ نسخة منه. لا تستخدم `-UpdateExistingKitFiles` للتجاوز الأعمى لأي تعارض.

ملاحظة عن فحص Git: يفحص المثبت حالة تتبّع ملفات الوجهة باستخدام `git ls-files --cached`؛ الملفات المحلية غير المتتبعة مثل `CLAUDE.local.md` تعطي نتيجة فارغة طبيعية ولا يجب أن تنتج خطأ `pathspec`. إذا تعذر على Git قراءة الفهرس أو أعاد رمز خروج غير صفري، يتوقف المثبت قبل أي كتابة.

المثبت سيقوم بالآتي:

1. يتأكد من وجود `package.json` ومجلد `.git` عادي في جذر Paperclip، ويتحقق من SHA-256 لكل ملفات الحزمة المدرجة في `PACKAGE-MANIFEST.sha256` ويرفض الملفات الإضافية غير المدرجة والـ Reparse Points داخل مجلد الاستخراج.
2. يتحقق من وجود Node.js 20+ وGit for Windows وWindows PowerShell وClaude Code 2.1.314+، ثم ينشئ `pc-guard-launch.ps1` بمسار `node.exe` المطلق ويجعل Hook يستدعي PowerShell التنفيذي بمساره المطلق. مهلة Hook هي 15 ثانية لإتاحة وقت بدء PowerShell وNode على Windows.
3. يرفض استبدال ملف `CLAUDE.local.md` شخصي موجود مسبقًا.
4. يرفض تعارض الملفات افتراضيًا، ولا يحدّث ملفات الحزمة الموجودة إلا بخيار صريح.
5. يدمج Hook الحزمة في `.claude/settings.local.json` الموجود دون حذف إعدادات أو Hooks أخرى.
6. يضبط `permissions.defaultMode` على `plan`، ويفعّل `blockReadsOutsideWorkingDirectories` و`blockWritesOutsideWorkingDirectories` للحماية الأصلية من القراءة/الكتابة خارج مجلدات العمل.
7. يضيف قواعد الاستثناء إلى `.git/info/exclude` بدلًا من تعديل `.gitignore` المتتبّع.
8. ينسخ الملفات باستخدام ملفات مؤقتة في نفس المجلد، ويحتفظ بنسخ احتياطية، ويحاول التراجع تلقائيًا إذا فشل التثبيت أو اختبار الحارس بعد النسخ.

إذا كان لديك إصدار سابق من ملفات الحزمة، راجعه أولًا. لا تستخدم خيار التحديث إلا بعد التأكد من أن الملفات الموجودة هي نسخة قديمة من هذا الـ kit، ثم نفّذ:

```powershell
.\INSTALL.ps1 -RepoPath 'C:\AI\Paperclip-LF' -UpdateExistingKitFiles
```

سيُنشئ المثبت نسخًا احتياطية قبل الاستبدال. لكنه لن يستبدل `CLAUDE.local.md` الشخصي المختلف؛ ادمج تعليماتك يدويًا عند الحاجة.

### ملاحظات مهمة للمثبت

- استخدم مسارًا محليًا مطلقًا مثل `C:\AI\Paperclip-LF`؛ المسارات النسبية وUNC غير مدعومة.
- يستخدم المثبت `node.exe` و`git.exe` و`powershell.exe` كملفات تنفيذية حقيقية، وليس Alias أو Function. يسجل مسار PowerShell المطلق في Hook، وينشئ المشغّل بمسار Node المطلق. المشغّل يزيل `NODE_OPTIONS` و`NODE_PATH` و`NODE_V8_COVERAGE` و`NODE_EXTRA_CA_CERTS` قبل تشغيل الحارس، ويمرر بايتات JSON الواردة من Hook كما هي دون إعادة ترميزها، لتجنب تلف النصوص غير الإنجليزية.
- إذا تغير مكان Node.js بعد التثبيت (مثل تغيير إصدار nvm أو إعادة تثبيت Node)، أعد تشغيل `-ValidateOnly` ثم المثبت لتحديث مسار المشغّل.
- يرفض المثبت متغيرات Git/SSH/Pager وNode التي قد تغيّر مسار الإعداد أو تحمّل كودًا قبل الحارس. يعرض أسماء المتغيرات فقط دون قيمها. افتح جلسة PowerShell نظيفة بدل مشاركة قيم هذه المتغيرات.
- فحص `-ValidateOnly` يجب أن يسبق كل تثبيت أو تحديث. لا تشغّل التثبيت على نسخة Paperclip الحية قبل نجاح الفحص ومراجعة مسارات الملفات التي سيضيفها.

## 3. الوضع الافتراضي: Phase 1 قراءة فقط

الحارس يعتبر الوضع `analysis` إذا لم يتم تعريف `PC_GUARD_PHASE`، ويمنع كل أدوات تعديل الملفات حتى داخل `ui/`.

بعد التثبيت، افتح PowerShell جديدًا وشغّل Claude Code من جذر المستودع. إذا فشل تشغيل المشغّل أو الحارس لأي سبب، يجب أن يفشل Hook مغلقًا ويمنع الأداة؛ لا تتجاوز الخطأ ولا تتابع التحليل:

```powershell
Set-Location C:\AI\Paperclip-LF
$env:PC_GUARD_PHASE = 'analysis'
Remove-Item Env:PC_GUARD_ALLOW -ErrorAction SilentlyContinue
claude
```

لا تغيّر وضع التحليل إلى التطوير بنفسك قبل مراجعة تقرير Phase 1 وموافقة المالك على خطوة محددة.

## 4. تأكد أن Claude Code حمّل الحماية

داخل Claude Code نفّذ الأوامر التالية كلٌّ على حدة:

- `/status` — تحقق من الإعدادات المحلية للمشروع.
- `/hooks` — تحقق من تسجيل `PreToolUse` hook الخاص بالحارس.
- `/memory` — افتح قائمة ملفات التعليمات والذاكرة المحمّلة، وتحقق من ظهور `CLAUDE.local.md`.

يحمّل Claude Code ملفي `CLAUDE.md` و`CLAUDE.local.md` من مجلد العمل والمجلدات الأعلى منه، ويضيف الملف المحلي بعد ملف المشروع في نفس المستوى. استخدم `/memory` للتحقق الفعلي داخل الجلسة؛ لا تعتمد على الافتراض وحده.

اطلب من Claude قراءة ملف `package.json` في جذر المستودع. يجب السماح بالقراءة.

## 5. اختبارات الحارس

### اختبار ذاتي

من جذر المستودع:

```powershell
node .claude\hooks\pc-guard.mjs --selftest
```

شغّل الاختبار من PowerShell لا يحتوي على متغيرات `NODE_OPTIONS` أو `NODE_PATH`؛ المشغّل الذي يولده المثبت يزيلها تلقائيًا عند استدعاء Hook.

النتيجة المتوقعة في هذه النسخة v2.4.4:

```text
ALL 231 PASSED
```

تشمل اختبارات الانحدار الجديدة منع `rg -L` و`rg --follow` (اتباع الروابط الرمزية)، ومنع `git diff` غير المقيد الذي قد يعرض محتوى ملفات أسرار متتبعة، والسماح فقط بملخصات Git أو Diff لملف مصدر محدد داخل `ui/`.

هذا الاختبار يتحقق من منطق الحارس للحالات المدرجة فقط؛ لا يثبت استحالة تجاوزه. كما يمنع قراءة lockfiles الكبيرة وملفات minified وsource maps حتى عند استخدام أسماء ملفات قصيرة في أوامر `cat` أو `Get-Content`.

### اختبار تكامل Hook على Windows

بعد التأكد أن `/hooks` يعرض الحارس وأن `onFailure: "block"` متاح في إصدار Claude Code عندك، اطلب محاولة كتابة ملف تجريبي خارج المستودع، مثل:

```text
%TEMP%\pc-guard-outside-test.txt
```

يجب أن يرفض الحارس عملية الكتابة برسالة `PC-GUARD`. إذا ظهر الملف أو لم يعمل Hook أو كان فشل تشغيل Node لا يمنع الأداة، أوقف الجلسة فورًا ولا تبدأ تحليل المستودع. احذف ملف الاختبار من PowerShell يدويًا بعد التأكد من أنه ملف الاختبار فقط.

**لا تختبر الحارس بكتابة `server/test.txt` أو تعديل أي ملف داخل Paperclip أثناء Phase 1.**

## 6. ما الذي تسمح به الأوضاع؟

| الوضع | المسموح | الممنوع |
|---|---|---|
| `analysis` (الافتراضي) | قراءة محددة داخل المستودع، `git status/log/rev-parse`، عرض الفروع والـ tags والـ remotes، `git ls-remote` على Remote معروف، وGET محدود إلى Ollama إذا عُرف عنوانه صراحة | جميع التعديلات، تشغيل التطبيق أو الاختبارات أو الوكلاء، التثبيت، migrations، Docker lifecycle، عمليات API المغيّرة، الأدوات غير المعتمدة وMCP |
| `development` | تعديلات الملفات تحت `ui/` فقط، وبعض أوامر اختبار UI المحددة | Backend/API/Schema/Migrations/Adapters، الأسرار، Gemini، الوكيل `ayoub`، تثبيت الحزم دون إذن منفصل، عمليات Git الخطرة، أدوات غير معتمدة |

بعد موافقة المالك على تقرير Phase 1 وعلى خطوة UI محددة، افتح جلسة PowerShell جديدة:

```powershell
Set-Location C:\AI\Paperclip-LF
$env:PC_GUARD_PHASE = 'development'
Remove-Item Env:PC_GUARD_ALLOW -ErrorAction SilentlyContinue
claude
```

لا تغيّر الوضع لمجرد الانتقال من مرحلة التحليل إلى التنفيذ. يجب أن تكون الموافقة على نطاق محدد.

## 7. الاستثناءات التي لا يستخدمها إلا المالك

هذه المتغيرات ليست جزءًا من التشغيل المعتاد. لا تضبط أيًا منها إلا بعد موافقة صريحة على الإجراء المحدد، وفي جلسة جديدة:

- `PC_GUARD_ALLOW=tooling` — تعديل Skills وAgents وتعليمات الحزمة المحلية. لا يسمح بتغيير Hook أو إعدادات الأمان.
- `PC_GUARD_ALLOW=backend` — تعديل Backend لمسار وافق المالك عليه تحديدًا.
- `PC_GUARD_ALLOW=deps` — تعديل ملفات manifests/lockfiles وتثبيت أو تغيير dependencies بعد موافقة محددة.
- `PC_GUARD_ALLOW=commit` — السماح بـ Git commit بعد الموافقة. أوامر `fetch/pull/merge/rebase/push` تظل ممنوعة من الحارس ويجريها المالك بنفسه.

مثال توضيحي فقط بعد موافقة محددة على Backend:

```powershell
$env:PC_GUARD_PHASE = 'development'
$env:PC_GUARD_ALLOW = 'backend'
claude
```

لا تجمع استثناءات متعددة إلا إذا كانت كل عملية قد حصلت على موافقة مستقلة. أغلق الجلسة واحذف متغيرات البيئة بعد الانتهاء.

## 8. Ollama — لا تخمّن العنوان أو مكان التشغيل

لا تضبط `PC_OLLAMA_URL` ما دام مكان Ollama أو عنوانه `UNKNOWN`.

إذا قدّم المالك عنوانًا مؤكدًا، يمكن للحارس في Phase 1 السماح فقط بـ GET إلى `/api/tags` أو `/api/version` على نفس الـ origin المحدد. لا يسمح هذا بتشغيل inference أو تنزيل/حذف نماذج.

معلومة عامة يجب مراعاتها عند التخطيط: Ollama يستمع عادةً على `127.0.0.1:11434`، ويمكن تغيير عنوان الربط باستخدام `OLLAMA_HOST`. خادم Ollama القياسي لا يوفر مصادقة API مدمجة؛ لذلك لا تعرضه لشبكة غير موثوقة. عند استخدام Docker، `localhost` داخل الحاوية هو الحاوية نفسها، وليس Windows host. راجع `pc-provider-setup` لتفاصيل السيناريوهات دون تغيير إعدادات جهازك.

## 9. ملفات Git المحلية

- يضيف المثبت الاستثناءات إلى `.git/info/exclude`، ولا يغير `.gitignore`.
- لا يضيف Remote، ولا يغيّر Branch أو Tag، ولا ينفّذ `fetch` أو `pull`، ولا يلمس `pc-ai-os-base`.
- إذا كانت إحدى ملفات الحزمة الهدف متتبعة بالفعل بواسطة Git، يتوقف المثبت ويطلب مراجعتها بدلًا من استبدالها.
- الحزمة لا تنفذ أي تعديل على مستودع Paperclip قبل تشغيل المثبت. راجع الملفات التي سيضيفها المثبت إذا كان لديك أي شك.

### توافق إعدادات Git for Windows وGit LFS

إذا كان Git for Windows يحتوي على هذه القيم القياسية، فلن تحتاج إلى حذفها أو تعطيلها:

- `[diff "astextplain"] textconv = astextplain`
- `[filter "lfs"] clean = git-lfs clean -- %f`
- `[filter "lfs"] smudge = git-lfs smudge -- %f`
- `[filter "lfs"] process = git-lfs filter-process`

المثبت يسمح بهذه القيم فقط كما هي، ويشغّل اختبار سياسة محليًا أثناء `-ValidateOnly`. كما أن `credential.helper = manager` إعداد اعتماد طبيعي؛ فحص الملفات المحلي يستخدم `git ls-files` ولا يستدعي credential helper، وتظل عمليات Git الشبكية محظورة أثناء التحليل. يظل يرفض أي `textconv` أو filter command مخصص أو مختلف، وكذلك `include` و`fsmonitor` وpager وأي إعداد تنفيذ غير معتمد. لا تحذف إعدادات Git LFS ولا تغيّر `gitconfig` يدويًا لتجاوز الفحص.

في Claude Code، تظل أوامر Git للشبكة محظورة أثناء التحليل. أوامر `git diff` التي تعرض محتوى تحتاج `--no-textconv` مع مسارات UI صريحة، بينما ملخصات `--stat` و`--name-only` لا تعرض محتوى الملفات.

## 10. المحتويات

- `CLAUDE.local.md` — تعليمات العمل الخاصة بالمالك، بالعربية في الردود.
- `.claude/skills/pc-*/` — ثماني مهارات متخصصة للتحليل ودورة الشركة والتكاملات والنماذج والواجهة والبوابات والدمج.
- `.claude/agents/pc-explorer.md` — مستكشف للقراءة فقط.
- `.claude/hooks/pc-guard.mjs` — حارس نطاق ومراحل وعمليات.
- `.claude/settings.local.json.NEW` — مصدر دمج إعدادات Hook المحلية.
- `INSTALL.ps1` — مثبت Windows يحافظ على الإعدادات القائمة قدر الإمكان.
- `PHASE1-PROMPT.md` — البرومبت الكامل لفحص Paperclip دون تعديل.
- `SECURITY-NOTES.md` — حدود الحماية ونموذج التهديد.

## 10-A. فحص صياغة مثبت Windows ثم التحقق منه

**لا تشغّل `INSTALL.ps1` مباشرة.** أولًا اطلب من PowerShell نفسه تحليل الملف دون تنفيذه. نفّذ هذه الأوامر من مجلد الحزمة المستخرجة:

```powershell
$tokens = $null
$parseErrors = $null
$installerPath = (Resolve-Path -LiteralPath .\INSTALL.ps1).Path
[void][System.Management.Automation.Language.Parser]::ParseFile($installerPath, [ref]$tokens, [ref]$parseErrors)
if ($parseErrors.Count -gt 0) {
    $parseErrors | Format-List Message, Extent
    throw 'PowerShell syntax check failed. Do not run INSTALL.ps1.'
}
Write-Host 'INSTALL.ps1 PowerShell syntax: PASS' -ForegroundColor Green
```

إذا ظهرت `INSTALL.ps1 PowerShell syntax: PASS` فقط، انتقل إلى وضع الفحص دون تثبيت:

```powershell
.\INSTALL.ps1 -RepoPath 'C:\AI\Paperclip-LF' -ValidateOnly
```

هذا يفحص المتطلبات والنسخ، الملفات، المسارات والروابط/Junctions، البيئة، الملفات المتتبعة، صحة JSON ودمج Hook، ويشغّل الاختبار الذاتي دون كتابة ملفات داخل المستودع. لا تنفّذ التثبيت الفعلي إلا إذا ظهرت `VALIDATION PASSED`.

المثبت يرفض مسارات UNC والمسارات النسبية ومجلدات `.git` من نوع worktree file وروابط reparse/junction على مسارات المصدر والوجهة. كما يرفض متغيرات بيئة Git/SSH/Pager التي قد تغيّر سلوك أوامر الفحص، ويفحص إعدادات Git المحلية والعامة (بما فيها `HOME` و`XDG_CONFIG_HOME` وProgram Files (x86)) بحثًا عن include أو fsmonitor أو pager أو أوامر تنفيذ خارجية، دون طباعة محتوى ملفات الإعداد أو قيم المتغيرات. إعدادات credential helper وURL rewrite تمنع `git ls-remote` عبر الحارس، لكنها لا تمنع التثبيت المحلي وحدها. كما يفحص أيضًا إعدادات Git المحلية والعامة التي قد تنفذ أوامر جانبية أثناء الفحص. إعدادات credential helper أو URL rewrite تمنع عمليات الفحص الشبكي `git ls-remote` داخل الحارس، لكنها لا تمنع فحص الملفات المحلي ما لم تتضمن إعداد تنفيذ جانبي. كما ينسخ الملفات عبر ملفات مؤقتة في نفس المجلد ويحتفظ بنسخة احتياطية من كل ملف يتم استبداله، ويحاول Rollback عند فشل التثبيت أو الاختبار اللاحق. **هذه السلوكيات لم تُختبر على Windows في بيئة إعداد الحزمة؛ الاختبار الفعلي على جهازك إلزامي.**

## 11. حدود الحماية — اقرأها قبل الاستخدام

هذه الحزمة تقلل الأخطاء والتغييرات العرضية، لكنها ليست حاجزًا أمنيًا كاملًا على مستوى النظام. الحارس لا يستطيع ضمان منع كل عملية من سكربت معقد أو برنامج خارجي أو Terminal يدوي أو صلاحية Windows أخرى. لا تقدم جلسة التحليل Tokens حقيقية، ولا توصل إليها أدوات MCP قادرة على التغيير، واستخدم نسخة تجريبية معزولة عند السماح بالتشغيل في مراحل لاحقة.

إذا رفض الحارس أداة لازمة، لا تحاول الالتفاف عليه. سجّل اسم الأداة، وشكل الإدخال بعد حذف الأسرار، ثم راجع السياسة قبل الاستمرار.
