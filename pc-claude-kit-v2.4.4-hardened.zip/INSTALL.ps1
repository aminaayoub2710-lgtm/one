﻿#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$RepoPath = 'C:\AI\Paperclip-LF',
    [switch]$UpdateExistingKitFiles,
    [switch]$ValidateOnly
)

$ErrorActionPreference = 'Stop'
$script:ChangeLog = New-Object System.Collections.ArrayList
$script:CreatedDirs = New-Object System.Collections.ArrayList
$script:BackupRoot = $null
$script:RepoRoot = $null
$script:NodeCommand = $null
$script:GitCommand = $null
$script:ClaudeCommand = $null
$script:PowerShellCommand = $null

function Stop-WithMessage([string]$Message) {
    throw "INSTALL STOPPED: $Message"
}

function Has-Property($Object, [string]$Name) {
    return ($null -ne $Object -and $null -ne $Object.PSObject.Properties[$Name])
}

function Ensure-Property($Object, [string]$Name, $Value) {
    if (-not (Has-Property $Object $Name)) {
        $Object | Add-Member -MemberType NoteProperty -Name $Name -Value $Value
    } elseif ($null -eq $Object.$Name) {
        $Object.$Name = $Value
    }
}

function Assert-NoReparsePoints([string]$Path) {
    $full = [System.IO.Path]::GetFullPath($Path)
    $volumeRoot = [System.IO.Path]::GetPathRoot($full)
    if ([string]::IsNullOrWhiteSpace($volumeRoot)) {
        Stop-WithMessage "Could not determine the volume root for path: $Path"
    }
    $candidates = New-Object System.Collections.Generic.List[string]
    [void]$candidates.Add($volumeRoot)
    $tail = $full.Substring($volumeRoot.Length)
    $current = $volumeRoot
    foreach ($segment in ($tail -split '[\\/]+' | Where-Object { $_ -ne '' })) {
        $current = Join-Path $current $segment
        [void]$candidates.Add($current)
    }
    foreach ($candidate in $candidates) {
        $item = Get-Item -LiteralPath $candidate -Force -ErrorAction SilentlyContinue
        if ($null -ne $item -and (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0)) {
            Stop-WithMessage "Reparse point / symlink / junction detected in path: $candidate. Refusing installation to avoid writing outside the intended directory."
        }
    }
}

function Assert-PackageManifest([string]$SourceRoot) {
    $manifestPath = Join-Path $SourceRoot 'PACKAGE-MANIFEST.sha256'
    if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
        Stop-WithMessage 'PACKAGE-MANIFEST.sha256 is missing; package integrity cannot be checked.'
    }
    Assert-NoReparsePoints $manifestPath

    $hashes = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::OrdinalIgnoreCase)
    $lines = [System.IO.File]::ReadAllLines($manifestPath, [System.Text.Encoding]::UTF8)
    foreach ($line in $lines) {
        if ([string]::IsNullOrWhiteSpace($line)) { continue }
        if ($line -notmatch '^([0-9a-fA-F]{64})\s+\*?(.+?)\s*$') {
            Stop-WithMessage 'PACKAGE-MANIFEST.sha256 contains an invalid line.'
        }
        $expectedHash = $Matches[1].ToUpperInvariant()
        $rawRelative = $Matches[2].Trim()
        if ([string]::IsNullOrWhiteSpace($rawRelative) -or [System.IO.Path]::IsPathRooted($rawRelative) -or ($rawRelative -match '(^|[\\/])\.\.(?:[\\/]|$)') -or ($rawRelative -match '[:*?"<>|]')) {

            Stop-WithMessage 'PACKAGE-MANIFEST.sha256 contains an unsafe relative path.'
        }
        $relative = $rawRelative.Replace('\', '/')
        if ($relative -ieq 'PACKAGE-MANIFEST.sha256') {
            Stop-WithMessage 'The manifest must not hash itself.'
        }
        if ($hashes.ContainsKey($relative)) {
            Stop-WithMessage "PACKAGE-MANIFEST.sha256 contains a duplicate path: $relative"
        }
        $candidate = [System.IO.Path]::GetFullPath((Join-Path $SourceRoot ($relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))))
        $prefix = $SourceRoot.TrimEnd([char[]]@('\', '/')) + [System.IO.Path]::DirectorySeparatorChar
        if (-not $candidate.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            Stop-WithMessage "Manifest path escapes the package directory: $relative"
        }
        Assert-NoReparsePoints $candidate
        if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            Stop-WithMessage "Manifest file is missing or not a regular file: $relative"
        }
        $actualHash = (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualHash -ne $expectedHash) {
            Stop-WithMessage "Package file hash mismatch: $relative. Extract a fresh ZIP; do not continue."
        }
        $hashes.Add($relative, $expectedHash)
    }
    if ($hashes.Count -lt 10) { Stop-WithMessage 'Package manifest is unexpectedly small.' }

    # Reject unexpected/unmanifested files, and reject reparse points anywhere in
    # the extracted package (including files not listed in the manifest).
    $items = @(Get-ChildItem -LiteralPath $SourceRoot -Force -Recurse -ErrorAction Stop)
    foreach ($item in $items) {
        if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
            Stop-WithMessage "A reparse point exists inside the extracted package: $($item.FullName)"
        }
    }
    $actualFiles = @(Get-ChildItem -LiteralPath $SourceRoot -File -Force -Recurse -ErrorAction Stop |
        Where-Object { $_.FullName -ine $manifestPath })
    foreach ($file in $actualFiles) {
        $relative = $file.FullName.Substring($SourceRoot.Length).TrimStart('\', '/').Replace('\', '/')
        if (-not $hashes.ContainsKey($relative)) {
            Stop-WithMessage "Unmanifested file found in package: $relative"
        }
    }
    if ($actualFiles.Count -ne $hashes.Count) {
        Stop-WithMessage 'Package file count does not match PACKAGE-MANIFEST.sha256.'
    }
    Write-Host "Package manifest verified: $($hashes.Count) files; no unmanifested files or reparse points." -ForegroundColor Green
}

function Ensure-Directory([string]$Path) {
    if (Test-Path -LiteralPath $Path) {
        Assert-NoReparsePoints $Path
        $item = Get-Item -LiteralPath $Path -Force
        if (-not $item.PSIsContainer) { Stop-WithMessage "Expected a directory but found a file: $Path" }
        return
    }
    $parent = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $parent -PathType Container)) {
        Ensure-Directory $parent
    }
    Assert-NoReparsePoints $parent
    # Use the .NET API with a literal path; avoid PowerShell wildcard interpretation.
    [void][System.IO.Directory]::CreateDirectory([System.IO.Path]::GetFullPath($Path))
    [void]$script:CreatedDirs.Add($Path)
    Assert-NoReparsePoints $Path
}

function Test-GitTracked([string]$RelativePath) {
    # Do not use --error-unmatch here: an expected untracked destination (for
    # example CLAUDE.local.md) makes Git print a pathspec diagnostic to stderr.
    # Under $ErrorActionPreference = 'Stop', PowerShell can promote native stderr
    # to a terminating error before $LASTEXITCODE is inspected. `ls-files
    # --cached` is quiet for an untracked path and still returns a non-zero exit
    # code for genuine Git/index failures.
    $trackedEntries = @(& $script:GitCommand -C $script:RepoRoot ls-files --cached -- $RelativePath 2>$null)
    $code = $LASTEXITCODE
    if ($code -ne 0) {
        Stop-WithMessage "Git could not verify whether '$RelativePath' is tracked (exit $code). No installation changes have been made."
    }
    return ($trackedEntries.Count -gt 0 -and -not [string]::IsNullOrWhiteSpace([string]$trackedEntries[0]))
}

function Test-SameFile([string]$Source, [string]$Destination) {
    if (-not (Test-Path -LiteralPath $Destination -PathType Leaf)) { return $false }
    $sourceHash = (Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash
    $destinationHash = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256).Hash
    return $sourceHash -eq $destinationHash
}

function Get-BackupPath([string]$Destination) {
    $relative = $Destination.Substring($script:RepoRoot.Length).TrimStart('\', '/')
    return Join-Path $script:BackupRoot $relative
}

function Register-Original([string]$Destination) {
    $exists = Test-Path -LiteralPath $Destination -PathType Leaf
    $backup = $null
    if ($exists) {
        $backup = Get-BackupPath $Destination
        $backupParent = Split-Path -Parent $backup
        Ensure-Directory $backupParent
        Copy-Item -LiteralPath $Destination -Destination $backup -ErrorAction Stop
    }
    [void]$script:ChangeLog.Add([pscustomobject]@{
        Destination = $Destination
        Existed = $exists
        Backup = $backup
    })
}

function Replace-FileAtomically([string]$TemporaryFile, [string]$Destination) {
    if (Test-Path -LiteralPath $Destination -PathType Leaf) {
        [System.IO.File]::Replace($TemporaryFile, $Destination, $null)
    } else {
        [System.IO.File]::Move($TemporaryFile, $Destination)
    }
}

function Install-File([string]$Source, [string]$Destination) {
    $parent = Split-Path -Parent $Destination
    Ensure-Directory $parent
    Assert-NoReparsePoints $parent
    Assert-NoReparsePoints $Destination
    if (Test-SameFile $Source $Destination) { return }

    Register-Original $Destination
    $temporary = Join-Path $parent ('.pc-kit-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        Copy-Item -LiteralPath $Source -Destination $temporary -ErrorAction Stop
        Assert-NoReparsePoints $temporary
        Replace-FileAtomically $temporary $Destination
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
    }
}

function Write-TextAtomically([string]$Text, [string]$Destination) {
    $parent = Split-Path -Parent $Destination
    Ensure-Directory $parent
    Assert-NoReparsePoints $parent
    Assert-NoReparsePoints $Destination
    Register-Original $Destination
    $temporary = Join-Path $parent ('.pc-kit-' + [guid]::NewGuid().ToString('N') + '.tmp')
    try {
        [System.IO.File]::WriteAllText($temporary, $Text, [System.Text.UTF8Encoding]::new($false))
        Assert-NoReparsePoints $temporary
        Replace-FileAtomically $temporary $Destination
    } finally {
        if (Test-Path -LiteralPath $temporary) { Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue }
    }
}

function Restore-Transaction {
    for ($i = $script:ChangeLog.Count - 1; $i -ge 0; $i--) {
        $entry = $script:ChangeLog[$i]
        $temporary = $null
        try {
            $parent = Split-Path -Parent $entry.Destination
            Assert-NoReparsePoints $parent
            Assert-NoReparsePoints $entry.Destination
            if ($entry.Existed -and (Test-Path -LiteralPath $entry.Backup -PathType Leaf)) {
                Assert-NoReparsePoints $entry.Backup
                $temporary = Join-Path $parent ('.pc-kit-rollback-' + [guid]::NewGuid().ToString('N') + '.tmp')
                Copy-Item -LiteralPath $entry.Backup -Destination $temporary -ErrorAction Stop
                Assert-NoReparsePoints $temporary
                if (Test-Path -LiteralPath $entry.Destination -PathType Leaf) {
                    [System.IO.File]::Replace($temporary, $entry.Destination, $null)
                } else {
                    [System.IO.File]::Move($temporary, $entry.Destination)
                }
            } elseif (-not $entry.Existed -and (Test-Path -LiteralPath $entry.Destination -PathType Leaf)) {
                Remove-Item -LiteralPath $entry.Destination -Force -ErrorAction Stop
            }
        } catch {
            Write-Host "ROLLBACK WARNING: could not restore $($entry.Destination): $($_.Exception.Message)" -ForegroundColor Red
        } finally {
            if ($temporary -and (Test-Path -LiteralPath $temporary -PathType Leaf)) {
                Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
            }
        }
    }
    for ($i = $script:CreatedDirs.Count - 1; $i -ge 0; $i--) {
        $dir = $script:CreatedDirs[$i]
        try {
            if (Test-Path -LiteralPath $dir -PathType Container) {
                $children = @(Get-ChildItem -LiteralPath $dir -Force -ErrorAction SilentlyContinue)
                if ($children.Count -eq 0) { Remove-Item -LiteralPath $dir -Force -ErrorAction Stop }
            }
        } catch {
            Write-Host "ROLLBACK WARNING: could not remove new directory $($dir): $($_.Exception.Message)" -ForegroundColor Red
        }
    }
    $script:ChangeLog.Clear()
    $script:CreatedDirs.Clear()
}

function Is-KitGuardHook($Hook) {
    if ($null -eq $Hook) { return $false }
    $commandText = ([string]$Hook.command).Trim().Trim('"')
    $commandName = [System.IO.Path]::GetFileNameWithoutExtension($commandText)
    $argumentText = (@($Hook.args) -join ' ')
    $isNodeCommand = $commandName -ieq 'node'
    $isPowerShellCommand = $commandName -ieq 'powershell'
    $hasGuardArgument = ($argumentText -match '(?i)pc-guard(?:-launch)?\.(?:mjs|ps1)') -or ($commandText -match '(?i)pc-guard(?:-launch)?\.(?:mjs|ps1)')
    return (($isNodeCommand -or $isPowerShellCommand) -and $hasGuardArgument)
}

function Get-MergedSettings($ExistingSettings, $PackagedSettings) {
    if ($ExistingSettings -isnot [pscustomobject]) { Stop-WithMessage 'The root of settings.local.json must be a JSON object.' }
    if ((Has-Property $ExistingSettings 'permissions') -and $null -ne $ExistingSettings.permissions -and $ExistingSettings.permissions -isnot [pscustomobject]) {
        Stop-WithMessage 'The permissions setting must be a JSON object.'
    }
    if ((Has-Property $ExistingSettings 'hooks') -and $null -ne $ExistingSettings.hooks -and $ExistingSettings.hooks -isnot [pscustomobject]) {
        Stop-WithMessage 'The hooks setting must be a JSON object.'
    }

    Ensure-Property $ExistingSettings 'permissions' ([pscustomobject]@{})
    # Plan mode is intentional: the kit installs for a read-only analysis first.
    $ExistingSettings.permissions.defaultMode = 'plan'
    # Native Claude Code path boundaries supplement (but do not replace) the hook.
    $ExistingSettings.permissions.blockReadsOutsideWorkingDirectories = $true
    $ExistingSettings.permissions.blockWritesOutsideWorkingDirectories = $true
    Ensure-Property $ExistingSettings 'hooks' ([pscustomobject]@{})
    Ensure-Property $ExistingSettings.hooks 'PreToolUse' @()

    $current = $ExistingSettings.hooks.PreToolUse
    if ($null -eq $current) { $current = @() }
    if ($current -is [pscustomobject]) { $current = @($current) }
    if ($current -isnot [array]) { Stop-WithMessage 'hooks.PreToolUse must be a JSON array or a single hook matcher object.' }

    $merged = New-Object System.Collections.ArrayList
    foreach ($entry in $current) {
        if ($entry -isnot [pscustomobject]) { Stop-WithMessage 'Every hooks.PreToolUse entry must be a JSON object.' }
        if (-not (Has-Property $entry 'hooks')) {
            [void]$merged.Add($entry)
            continue
        }
        $inner = @($entry.hooks)
        if ($inner | Where-Object { $_ -isnot [pscustomobject] }) { Stop-WithMessage 'Every hook handler must be a JSON object.' }
        $kept = @($inner | Where-Object { -not (Is-KitGuardHook $_) })
        if ($kept.Count -gt 0) {
            $entry.hooks = $kept
            [void]$merged.Add($entry)
        }
    }

    $required = [pscustomobject]@{
        matcher = '*'
        hooks = @([pscustomobject]@{
            type = 'command'
            command = $script:PowerShellCommand
            args = @('-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', '${CLAUDE_PROJECT_DIR}/.claude/hooks/pc-guard-launch.ps1')
            timeout = 15
            onFailure = 'block'
        })
    }
    [void]$merged.Add($required)
    $ExistingSettings.hooks.PreToolUse = @($merged.ToArray())
    return $ExistingSettings
}

function Run-GuardSelfTest([string]$GuardPath, [string]$Label) {
    Write-Host "Running $Label guard self-test..." -ForegroundColor Cyan
    & $script:NodeCommand $GuardPath --selftest
    $code = $LASTEXITCODE
    if ($code -ne 0) { Stop-WithMessage "$Label guard self-test failed (exit $code)." }
}

function Get-GuardLauncherText([string]$NodeExecutable) {
    $escapedNode = $NodeExecutable.Replace("'", "''")
    return @"
#requires -Version 5.1
`$ErrorActionPreference = 'Stop'
`$nodeExe = '$escapedNode'
`$guardPath = Join-Path `$PSScriptRoot 'pc-guard.mjs'
try {
    if (-not (Test-Path -LiteralPath `$nodeExe -PathType Leaf)) { throw 'Pinned node.exe no longer exists; rerun INSTALL.ps1 to refresh the path.' }
    if (-not (Test-Path -LiteralPath `$guardPath -PathType Leaf)) { throw 'pc-guard.mjs is missing.' }

    # Capture raw hook bytes and forward them unchanged; Claude Code sends UTF-8 JSON.
    `$inputStream = [Console]::OpenStandardInput()
    `$memory = New-Object System.IO.MemoryStream
    `$inputStream.CopyTo(`$memory)
    `$hookBytes = `$memory.ToArray()
    `$memory.Dispose()

    # Prevent inherited NODE_OPTIONS from preloading arbitrary code before the policy guard.
    foreach (`$name in @('NODE_OPTIONS', 'NODE_PATH', 'NODE_V8_COVERAGE', 'NODE_EXTRA_CA_CERTS')) {
        [Environment]::SetEnvironmentVariable(`$name, `$null, 'Process')
    }

    `$start = New-Object System.Diagnostics.ProcessStartInfo
    `$start.FileName = `$nodeExe
    `$start.Arguments = '"' + `$guardPath + '"'
    `$start.WorkingDirectory = [System.IO.Path]::GetFullPath((Join-Path `$PSScriptRoot '..\..'))
    `$start.UseShellExecute = `$false
    `$start.CreateNoWindow = `$true
    `$start.RedirectStandardInput = `$true
    `$start.RedirectStandardOutput = `$true
    `$start.RedirectStandardError = `$true

    `$process = New-Object System.Diagnostics.Process
    `$process.StartInfo = `$start
    if (-not `$process.Start()) { throw 'Could not start the pinned Node.js executable.' }
    `$stdoutTask = `$process.StandardOutput.ReadToEndAsync()
    `$stderrTask = `$process.StandardError.ReadToEndAsync()
    `$childInput = `$process.StandardInput.BaseStream
    `$childInput.Write(`$hookBytes, 0, `$hookBytes.Length)
    `$childInput.Flush()
    `$childInput.Close()
    `$process.WaitForExit()
    [Console]::Out.Write(`$stdoutTask.GetAwaiter().GetResult())
    [Console]::Error.Write(`$stderrTask.GetAwaiter().GetResult())
    `$exitCode = `$process.ExitCode
    `$process.Dispose()
    exit `$exitCode
} catch {
    [Console]::Error.WriteLine(('PC-GUARD LAUNCHER BLOCKED: ' + `$_.Exception.Message))
    exit 2
}
"@
}

function Assert-CleanGitEnvironment {
    # Git environment overrides can redirect repository/config/SSH execution.
    # Report variable names only; never echo their values (they may contain secrets).
    $patterns = @(
        '^GIT_CONFIG(?:_.*)?$', '^GIT_DIR$', '^GIT_WORK_TREE$', '^GIT_INDEX_FILE$',
        '^GIT_COMMON_DIR$', '^GIT_OBJECT_DIRECTORY$', '^GIT_ALTERNATE_OBJECT_DIRECTORIES$',
        '^GIT_EXEC_PATH$', '^GIT_EXTERNAL_DIFF$', '^GIT_DIFF_OPTS$', '^GIT_PAGER$',
        '^GIT_SSH(?:_COMMAND)?$', '^GIT_ASKPASS$', '^GIT_TRACE(?:_.*)?$',
        '^GIT_CEILING_DIRECTORIES$', '^GIT_DISCOVERY_ACROSS_FILESYSTEM$',
        '^GIT_OPTIONAL_LOCKS$', '^SSH_ASKPASS$', '^PAGER$'
    )
    $bad = @(Get-ChildItem Env: | Where-Object {
        $name = $_.Name
        $value = $_.Value
        $matchesPattern = $false
        foreach ($pattern in $patterns) {
            if ($name -match $pattern) { $matchesPattern = $true; break }
        }
        $matchesPattern -and -not [string]::IsNullOrWhiteSpace($value)
    } | Select-Object -ExpandProperty Name -Unique)
    if ($bad.Count -gt 0) {
        Stop-WithMessage ("Unsafe Git-related environment overrides are set: {0}. Open a clean PowerShell session and clear only the listed overrides before retrying." -f ($bad -join ', '))
    }
}

function Assert-CleanNodeEnvironment {
    # NODE_OPTIONS can preload arbitrary JavaScript before the guard starts.
    # The launcher clears these variables again immediately before starting Node.
    $names = @('NODE_OPTIONS', 'NODE_PATH', 'NODE_V8_COVERAGE', 'NODE_EXTRA_CA_CERTS')
    $set = @($names | Where-Object { -not [string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable($_, 'Process')) })
    if ($set.Count -gt 0) {
        Stop-WithMessage ("Unsafe Node.js environment variables are set: {0}. Start a clean PowerShell session and clear these process variables before installing." -f ($set -join ', '))
    }
}

function Test-ApprovedGitExecutionEntry([string]$Section, [string]$Key, [string]$Value) {
    # Narrow exceptions for the exact stock Git for Windows / Git LFS entries
    # reported by the Owner. These are not removed or rewritten. The installer
    # only calls `git ls-files`; it does not run diff, checkout, add, or network
    # operations. The Claude hook separately requires --no-textconv for any
    # raw-content git diff and keeps network/credential operations blocked.
    $sectionName = ($Section -replace '\s+', ' ').Trim().ToLowerInvariant()
    $keyName = $Key.Trim().ToLowerInvariant()
    $valueName = ($Value -replace '\s+', ' ').Trim().ToLowerInvariant()

    if ($sectionName -eq 'diff "astextplain"' -and $keyName -eq 'textconv' -and $valueName -eq 'astextplain') {
        return $true
    }
    if ($sectionName -eq 'filter "lfs"') {
        if ($keyName -eq 'clean' -and $valueName -eq 'git-lfs clean -- %f') { return $true }
        if ($keyName -eq 'smudge' -and $valueName -eq 'git-lfs smudge -- %f') { return $true }
        if ($keyName -eq 'process' -and $valueName -eq 'git-lfs filter-process') { return $true }
    }
    return $false
}

function Test-UnsafeGitExecutionConfig([string]$Text) {
    $section = ''
    foreach ($line in ($Text -split "`r?`n")) {
        if ($line -match '^\s*\[([^\]]+)\]\s*$') {
            $section = $Matches[1].ToLowerInvariant().Trim()
            $sectionBase = [regex]::Replace($section, '\s+["''][^"'']*["'']\s*$', '').Trim()
            if ($sectionBase -in @('include', 'includeif', 'pager', 'fsmonitor')) { return $true }
            continue
        }
        if ($line -match '^\s*([a-z][a-z0-9.-]*)\s*=\s*(.*?)\s*$') {
            $key = $Matches[1].ToLowerInvariant()
            $value = $Matches[2].Trim().ToLowerInvariant()
            $baseSection = [regex]::Replace($section, '\s+["''][^"'']*["'']\s*$', '').Trim()
            if ($baseSection -eq 'core' -and $key -in @('fsmonitor', 'pager') -and $value -notin @('', 'false', 'no', '0')) { return $true }
            if ($baseSection -eq 'diff' -and $key -in @('external', 'textconv', 'command') -and $value -notin @('', 'false', 'no', '0')) {
                if (Test-ApprovedGitExecutionEntry $section $key $value) { continue }
                return $true
            }
            if ($baseSection -eq 'filter' -and $key -in @('process', 'smudge', 'clean') -and $value) {
                if (Test-ApprovedGitExecutionEntry $section $key $value) { continue }
                return $true
            }
        }
    }
    return $false
}

function Test-GitConfigPolicySelfTest {
    $cases = @(
        [pscustomobject]@{ Name = 'stock astextplain textconv'; Text = "[diff `"astextplain`"]`n textconv = astextplain`n"; ExpectedUnsafe = $false },
        [pscustomobject]@{ Name = 'stock Git LFS clean/smudge/process'; Text = "[filter `"lfs`"]`n clean = git-lfs clean -- %f`n smudge = git-lfs smudge -- %f`n process = git-lfs filter-process`n required = true`n"; ExpectedUnsafe = $false },
        [pscustomobject]@{ Name = 'custom textconv command'; Text = "[diff `"custom`"]`n textconv = C:/tools/convert.exe`n"; ExpectedUnsafe = $true },
        [pscustomobject]@{ Name = 'modified Git LFS process command'; Text = "[filter `"lfs`"]`n process = powershell -File C:/temp/bad.ps1`n"; ExpectedUnsafe = $true },
        [pscustomobject]@{ Name = 'custom filter command'; Text = "[filter `"custom`"]`n clean = C:/temp/clean.exe`n"; ExpectedUnsafe = $true },
        [pscustomobject]@{ Name = 'Git include remains blocked'; Text = "[include]`n path = C:/temp/extra.gitconfig`n"; ExpectedUnsafe = $true },
        [pscustomobject]@{ Name = 'Git fsmonitor remains blocked'; Text = "[core]`n fsmonitor = C:/tools/watch.exe`n"; ExpectedUnsafe = $true },
        [pscustomobject]@{ Name = 'Git pager remains blocked'; Text = "[core]`n pager = C:/tools/pager.exe`n"; ExpectedUnsafe = $true }
    )
    foreach ($case in $cases) {
        $actual = Test-UnsafeGitExecutionConfig $case.Text
        if ($actual -ne $case.ExpectedUnsafe) {
            Stop-WithMessage ("Git config policy self-test failed: {0}." -f $case.Name)
        }
    }
    Write-Host ("Git config policy self-test: {0}/{0} passed." -f $cases.Count) -ForegroundColor Green
}

function Assert-SafeGitConfiguration {
    # Read config files only to detect external execution hooks; never print contents.
    $profilePath = [Environment]::GetFolderPath('UserProfile')
    $homeCandidates = @($profilePath, $env:HOME) | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | Select-Object -Unique
    $paths = New-Object System.Collections.Generic.List[string]
    [void]$paths.Add((Join-Path $script:RepoRoot '.git\config'))
    foreach ($homeCandidate in $homeCandidates) {
        if ($homeCandidate -notmatch '^[A-Za-z]:[\\/]') {
            Stop-WithMessage 'HOME/UserProfile must resolve to a local absolute drive path for safe Git configuration inspection.'
        }
        [void]$paths.Add((Join-Path $homeCandidate '.gitconfig'))
        if ([string]::IsNullOrWhiteSpace($env:XDG_CONFIG_HOME)) {
            [void]$paths.Add((Join-Path $homeCandidate '.config\git\config'))
        }
    }
    if (-not [string]::IsNullOrWhiteSpace($env:XDG_CONFIG_HOME)) {
        if ($env:XDG_CONFIG_HOME -notmatch '^[A-Za-z]:[\\/]') {
            Stop-WithMessage 'XDG_CONFIG_HOME must be a local absolute drive path for safe Git configuration inspection.'
        }
        [void]$paths.Add((Join-Path $env:XDG_CONFIG_HOME 'git\config'))
    }
    if ($env:ProgramData) { [void]$paths.Add((Join-Path $env:ProgramData 'Git\config')) }
    if ($env:ProgramFiles) { [void]$paths.Add((Join-Path $env:ProgramFiles 'Git\etc\gitconfig')) }
    $programFilesX86 = [Environment]::GetEnvironmentVariable('ProgramFiles(x86)')
    if ($programFilesX86) { [void]$paths.Add((Join-Path $programFilesX86 'Git\etc\gitconfig')) }
    $seenPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($configPath in $paths) {
        if (-not $seenPaths.Add([System.IO.Path]::GetFullPath($configPath))) { continue }
        if (Test-Path -LiteralPath $configPath -PathType Leaf) {
            Assert-NoReparsePoints $configPath
            $configText = [System.IO.File]::ReadAllText($configPath)
            if (Test-UnsafeGitExecutionConfig $configText) {
                Stop-WithMessage "Git configuration contains an include, fsmonitor, pager, external diff, diff-driver command/textconv, or filter execution setting that could affect local inspection: $configPath. Review it manually before installing."
            }
        }
    }
}

try {
    Write-Host 'Paperclip AI-OS Claude Kit installer v2.4.4' -ForegroundColor Cyan

    if ($RepoPath -match '^\\\\') { Stop-WithMessage 'UNC/network repository paths are not supported. Use a local drive path.' }
    if ($RepoPath -notmatch '^[A-Za-z]:[\\/]') { Stop-WithMessage 'RepoPath must be a fully-qualified local drive path such as C:\AI\Paperclip-LF.' }
    if (-not (Test-Path -LiteralPath $RepoPath -PathType Container)) { Stop-WithMessage "Repository folder not found: $RepoPath" }
    Assert-NoReparsePoints $RepoPath
    $resolvedRepo = (Resolve-Path -LiteralPath $RepoPath).ProviderPath
    $script:RepoRoot = [System.IO.Path]::GetFullPath($resolvedRepo).TrimEnd([char[]]@('\', '/'))
    Assert-NoReparsePoints $script:RepoRoot

    $packageJsonPath = Join-Path $script:RepoRoot 'package.json'
    if (-not (Test-Path -LiteralPath $packageJsonPath -PathType Leaf)) {
        Stop-WithMessage 'package.json was not found at the target root. RepoPath must be the Paperclip repository root.'
    }
    Assert-NoReparsePoints $packageJsonPath
    $gitDir = Join-Path $script:RepoRoot '.git'
    if (-not (Test-Path -LiteralPath $gitDir -PathType Container)) {
        Stop-WithMessage '.git is not a directory. This installer supports a normal clone; for a worktree/submodule, use the manual instructions.'
    }
    Assert-NoReparsePoints $gitDir

    # Do not let inherited Git/SSH/Pager overrides or Git config helpers redirect installer reads.
    Assert-CleanGitEnvironment
    Assert-CleanNodeEnvironment
    Test-GitConfigPolicySelfTest
    Assert-SafeGitConfiguration

    # Resolve real executable/script paths and never invoke a PowerShell alias or function.
    $gitInfo = Get-Command -Name git -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $gitInfo -or [string]::IsNullOrWhiteSpace($gitInfo.Source)) { Stop-WithMessage 'Git for Windows application was not found on PATH.' }
    $script:GitCommand = [System.IO.Path]::GetFullPath($gitInfo.Source)
    if (-not (Test-Path -LiteralPath $script:GitCommand -PathType Leaf) -or [System.IO.Path]::GetExtension($script:GitCommand) -ine '.exe') { Stop-WithMessage 'Resolved Git command must be a real git.exe executable.' }

    $nodeInfo = Get-Command -Name node -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $nodeInfo -or [string]::IsNullOrWhiteSpace($nodeInfo.Source)) { Stop-WithMessage 'Node.js application was not found on PATH.' }
    $script:NodeCommand = [System.IO.Path]::GetFullPath($nodeInfo.Source)
    if (-not (Test-Path -LiteralPath $script:NodeCommand -PathType Leaf) -or [System.IO.Path]::GetExtension($script:NodeCommand) -ine '.exe') { Stop-WithMessage 'Resolved Node command must be a real node.exe executable.' }

    $powershellInfo = Get-Command -Name powershell.exe -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($null -eq $powershellInfo -or [string]::IsNullOrWhiteSpace($powershellInfo.Source)) { Stop-WithMessage 'Windows PowerShell powershell.exe was not found.' }
    $script:PowerShellCommand = [System.IO.Path]::GetFullPath($powershellInfo.Source)
    if (-not (Test-Path -LiteralPath $script:PowerShellCommand -PathType Leaf) -or [System.IO.Path]::GetExtension($script:PowerShellCommand) -ine '.exe') { Stop-WithMessage 'Resolved PowerShell command must be a real powershell.exe executable.' }

    $claudeInfo = Get-Command -Name claude -All -ErrorAction SilentlyContinue | Where-Object { $_.CommandType -eq 'Application' -or $_.CommandType -eq 'ExternalScript' } | Select-Object -First 1
    if ($null -eq $claudeInfo) { Stop-WithMessage 'Claude Code CLI application or script was not found on PATH (aliases/functions are ignored).' }
    $claudePath = if (-not [string]::IsNullOrWhiteSpace($claudeInfo.Source)) { $claudeInfo.Source } else { $claudeInfo.Path }
    if ([string]::IsNullOrWhiteSpace($claudePath) -or -not (Test-Path -LiteralPath $claudePath -PathType Leaf)) { Stop-WithMessage 'Could not resolve the real Claude Code CLI file path.' }
    $script:ClaudeCommand = [System.IO.Path]::GetFullPath($claudePath)

    $nodeVersionOutput = (& $script:NodeCommand --version 2>&1 | Out-String).Trim()
    $nodeExit = $LASTEXITCODE
    if ($nodeExit -ne 0) { Stop-WithMessage "Node.js failed to start: $nodeVersionOutput" }
    $nodeMatch = [regex]::Match($nodeVersionOutput, '(?<!\d)(\d+)\.(\d+)\.(\d+)')
    if (-not $nodeMatch.Success -or [int]$nodeMatch.Groups[1].Value -lt 20) { Stop-WithMessage "Node.js 20 or newer is required. Detected: $nodeVersionOutput" }

    $claudeVersionOutput = (& $script:ClaudeCommand --version 2>&1 | Out-String).Trim()
    $claudeExit = $LASTEXITCODE
    if ($claudeExit -ne 0) { Stop-WithMessage "Claude Code failed to start: $claudeVersionOutput" }
    $claudeMatch = [regex]::Match($claudeVersionOutput, '(?<!\d)(\d+\.\d+\.\d+)(?!\d)')
    if (-not $claudeMatch.Success) { Stop-WithMessage "Could not parse Claude Code version: $claudeVersionOutput" }
    $claudeVersion = [version]$claudeMatch.Groups[1].Value
    if ($claudeVersion -lt [version]'2.1.314') {
        Stop-WithMessage "Claude Code $claudeVersion is older than 2.1.314. Update it first; onFailure=block and native read/write path boundaries are required."
    }

    Assert-NoReparsePoints $PSScriptRoot
    $sourceRoot = [System.IO.Path]::GetFullPath($PSScriptRoot).TrimEnd([char[]]@('\', '/'))
    Assert-NoReparsePoints $sourceRoot
    Assert-PackageManifest $sourceRoot
    $sourceSettings = Join-Path $sourceRoot '.claude\settings.local.json.NEW'
    $guardSource = Join-Path $sourceRoot '.claude\hooks\pc-guard.mjs'
    if (-not (Test-Path -LiteralPath $sourceSettings -PathType Leaf)) { Stop-WithMessage 'Package settings.local.json.NEW is missing.' }
    if (-not (Test-Path -LiteralPath $guardSource -PathType Leaf)) { Stop-WithMessage 'Package pc-guard.mjs is missing.' }
    Assert-NoReparsePoints $sourceSettings
    Assert-NoReparsePoints $guardSource

    $copyList = @(
        'CLAUDE.local.md',
        '.claude\agents\pc-explorer.md',
        '.claude\hooks\pc-guard.mjs',
        '.claude\skills\pc-api-map\SKILL.md',
        '.claude\skills\pc-company-launch-flow\SKILL.md',
        '.claude\skills\pc-live-work-rules\SKILL.md',
        '.claude\skills\pc-provider-setup\SKILL.md',
        '.claude\skills\pc-integration-matrix\SKILL.md',
        '.claude\skills\pc-rtl-i18n-review\SKILL.md',
        '.claude\skills\pc-step-gate\SKILL.md',
        '.claude\skills\pc-upstream-merge\SKILL.md'
    )

    foreach ($relative in $copyList) {
        $source = Join-Path $sourceRoot $relative
        $destination = Join-Path $script:RepoRoot $relative
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { Stop-WithMessage "Package file missing: $relative" }
        Assert-NoReparsePoints $source
        Assert-NoReparsePoints $destination
        $gitRelative = $relative.Replace('\', '/')
        if (Test-GitTracked $gitRelative) { Stop-WithMessage "Target is tracked by Git: $gitRelative. Review the repository before installing." }
        if (Test-Path -LiteralPath $destination) {
            $item = Get-Item -LiteralPath $destination -Force
            if ($item.PSIsContainer) { Stop-WithMessage "Destination exists as a directory: $relative" }
            if (-not (Test-SameFile $source $destination)) {
                if ($relative -eq 'CLAUDE.local.md') { Stop-WithMessage 'A different personal CLAUDE.local.md already exists. Merge it manually; it will never be overwritten.' }
                if (-not $UpdateExistingKitFiles) { Stop-WithMessage "A different kit file already exists: $relative. Review it, then re-run with -UpdateExistingKitFiles." }
            }
        }
    }

    # Only execute the guard after every packaged source has passed path/link checks.
    Run-GuardSelfTest $guardSource 'package'

    $launcherDestination = Join-Path $script:RepoRoot '.claude\hooks\pc-guard-launch.ps1'
    $launcherRelative = '.claude/hooks/pc-guard-launch.ps1'
    Assert-NoReparsePoints (Join-Path $script:RepoRoot '.claude\hooks')
    Assert-NoReparsePoints $launcherDestination
    if ((Test-Path -LiteralPath $launcherDestination) -and -not (Test-Path -LiteralPath $launcherDestination -PathType Leaf)) {
        Stop-WithMessage 'The pc-guard-launch.ps1 destination exists but is not a regular file.'
    }
    if (Test-GitTracked $launcherRelative) { Stop-WithMessage 'pc-guard-launch.ps1 is tracked by Git. Stop and review it manually.' }
    $launcherText = Get-GuardLauncherText $script:NodeCommand
    $existingLauncherText = if (Test-Path -LiteralPath $launcherDestination -PathType Leaf) { [System.IO.File]::ReadAllText($launcherDestination) } else { '' }
    if ($existingLauncherText -and $existingLauncherText.Trim() -ne $launcherText.Trim() -and -not $UpdateExistingKitFiles) {
        Stop-WithMessage 'An existing pc-guard-launch.ps1 differs from the generated launcher. Review it, then rerun with -UpdateExistingKitFiles to replace it safely.'
    }

    $settingsDestination = Join-Path $script:RepoRoot '.claude\settings.local.json'
    $settingsRelative = '.claude/settings.local.json'
    Assert-NoReparsePoints (Join-Path $script:RepoRoot '.claude')
    Assert-NoReparsePoints $settingsDestination
    if ((Test-Path -LiteralPath $settingsDestination) -and -not (Test-Path -LiteralPath $settingsDestination -PathType Leaf)) {
        Stop-WithMessage 'The settings.local.json destination exists but is not a regular file.'
    }
    if (Test-GitTracked $settingsRelative) { Stop-WithMessage 'settings.local.json is tracked by Git. Stop and review it manually.' }

    try { $packagedSettings = Get-Content -LiteralPath $sourceSettings -Raw | ConvertFrom-Json }
    catch { Stop-WithMessage "Package settings JSON is invalid: $($_.Exception.Message)" }
    if ($packagedSettings -isnot [pscustomobject]) { Stop-WithMessage 'Package settings root must be a JSON object.' }

    if (Test-Path -LiteralPath $settingsDestination -PathType Leaf) {
        try { $existingSettings = Get-Content -LiteralPath $settingsDestination -Raw | ConvertFrom-Json }
        catch { Stop-WithMessage "Existing settings.local.json is invalid JSON: $($_.Exception.Message)" }
    } else {
        $existingSettings = $packagedSettings
    }
    $mergedSettings = Get-MergedSettings $existingSettings $packagedSettings
    $settingsJson = $mergedSettings | ConvertTo-Json -Depth 100

    $excludePath = Join-Path $gitDir 'info\exclude'
    Assert-NoReparsePoints (Split-Path -Parent $excludePath)
    Assert-NoReparsePoints $excludePath
    if ((Test-Path -LiteralPath $excludePath) -and -not (Test-Path -LiteralPath $excludePath -PathType Leaf)) {
        Stop-WithMessage '.git/info/exclude exists but is not a regular file.'
    }
    if (Test-Path -LiteralPath $excludePath -PathType Leaf) {
        $excludeText = [System.IO.File]::ReadAllText($excludePath)
    } else {
        $excludeText = ''
    }
    $excludeLines = @($excludeText -split "`r?`n" | Where-Object { $_ -ne '' })
    $rules = @('/CLAUDE.local.md', '/.claude/settings.local.json', '/.claude/hooks/pc-guard.mjs', '/.claude/hooks/pc-guard-launch.ps1', '/.claude/agents/pc-explorer.md', '/.claude/skills/pc-*/')
    $rulesToAppend = @($rules | Where-Object { $excludeLines -notcontains $_ })
    $newExcludeText = $excludeText
    if ($rulesToAppend.Count -gt 0) {
        if ($newExcludeText.Length -gt 0 -and -not $newExcludeText.EndsWith("`n")) { $newExcludeText += [Environment]::NewLine }
        $newExcludeText += (($rulesToAppend -join [Environment]::NewLine) + [Environment]::NewLine)
    }

    if ($ValidateOnly) {
        Write-Host ''
        Write-Host 'VALIDATION PASSED. No repository files were written.' -ForegroundColor Green
        Write-Host "Repository: $script:RepoRoot"
        Write-Host "Node: $nodeVersionOutput ($script:NodeCommand)"
        Write-Host "Hook launcher: $script:PowerShellCommand (clean Node environment)"
        Write-Host "Claude Code: $claudeVersionOutput ($script:ClaudeCommand)"
        Write-Host "Kit files ready: $($copyList.Count); generated launcher: ready; Hook merge: valid; Git exclude merge: valid"
        return
    }

    $needsBackup = (Test-Path -LiteralPath $settingsDestination -PathType Leaf) -or (Test-Path -LiteralPath $excludePath -PathType Leaf) -or (Test-Path -LiteralPath $launcherDestination -PathType Leaf) -or $UpdateExistingKitFiles
    if ($needsBackup) {
        $localAppData = [Environment]::GetFolderPath('LocalApplicationData')
        if ([string]::IsNullOrWhiteSpace($localAppData)) { Stop-WithMessage 'LOCALAPPDATA is unavailable; cannot create safe backups.' }
        Assert-NoReparsePoints $localAppData
        $script:BackupRoot = Join-Path $localAppData ("Paperclip-AI-OS-Kit\Backups\{0}" -f (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
        Ensure-Directory $script:BackupRoot
    }

    try {
        foreach ($relative in $copyList) {
            $source = Join-Path $sourceRoot $relative
            $destination = Join-Path $script:RepoRoot $relative
            if (-not (Test-SameFile $source $destination)) { Install-File $source $destination }
        }
        if ($existingLauncherText.Trim() -ne $launcherText.Trim()) { Write-TextAtomically $launcherText $launcherDestination }
        $existingSettingsText = if (Test-Path -LiteralPath $settingsDestination -PathType Leaf) { [System.IO.File]::ReadAllText($settingsDestination) } else { '' }
        if ($existingSettingsText.Trim() -ne $settingsJson.Trim()) { Write-TextAtomically $settingsJson $settingsDestination }
        if ($newExcludeText -ne $excludeText) { Write-TextAtomically $newExcludeText $excludePath }

        Run-GuardSelfTest (Join-Path $script:RepoRoot '.claude\hooks\pc-guard.mjs') 'installed'
    } catch {
        Write-Host "Installation failed: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host 'Attempting transaction rollback...' -ForegroundColor Yellow
        throw
    }

    Write-Host ''
    Write-Host 'INSTALLATION SUCCESSFUL' -ForegroundColor Green
    Write-Host "Repository: $script:RepoRoot"
    Write-Host "Node: $nodeVersionOutput ($script:NodeCommand)"
    Write-Host "Hook launcher: $script:PowerShellCommand (clean Node environment)"
    Write-Host "Claude Code: $claudeVersionOutput ($script:ClaudeCommand)"
    if ($script:BackupRoot) { Write-Host "Backups: $script:BackupRoot" }
    Write-Host 'Existing Claude hooks and unrelated settings were preserved; the kit hook was merged.'
    Write-Host 'Next: open a NEW PowerShell session, set PC_GUARD_PHASE=analysis, then start Claude Code.' -ForegroundColor Cyan
} catch {
    if ($script:ChangeLog.Count -gt 0 -or $script:CreatedDirs.Count -gt 0) { Restore-Transaction }
    Write-Host "`n$($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
