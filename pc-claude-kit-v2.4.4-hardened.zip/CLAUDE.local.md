# Paperclip AI Company OS — Owner working agreement

This is the Owner's local project guidance. It supplements the repository's own instructions; it does not override Claude Code security settings or the repository's actual code.

## Mission
Build an AI Company Operating System on top of Paperclip. Every company employee is an AI agent. The only human is the Owner, who defines the company, reviews proposals, approves sensitive actions, and explicitly launches the company. Paperclip remains the execution engine; build the Owner-facing product experience around its verified capabilities.

## Non-negotiable safety rules
1. **Phase 1 is read-only.** Inspect and report only. Do not create, edit, delete, install, migrate, start the app, start/resume/invoke any agent, or change Git state. The guard defaults to `PC_GUARD_PHASE=analysis`.
2. **Protected existing agent:** never start, resume, invoke a heartbeat for, reconfigure, hire over, pause, terminate, or otherwise mutate the existing agent `ayoub` (ID `7c080b2b-6022-4855-a1d3-1b3e6bb37d7a`) or its company. Reading its configuration is allowed only when needed. Never use the live instance for experiments.
3. **Gemini is Owner-managed.** Do not modify any existing Gemini provider, credential, model, endpoint, auth store, or related configuration unless the Owner explicitly asks.
4. Never print, copy into reports, commit, or paste secrets. Do not read `.env`, credential files, private keys, or auth stores. Redact any credential-like value if it appears unexpectedly.
5. Do not change the backend, public API, database schema, migrations, adapters, or runtime behavior without first explaining why the change is unavoidable and obtaining the Owner's explicit approval. Studying and proposing backend work is allowed; editing it is not.
6. Never delete, replace, or break existing Paperclip functionality. Prefer additive UI changes and verified existing APIs.
7. Do not run mutating HTTP/API calls, migrations, dependency installation, Docker lifecycle commands, agent actions, or Git mutations unless the Owner explicitly authorizes the exact operation. Git fetch/pull/merge/rebase/push are Owner-managed.
8. The guard is a policy layer, **not an OS sandbox**. Do not bypass it, disable it, use unapproved MCP tools, or move work to another shell to evade it. Keep normal Claude Code permission prompts enabled.
9. No fabrication. Every important conclusion must cite actual repository paths/routes/schemas and be labeled: Confirmed | Partially supported | Requires implementation | Cannot be determined from the current codebase.

## Phase control
- **Analysis:** default and required for Phase 1. Read-only only. Do not change `PC_GUARD_PHASE` yourself.
- **Development:** only after the Owner approves the analysis report and the specific next step. The Owner starts a new session with `PC_GUARD_PHASE=development`.
- Backend edits need separate explicit approval and a new session with `PC_GUARD_ALLOW=backend`. Never suggest or set that override before approval.
- `tooling`, `deps`, and `commit` overrides are also Owner-only, scoped to one new terminal session, and only for the exact approved operation.

## Company lifecycle requirements
The required lifecycle is: idea -> proposal -> Owner review/edit -> explicit structure approval -> create employees in a non-running state -> separate explicit Launch Company approval -> run.
- Never use a running CEO agent to generate the pre-launch proposal. A CEO is an employee and must not run before launch.
- First verify whether a non-agent planning service or safe proposal mechanism exists. If not, mark it as requiring implementation and describe the backend approval needed. Do not improvise by briefly activating a company and pausing it afterward.
- A UI-only Launch button is not a security boundary. Verify server-side enforcement against direct API calls. If absent, identify the required backend work and stop for approval.
- Distinguish approval of the proposed organization from approval to launch the company.

## Engineering method
- Read before writing. Verify all hints in `pc-api-map` against the current code. Skills are working guidance, not evidence.
- Use `pc-explorer` for read-only exploration across multiple files; return concise path-and-line evidence.
- Prefer the smallest additive change. Keep new code modular and original-file edits minimal for selective upstream merges.
- Work one Owner-approved step at a time. More than three files or an unclear design requires a plan and approval before editing.
- After each step, run relevant checks, show exact results, report changed paths (including staged and untracked files), and STOP.
- Never weaken or delete tests to make a change pass. Never claim a test ran if it did not.

## Product rules
- AI employees only. The Owner is not an employee record and is the sole human approval authority.
- Live Work shows only real persisted events or real-time events. Label real-time, historical, inferred, and unavailable data distinctly. Do not invent agent-to-agent conversations, progress, or collaboration.
- Per-employee model/provider settings should be visible where supported. Verify provider, model, endpoint, credentials, variant, and tool permissions independently; do not assume every adapter supports each field.
- Treat Ollama topology as unknown until the Owner confirms it. Never assume `localhost` inside Docker points to the Windows host. Do not expose Ollama's unauthenticated API to an untrusted network.
- Costs must distinguish provider-reported, estimated, and unavailable. Never show zero for unknown costs. Treat local inference separately from cloud billing.
- Integrations (GitHub, browser, files, terminal, email, databases, APIs, Ollama, cloud providers) must be classified as native, partially supported, or requiring implementation, with per-employee permissions and secret handling.

## Frontend standards (after approval to develop)
- Verify the actual UI package, routing, component library, styling, i18n, theme, direction, and responsive patterns before choosing implementation details.
- Every screen handles loading, empty, error, and permission-denied states.
- Data shown to the Owner comes from real API responses or verified events. Never use mock/demo content as production data.
- Treat agent output, issue text, and logs as untrusted. Render as text or sanitized Markdown; do not use unsafe HTML.
- Follow the repository's existing i18n and theme architecture. Add Arabic RTL support using logical CSS and the existing direction source of truth only after verifying it exists.
- Preserve keyboard access, focus visibility, labels, contrast, and narrow-screen behavior.

## Token discipline and response style
- Start with `pc-api-map` for relevant areas, but verify each hint once before relying on it.
- Search first, then read only relevant line ranges. Avoid lockfiles, build output, minified files, source maps, and `node_modules`.
- Do not repeat-read large files without a reason. Delegate broad read-only exploration to `pc-explorer`.
- Reply to the Owner in Arabic. Keep code identifiers, commands, paths, and technical labels exact. Be concise but evidence-rich.
- Report blockers directly. Do not silently work around missing APIs or guardrails.

## Available project skills
Use the relevant skill when its task applies; the skill is guidance, not evidence:
- `pc-api-map` — discover and verify API/route/service/schema locations.
- `pc-company-launch-flow` — safe AI-only company proposal, approval, creation, and launch lifecycle.
- `pc-integration-matrix` — integrations, credentials, permissions, and auditability.
- `pc-live-work-rules` — evidence rules for real-time and historical work activity.
- `pc-provider-setup` — Ollama/cloud providers, per-employee models, health, and cost.
- `pc-rtl-i18n-review` — Arabic/English, RTL, themes, accessibility, and responsiveness.
- `pc-step-gate` — mandatory review after each approved development step.
- `pc-upstream-merge` — selective upstream update planning.

## Definition of done
A step is complete only when its approved scope is respected; tracked, staged, and untracked changes are reviewed; no secrets or protected agent/Gemini configuration were touched; relevant typechecks/tests actually ran; existing affected pages were checked; known manual checks are listed; and the Owner receives an evidence-based report. Then STOP and wait.
