# Security notes and limits — v2.4.4

## What the guard enforces

- Defaults to `analysis`; all direct edit/write tools are blocked in Phase 1, including writes under `ui/`. Claude Code native `blockReadsOutsideWorkingDirectories` and `blockWritesOutsideWorkingDirectories` are also enabled to restrict built-in file-tool access beyond the active working directories; they do not sandbox arbitrary shell commands or MCP processes and do not replace the hook/permission prompts.
- `development` allows direct edits only under `ui/`; Backend, dependency, and tooling changes require separate Owner-only session overrides.
- Resolves normalized paths and existing symlink/junction targets before checking repository containment. Rejects paths outside the checkout.
- Blocks direct reads/writes of `.git` internals, project-local Claude settings, common secret files, private-key formats, credential directories, and `node_modules`.
- Validates `Grep`/`Glob` base paths instead of validating only their patterns. Blocks broad wildcard enumeration and secret-targeting patterns.
- Uses a strict allowlist for shell search arguments. `rg --pre`, `--pre-glob`, `-f`/`--file`, ripgrep config files/environment, `grep -f`/`--file`, `--exclude-from`, unscoped recursive search, PowerShell `Env:`/other providers, wildcard paths, and unapproved options are denied. Bare lockfile names are excluded in `cat`/`Get-Content` as well as explicit path reads.
- Blocks Git global config/execution options (`-c`, `--config-env`, `--exec-path`, etc.), dangerous subcommands, external diff/textconv, output-file options, and read-oriented Git commands when local/global configuration enables include, fsmonitor, pagers, custom external diff/textconv, or custom filter execution. Exact stock Git for Windows astextplain and Git LFS filter values are narrowly allowlisted. `git ls-remote` requires a configured safe HTTP(S) remote and rejects local URL rewrites/custom helpers.
- Allows only the reviewed `pc-*` skills and the read-only `pc-explorer` subagent. Unknown tools and MCP tools are deny-by-default. `EnterPlanMode` is allowed; leaving plan mode is blocked in analysis.
- Blocks mutating HTTP/API commands. The only permitted network exception is an exact read-only Ollama `GET /api/tags` or `GET /api/version` request when `PC_OLLAMA_URL` is explicitly supplied.
- Fails closed on malformed hook input or internal errors. The hook uses `onFailure: "block"` and runs through a generated PowerShell launcher that clears `NODE_OPTIONS`, `NODE_PATH`, `NODE_V8_COVERAGE`, and `NODE_EXTRA_CA_CERTS` before starting the pinned Node executable.

## What the guard does not guarantee

This is a policy hook, not a security boundary. It is not a Windows Sandbox, VM, filesystem ACL, network firewall, credential vault, or proof that every process launched by a permitted command is harmless.

Residual risks include:

- Claude Code and the hook run with the current Windows user's permissions. A separate terminal, editor, IDE extension, malware, or another process can modify files without invoking this hook.
- A malicious/compromised repository or dependency may exploit bugs in tools that are allowed to inspect or test code. Do not run tests/builds in Phase 1.
- Git itself may consult global/system configuration or trusted credential helpers. The guard blocks common command/config injection paths and rejects selected Git/SSH/Pager environment overrides, but it cannot prove all machine-level Git configuration or executable resolution on Windows is safe.
- A permitted test/build command in a later development phase executes repository scripts with the user's privileges. Review scripts and use an isolated clone, separate database, separate ports, and no production credentials.
- Hook schemas and built-in Claude Code tool names may change. If a new required tool is blocked, inspect its exact input shape and add a narrow reviewed rule; do not broadly allow unknown tools.
- A command-output stream can still contain secrets embedded in ordinary source text. Redact unexpected credential-like data and do not inspect auth stores or `.env` files.
- Windows path handling, reparse-point behavior, Node process launching, PowerShell semantics, Claude hook registration, and failure behavior must be verified on the Owner's machine.
- A local configuration file may reference a credential provider or machine-specific path not recognized by these patterns. Do not expose live tokens to the analysis session.

## Windows installer guarantees and limits

`INSTALL.ps1` performs a read-only preflight before any write. It rejects UNC/relative repository paths, selected Git/SSH/Pager/Node environment overrides, Git config hooks that could execute during local inspection, and existing reparse points in the repository/source/destination path chains. It checks Git config from the repository, UserProfile, `HOME`, `XDG_CONFIG_HOME`, ProgramData, Program Files, and Program Files (x86). It requires Claude Code 2.1.314+, and resolves real `git.exe`, `node.exe`, and `powershell.exe` executables. It generates a PowerShell launcher that clears Node preload/module environment variables and forwards the original hook input bytes to the pinned absolute Node executable. It enables Claude Code's native read/write working-directory boundaries, rejects tracked targets and personal `CLAUDE.local.md` overwrites, validates JSON and hook structure, merges the kit hook without discarding unrelated hooks, preserves `.gitignore`, backs up existing files, uses temporary same-directory files, and attempts rollback if an install step or post-copy self-test fails. Credential helpers and URL rewrites are handled more narrowly: the guard refuses network `git ls-remote` when authentication/transport configuration is present, while the local installer preflight does not require disabling a normal credential manager.

These are implementation goals, not verified Windows results in this build. The script was not run under Windows PowerShell here. Run `INSTALL.ps1 -ValidateOnly` first on the target PC, inspect the output, then run the installer only after preflight passes. If rollback emits a warning, stop and inspect the backup directory before proceeding.

## Protected project state

The kit's instructions and policy protect the known `ayoub` agent ID and company ID, and the existing Gemini configuration. This is defense in depth only. Do not provide live API tokens to Claude Code, do not connect mutating Paperclip MCP tools during analysis, and do not use a live Paperclip database/container for experiments.

## Test evidence

`node .claude/hooks/pc-guard.mjs --selftest` runs the guard's explicit policy regression suite. **231 passing cases on Linux** prove only those cases. They do not prove resistance to arbitrary commands, Windows reparse points, every Claude Code tool, or every Git configuration. The Owner must still verify `-ValidateOnly`, `/status`, `/hooks`, `/memory`, a blocked write attempt, and a fail-closed hook failure on Windows.

## v2.4.1 additional hardening

- Ripgrep's `-L` means `--follow` and can traverse symlinks. It is now removed from the `rg` option allowlist; `--follow` is rejected. GNU grep's separate `-L` meaning (files-without-matches) remains allowed for explicit source files.
- Unrestricted `git diff` can print every changed tracked file, including a tracked secret file. Raw-content `git diff` is now blocked unless every pathspec after `--` is a literal, existing or resolvable UI source/document file under `ui/`, with no wildcard, Git pathspec magic, traversal, or protected file. Summary flags such as `--stat` and `--name-only` remain available without pathspecs.
- Windows installer now validates `PACKAGE-MANIFEST.sha256`, checks each listed file hash, rejects unmanifested files and reparse points within the extracted package before invoking the guard or copying anything.
- `evaluate()` is import-safe: the stdin/exit handler runs only when `pc-guard.mjs` is executed directly, allowing external regression tests to import the policy function without hanging.

## Additional v2.4.1 residual checks

- The shell/PowerShell command validator is intentionally restrictive but is not a complete language parser. Do not pass multiline PowerShell, script blocks, expressions, encoded commands, or command strings generated from untrusted content. Such forms should be denied, but a policy hook cannot guarantee semantic coverage for every future tool schema or shell grammar.
- The hook can inspect the arguments Claude Code supplies to `PreToolUse`; it cannot mediate commands launched outside Claude Code, nor can it confine a tool process after it starts.
- The installer uses path checks before file operations. These checks reduce symlink/junction risks but are not an atomic Windows handle-based filesystem sandbox; a privileged concurrent process could still create a time-of-check/time-of-use race.
- `-ValidateOnly` is mandatory. Then verify `/status`, `/hooks`, `/memory`, run the installed self-test, and confirm an out-of-root write attempt is denied. Do not proceed if the hook is absent, reports an error, or fails open.


## v2.4.3 Git for Windows / Git LFS compatibility

- The exact stock `[diff "astextplain"] textconv = astextplain` and `[filter "lfs"]` clean/smudge/process command strings are allowlisted. This is intentionally exact; other command strings and custom diff/filter sections remain blocked.
- The local installer only invokes `git ls-files` to check whether destination files are tracked. It does not run network, checkout, add, diff, or commit operations and does not rewrite the user's Git configuration.
- The installer runs a Git-config policy self-test during `-ValidateOnly`, covering the exact stock values and negative custom-command/include/fsmonitor/pager cases.
- The Claude hook permits read-only Git inspection with those exact stock entries. Raw-content `git diff` requires `--no-textconv` and explicit safe UI pathspecs; summary-only diffs remain permitted. Remote `git ls-remote` remains separately restricted when credential helpers or unsafe transport configuration are present.
- Git LFS is an external helper. The allowlist assumes the user's installed Git for Windows/Git LFS binaries are trusted; this kit is not an executable-signature verifier or Windows sandbox. Do not allow untrusted executables to shadow `git-lfs` in PATH.

## v2.4.2 installer parser hotfix

The v2.4.1 Windows `INSTALL.ps1` contained a PowerShell 5.1 parser error in a multi-line boolean condition. v2.4.2 changes that condition to a single line and requires the local PowerShell Parser API preflight check before `INSTALL.ps1 -ValidateOnly` is run. This is a syntax repair, not evidence of a successful Windows install.

## v2.4.4 Windows preflight path-check fix

- `Test-GitTracked` now uses `git ls-files --cached -- <literal-path>` rather than `--error-unmatch`. An expected untracked target such as `CLAUDE.local.md` therefore produces an empty result without Git's pathspec diagnostic, while a genuine Git/index error still stops the preflight.
- This is a read-only index query. It does not stage files, invoke checkout/filter operations, contact remotes, or modify Git configuration.
- The Owner's v2.4.3 run reached this check only after the ZIP hash, PowerShell parser check, Git-config policy self-test (8/8), and package-manifest verification (19 files) passed. The reported pathspec failure occurred during preflight, before the installer write section.
- v2.4.4 must still pass the Owner's Windows `-ValidateOnly` run. No Windows execution is claimed from the Linux build environment.
