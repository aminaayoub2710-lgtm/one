# Changelog

## 2.4.4

- Fixed a Windows PowerShell preflight failure for expected untracked installer targets such as `CLAUDE.local.md`.
- Replaced `git ls-files --error-unmatch` with quiet `git ls-files --cached`; untracked paths now produce an empty result without a pathspec diagnostic, while genuine Git/index failures still stop validation.
- No Git configuration is changed, and no staging, checkout, network, diff, or commit command is introduced.

# pc-claude-kit v2.4.3 — Git for Windows / Git LFS compatibility fix

## Installer and guard compatibility
- The Owner's read-only Git config inspection showed the stock Git for Windows `diff.astextplain.textconv=astextplain` setting and standard Git LFS `clean`, `smudge`, and `process` filters.
- The installer now permits only those exact known entries and continues to reject custom diff-driver commands, altered Git LFS commands, arbitrary filter commands, `include`/`includeIf`, `fsmonitor`, and pager execution settings.
- The installer does not remove, rewrite, or disable the Owner's Git configuration. It only uses local `git ls-files` checks and does not run network, checkout, add, diff, or commit operations.
- Added a Windows-side installer policy self-test for the exact Git for Windows/Git LFS defaults and negative cases. It runs during `-ValidateOnly` and real installation.
- The Claude guard recognizes those exact stock entries so ordinary read-only Git inspection is not blocked solely because Git LFS is installed. Custom filter/diff commands remain blocked.
- Raw-content `git diff` requires explicit `--no-textconv`; summary-only output (`--stat`, `--name-only`, etc.) remains available. Sensitive and non-UI pathspec restrictions remain in force.
- Added regression tests for the complete reported Git config set and modified/custom commands.

## Verification
- `node --check .claude/hooks/pc-guard.mjs`: passed on Linux.
- `node .claude/hooks/pc-guard.mjs --selftest`: **231/231 passed on Linux**.
- PowerShell installer policy tests are embedded and will run on Windows during `-ValidateOnly`; they have not been executed in this Linux build environment.
- Windows PowerShell 5.1 parsing, installer `-ValidateOnly`, Claude Code Hook registration, and fail-closed behavior remain to be verified on the Owner's machine.

## Safety note
Do not delete or change the reported Git LFS / astextplain entries to make installation pass. The allowlist is exact and narrow; a modified command or different filter remains a hard stop.
# pc-claude-kit v2.4.2 — Windows PowerShell parser hotfix

## Critical installer hotfix
- Fixed the Windows PowerShell parser error reported on v2.4.1. The manifest-path safety `if` condition in `Assert-PackageManifest` is now a single line, avoiding the parser failure caused by placing binary `-or` operators at the beginning of continuation lines in Windows PowerShell 5.1.
- Added a mandatory local PowerShell AST parser preflight to the installation guide. It parses `INSTALL.ps1` without executing it; the installer must not be run unless the exact local parser reports zero errors.
- The prior v2.4.1 command failed while PowerShell parsed the script. The installer body had not begun executing, so its repository-write steps did not run.

## Preserved v2.4.1 protections
- Retains the restrictions on `rg -L` / `rg --follow` symlink traversal.
- Retains scoped `git diff` rules that prevent unrestricted diff output and sensitive/out-of-scope pathspecs.
- Retains the 225 guard regression tests, including symlink fixtures and Git staged/untracked inventory coverage.
- Retains package manifest validation, reparse-point detection, `-ValidateOnly`, backup/rollback, Hook merge, and Git exclude merge.

## Verification
- `node --check .claude/hooks/pc-guard.mjs`: passed on Linux / Node.js 22.16.0.
- `node .claude/hooks/pc-guard.mjs --selftest`: **225/225 passed on Linux**.
- `.claude/settings.local.json.NEW`: valid JSON.
- Package Manifest regenerated and every listed file hash verified; no unmanifested files included.
- ZIP archive integrity verified after creation.
- Windows PowerShell 5.1 parsing and `-ValidateOnly` are **not yet verified in this build environment**. The Owner must run the included parser preflight first.

---

## إصلاحات الحارس في v2.4.0
- توسيع فحص إعدادات Git ليشمل إعدادات diff-driver داخل `[diff "name"]`، بما فيها `textconv` و`command` التي قد تنفذ برامج خارجية، مع فحص مصادر HOME وXDG وProgram Files (x86).
- إضافة حارس لمتغيرات بيئة Node، ومشغّل PowerShell على Windows يزيل متغيرات التحميل المسبق قبل بدء Node ويمرر بايتات JSON الأصلية دون إعادة ترميز.

- سدّ ثغرة `rg --pre` و`--pre-glob` وخيارات قراءة ملفات الأنماط الخارجية، مع قائمة سماح صارمة لخيارات البحث.
- منع `grep -f/--file` و`--exclude-from` وما شابهها من قراءة ملفات خارج مسار البحث المقصود.
- تصحيح فحص مسارات أوامر القراءة، ومنع قراءة lockfiles وملفات minified وsource maps حتى عند استخدام اسم ملف جذري مثل `cat pnpm-lock.yaml` أو `Get-Content pnpm-lock.yaml`.
- حظر توسعة متغيرات البيئة والمسارات المنزلية، ومسارات PowerShell providers مثل `Env:`، وتعبيرات PowerShell الديناميكية في نمط التحليل.
- تضييق `Grep` و`Glob` إلى مجلدات وأنماط امتدادات المصدر/التوثيق الآمنة؛ ومنع البحث داخل `.claude` و`.git` ومجلدات الأسرار.
- حظر خيارات Git العامة التي تغيّر إعدادات التنفيذ (`-c`, `--config-env`, `--exec-path`) وخيارات external diff/textconv والخيارات الخطرة.
- حظر متغيرات بيئة Git/SSH/Pager المعروفة التي قد تعيد توجيه إعداد Git أو تنفيذ SSH أو Pager؛ لا تُطبع قيم المتغيرات. كما يوقف أوامر Git المقروءة عند اكتشاف إعدادات `include` أو `fsmonitor` أو pager أو external diff/textconv أو filter process التي يمكن أن تشغّل برامج جانبية، ويطبق المثبت فحصًا مماثلًا على ملفات إعداد Git قبل استدعاء `git.exe`.
- قصر فحص Git remotes على remotes معروفة بعناوين HTTP(S) آمنة، ورفض credential helpers وURL rewrite وcustom helpers والعناوين ذات بيانات الاعتماد.
- السماح بطلب Ollama GET فقط إلى `/api/tags` أو `/api/version` على العنوان الصريح الذي يقدمه المالك، مع `curl --disable` أولًا لتعطيل ملف إعداد curl.
- حماية الوكيل `ayoub` والشركة المعروفة وإعدادات Gemini، مع السماح بعرض أسماء نماذج Gemini العادية في نصوص الواجهة.
- حصر أدوات Claude في الأدوات والمهارات التي تمت مراجعتها؛ الأدوات غير المعروفة وMCP مرفوضة افتراضيًا. `ExitPlanMode` محجوب أثناء التحليل.
- وضع `analysis` هو الافتراضي، ويمنع كل الكتابة؛ وضع `development` يقتصر على `ui/` وفق قواعد الحارس.

## تحسينات مثبت Windows
- تمرير إدخال Hook كـ UTF-8 bytes دون تحويل نصي وسيط، ورفض استبدال مشغّل موجود ومختلف دون `-UpdateExistingKitFiles` مع أخذ نسخة احتياطية عند التحديث.
- فحص Git config أيضًا داخل `HOME` و`XDG_CONFIG_HOME` وProgram Files (x86)، مع إبقاء credential helpers/URL rewrites سببًا لمنع الفحص الشبكي داخل الحارس بدل تعطيل التثبيت المحلي تلقائيًا.

- إضافة `-ValidateOnly` لفحص المتطلبات والحزمة والبيئة والمسارات وJSON وGit tracking وself-test دون كتابة في مستودع Paperclip.
- رفض مسارات UNC والمسارات النسبية، وفحص Reparse Points / symlink / junction على سلاسل المسارات قبل النسخ.
- رفض متغيرات البيئة الحساسة الخاصة بـ Git/SSH/Pager قبل تشغيل فحوص Git، مع طباعة أسماء المتغيرات فقط دون قيمها.
- استخدام `node.exe` و`git.exe` كملفات تنفيذية حقيقية مكتشفة، وتثبيت مسار Node المطلق في Hook بدل الاعتماد على PATH وقت التشغيل.
- استخدام `onFailure: "block"` و`args` لتمرير مسار الحارس دون بناء أمر shell. كما يفعّل إعدادات Claude Code الأصلية `blockReadsOutsideWorkingDirectories` و`blockWritesOutsideWorkingDirectories` بجانب وضع `plan`. الحد الأدنى المطلوب 2.1.314 (لأن حدود الكتابة الأصلية تتطلب هذا الإصدار؛ `onFailure: block` وحده يتطلب 2.1.295).
- دمج Hook الخاص بالحزمة مع الحفاظ على Hooks وإعدادات المستخدم الأخرى، دون استبدال الملف الشخصي `CLAUDE.local.md`.
- استخدام ملفات مؤقتة بنفس المجلد، نسخ احتياطية، وRollback best-effort عند الفشل؛ وإضافة الاستثناءات إلى `.git/info/exclude` دون لمس `.gitignore`.
- استخدام واجهة .NET لإنشاء المجلدات مع مسارات literal، وفحص الوجهات قبل عملية النسخ والاستعادة.

## أدلة التحقق في هذه النسخة

- `node --check .claude/hooks/pc-guard.mjs`: Passed على Linux / Node.js 22.
- `node .claude/hooks/pc-guard.mjs --selftest`: **206/206 passed على Linux**.
- `.claude/settings.local.json.NEW`: JSON صالح.
- جميع المهارات الثماني موجودة، وأسماؤها تطابق قائمة السماح في الحارس.
- `INSTALL.ps1`: تمت مراجعته ساكنًا، لكن لم يتم تشغيله أو تحليله بواسطة Windows PowerShell في بيئة البناء هذه. يجب تنفيذ `-ValidateOnly` على Windows قبل التثبيت الفعلي.
- تكامل Claude Code وHook على جهاز المالك: غير مختبر هنا.

## حدود مهمة

هذا الحارس طبقة سياسة دفاعية إضافية، وليس Sandbox أو ACL أو Firewall. ولا يمنع برنامجًا آخر أو PowerShell مستقلًا من تغيير الملفات خارج Claude Code. لا تقدّم مفاتيح حقيقية لجلسة التحليل، ولا توصل MCP قادرًا على التغيير، ولا تختبر على الحاوية أو قاعدة البيانات الحية.
