# Phase 1 — Paperclip AI Company OS Repository Audit

> Copy the prompt below into Claude Code after the kit is installed and its Windows hook checks have passed. Run Claude Code from the Paperclip repository root. This phase is analysis-only.

---

# Role and goal

You are working inside a clone of the open-source Paperclip repository.
Our goal is to build an **AI Company Operating System** on top of Paperclip.

The company is made entirely of AI employees and AI agents. There are no human employees. The only human is the Owner, who gives instructions, reviews proposals, and makes approval decisions.

The Owner can describe any kind of company. The system should propose its structure, roles, managers, AI employees, model assignments, tools, permissions, and estimated costs. The Owner reviews and edits the proposal, explicitly approves the structure, and then the system creates employees in a verified non-running state. A separate explicit Owner action launches the company. The Owner can then watch actual employee work and collaboration in a live screen.

Employees should be able to use local models (including Ollama models such as Gemma) and cloud API providers, according to verified adapter and runtime capabilities.

Paperclip remains the underlying engine for companies, agents, tasks, budgets, approvals, adapters, heartbeats, and execution. Build the Owner-facing product experience on top of its verified capabilities.

# Deployment facts — UNKNOWN means unknown

- Paperclip runs: UNKNOWN. The Owner suspects Docker on Windows, but this has not been confirmed for this audit.
- Ollama runs: UNKNOWN (Windows host / inside Docker / remote server).
- Ollama address: UNKNOWN.
- Do not infer or guess any value marked UNKNOWN. Report what repository files and non-secret configuration actually prove, then list what the Owner must confirm.

# Hard rules — apply to every phase

1. **PHASE 1 IS READ-ONLY.** Do not create, edit, move, rename, or delete files. Do not install dependencies, run migrations, start the app, start containers, start agents, invoke heartbeats, or run tests/builds that may write files. Read source and inspect read-only repository/configuration state only.
2. Allowed commands are limited to read-only inspection such as `ls`, `dir`, `cat`, `type`, `grep`, `rg` with narrow source paths, `git status`, `git rev-parse`, `git log`, `git branch` in list mode, `git tag` in list mode, `git remote` in list mode, `git ls-files`, and `docker ps`/`docker port` if relevant. Do not use shell chaining, redirects, script execution, or command wrappers.
3. Allowed network checks are limited to `git ls-remote` against a remote name already configured in `.git/config`, and HTTP GET requests to Ollama's `/api/tags` or `/api/version` endpoint only if its exact address is already known from the Deployment Facts or a non-secret config file. If unknown, do not make a network request. Never run `git fetch`, `pull`, `checkout`, `switch`, `reset`, `merge`, `rebase`, `push`, or add/remove remotes.
4. Existing agent `ayoub` is protected. Do not start, resume, pause, terminate, invoke a heartbeat for, reconfigure, hire over, or otherwise modify it or its company. Reading its configuration is allowed only when necessary. Do not experiment against a live instance containing it.
5. Do not modify any Gemini configuration, provider credentials, auth store, endpoint, model, or related config at any point unless the Owner separately and explicitly asks.
6. Never print, copy into the report, or expose API keys, tokens, passwords, cookies, credential-bearing URLs, private keys, or auth-store data. Do not read `.env`, secret files, private keys, or credential stores. Redact unexpected secrets immediately.
7. Do not modify the backend, public API, database schema, migrations, adapters, or runtime behavior. You may investigate and recommend backend work, but any such implementation requires a clear explanation and the Owner's explicit approval before a later phase.
8. Never remove or break existing Paperclip functionality. Hiding or reorganizing functionality in the UI is allowed only if the original capability remains available to authorized users.
9. Be merge-friendly. The Owner intends to pin the current baseline and integrate upstream updates selectively. Recommend an approach; do not alter Git state.
10. Do not fabricate. Do not claim that something works unless repository code or prior test evidence proves it. Because running tests is not allowed in this phase, mark runtime-dependent claims accordingly.
11. For every important technical conclusion, cite the exact repository file path and line range, API route, schema, test, or configuration evidence. Use exactly one status label: `Confirmed`, `Partially supported`, `Requires implementation`, or `Cannot be determined from the current codebase`.
12. Treat the installed skills and `pc-api-map` as navigation hints, not proof. Verify every important hint against the current checkout. Use `pc-explorer` for focused read-only investigation across multiple files. Do not invoke unapproved subagents or tools.
13. If a requested fact cannot be proven from source or permitted read-only configuration, say so. Do not attempt to discover it by starting the application or changing the environment.

# Additional critical requirements

## R1. Company creation and launch safety

The required lifecycle is:

(a) Idea submitted by Owner  
(b) Proposal generation  
(c) Owner review and editing  
(d) Explicit approval of the proposed organization  
(e) Create and configure every AI employee in a verified NON-RUNNING state  
(f) A separate explicit `Launch Company` action by the Owner  
(g) Only after successful launch may execution, dispatch, or heartbeats begin.

Investigate in source:
- Is there a non-agent planning service or a safe direct model-call path that can generate a proposal without creating, activating, scheduling, or invoking a Paperclip employee?
- Does Paperclip have a draft, paused, inactive, setup-hold, launch-hold, or equivalent state for companies and newly created agents?
- What are the defaults for newly created companies and agents? Can any agent receive a heartbeat or run immediately after creation?
- Do hire approval, setup completion, worker processing, dispatch, or heartbeat scheduling create a race window?
- Can direct API calls bypass a proposed UI-only gate?
- Is there server-side authorization and enforcement for the complete pre-launch state?

A CEO is an AI employee. Never propose creating/running a CEO before launch to generate the company plan. If no safe non-agent proposal mechanism exists, mark that part `Requires implementation` and explain the smallest backend change required. Do not suggest creating an active company and pausing it afterward. Do not claim server-side launch safety unless the route, service, worker, scheduler, and tests prove it. Identify backend changes and wait for the Owner's approval before any implementation.

## R2. Live Work accuracy

The Live Work screen must show only actual persisted records or real-time Paperclip events. Never invent agent conversations, inter-agent messages, task progress, collaboration, status, or completion.

Classify every candidate data source as:
- **Real-time:** received from a live event stream or a newly refreshed server response; show timestamp and connection/refresh state.
- **Historical:** persisted run, task, activity, comment, or audit event; show its actual event time and never label it as happening now.
- **Inferred:** derived from documented rules; label it as inferred and explain the rule.
- **Unavailable:** absent from the current API/data model; show `Not available` or omit it. Never replace it with demo content or fabricated zero/100% values.

Trace transport (WebSocket, SSE, polling, query invalidation), event types, reconnect behavior, run/heartbeat lifecycle, logs, comments, task events, audit events, and any actual inter-agent communication model.

## R3. Ollama deployment and security

Do not assume which deployment topology the Owner uses. Analyze separately:
1. Paperclip and Ollama both on the Windows host.
2. Paperclip in Docker Desktop on Windows, Ollama on the Windows host.
3. Paperclip and Ollama in containers on the same Docker network.
4. Ollama on a remote server.

For each topology, document what must be true for network connectivity, what hostname/address is appropriate, how reachability and installed-model discovery could be checked, and what firewall/network restrictions are needed. Do not assume `localhost` inside a container means the Windows host.

Verify current Ollama documentation only if permitted by the Owner's deployment facts or a known address. The general known facts to validate are: Ollama normally binds to `127.0.0.1:11434`, the bind can be changed with `OLLAMA_HOST`, and the standard Ollama server does not provide built-in API authentication. Do not advise exposing an unauthenticated endpoint to an untrusted network. Recommend isolation, host firewall restrictions, VPN, or an authenticated reverse proxy when remote access is necessary.

For model discovery, identify whether the read-only `GET /api/tags` and `GET /api/version` endpoints are appropriate. Do not call pull, delete, create, generate, chat, embeddings, or other stateful/inference endpoints during this phase.

## R4. Per-employee model configuration

Investigate whether each employee can independently configure each field:
- provider/adapter;
- model identifier;
- endpoint/base URL;
- variant or inference options;
- credentials or credential reference;
- permitted tools/capabilities;
- resource limits or budget, if available.

For every field, classify as native, partial, requires implementation, or cannot be determined. Inspect adapter schemas, registration, runtime config validation, UI forms, credential storage, and execution dispatch. Do not assume all local models support equivalent tool calling. Document relevant limits and actual adapter behavior for small local models. Do not conflate a native Ollama adapter with an OpenAI-compatible or OpenCode adapter that may connect to Ollama indirectly.

## R5. Integration and permission matrix

Produce a matrix for GitHub, browser, files, terminal/command execution, email, databases, generic APIs, Ollama, and cloud AI providers. For each, report:
- capabilities (read/write/execute/send/delete/admin);
- which AI roles genuinely need access and why;
- whether access is per employee, per company, global server config, OAuth user, or environment variable;
- scope granularity and revocation;
- credential storage and redaction/encryption;
- audit trail (actor, tool, target, timestamp, outcome);
- sandboxing and reachable host/container/network;
- native vs partial vs external integration vs unavailable.

Treat command execution and terminal access as high risk. Do not imply that a UI permission toggle creates a server-side security boundary unless the code proves enforcement.

## R6. Cost accuracy

Separate provider-reported usage/cost from estimates and unknown values. Identify which adapters expose input/output token counts, cached tokens, model pricing, or provider-reported monetary cost. Treat local inference as a distinct cost category (hardware, electricity, infrastructure estimates); do not label it as free or mix it with cloud API billing. Never invent a zero cost or infer a monetary value without a documented source.

## R7. Git and version evidence

Report local commit hash, branch, local tags, and configured remotes. If a remote version check is useful and allowed, run `git ls-remote` only against an existing configured remote name. Clearly distinguish local facts from remote facts. Do not fetch or change Git state. Treat `pc-ai-os-base` as a candidate baseline label only; verify whether it exists locally and what commit it points to. Do not move or recreate it.

# Phase 1 — Analysis only (do this now)

Study the repository and produce the report. Change nothing and do not begin implementation.

## A. Version baseline
- Commit hash, branch, local tags, configured remotes, and whether `pc-ai-os-base` exists.
- Monorepo layout, main packages/apps, languages/frameworks, package manager, documented dev/test/typecheck commands, and repository instructions.
- Do not execute dev servers, installs, builds, migrations, or tests.

## B. UI inventory
- Every user-facing page and route that can be identified from route definitions.
- Main layouts/components, design system/component library, styling approach, and routing system.
- Exact existing support for i18n, Arabic, RTL, dark/light theme, responsive breakpoints, and accessibility patterns. Distinguish full support, partial support, and absent support.

## C. Live activity
- Current real-time transport, subscriptions, polling, invalidation, and reconnect behavior.
- Available heartbeats, runs, task events, comments, logs, audit events, agent-to-agent communication, and activity records.
- Classify each source using the four R2 evidence classes.

## D. Backend and API
- API route structure, authentication, authorization, company scoping, roles, and permission checks.
- For every feature below, classify `supported`, `partial`, or `needs backend work`, with evidence:
  1. Company creation wizard following all R1 stages.
  2. Live Work screen.
  3. Organization chart and AI employee profiles, including per-employee models/tools.
  4. Tasks and projects.
  5. Approvals, budgets, usage, and costs.
  6. Integrations/tools page, including Ollama status and model discovery.
- State explicitly where server-side enforcement is missing or cannot be proven.

## E. Models and adapters
- Built-in adapters; adapter interface, registry, registration, configuration schema, and how external adapters are installed or enabled.
- Native Ollama support vs compatibility through external/OpenAI-compatible/OpenCode adapters. Explain actual limitations per R3/R4.
- Existing model-provider health and usage/cost reporting data sources.

## F. Company creation flow
- Current company creation, CEO setup, hiring, approval, worker processing, scheduling, and agent launch flow.
- Whether a CEO can create/propose hiring plans without running before Owner launch. If not, identify the missing safe planning service.
- Exact work needed for idea -> proposal -> review -> structure approval -> non-running creation -> launch.

## G. Risks
- Likely upstream merge conflict areas, UI/backend coupling, assumptions in existing docs, test coverage gaps, security/permission risks, command execution risks, credential handling, and Docker/network concerns.
- Separate proven risks from hypotheses.

# Deliverables — exact order

1. **Summary table first.** Include one row for each of A, B, C, D, E, F, G, and R1, R2, R3, R4, R5, R6, R7. Columns: topic, status label, single most important evidence path/reference, and one-line finding.
2. **Detailed report** with sections A-G and R1-R7, including the full integration/permission matrix. Cite paths and line numbers or exact route/schema/test references for each key conclusion.
3. **Minimal-change implementation plan**, in this order:
   - Step 1: company creation wizard with the full R1 lifecycle;
   - Step 2: truthful Live Work screen;
   - Step 3: AI employees and organization structure with visible per-employee model settings;
   - Step 4: tasks and projects;
   - Step 5: approvals and costs;
   - Step 6: integrations and tools, including Ollama status/model discovery.

   Place Arabic/English localization, RTL, dark/light theme, responsive design, and accessibility foundations where the verified architecture makes them safest. For every step list existing files likely to change, proposed new files/directories, backend changes (if any), approval needed, merge risk, automated/manual tests to run in a future approved phase, and rollback approach. Do not create those files now.
4. **Recommended Git plan for Owner approval:** pinned baseline commit, development branch name, correct upstream identification, and selective upstream integration strategy. Do not execute any Git mutation.
5. **Open questions for the Owner**, including every UNKNOWN from Deployment Facts and any missing information required for implementation. Do not re-ask facts already proven in the repository/configuration.
6. **Explicit stop statement:** Phase 1 is complete; no changes were made; wait for Owner approval. Do not start Phase 2.

# Later phases — context only; never start now

- Phase 2: after Owner approval, establish Git setup, safe isolated environment, UI foundations, then Step 1 only.
- Phase 3 onward: one approved step at a time. Run relevant tests only after approval, show exact command/results, review tracked/staged/untracked changes, and stop for Owner approval before the next step.

**Begin with read-only repository inspection. Do not write any file.**
