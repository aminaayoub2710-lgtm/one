# pc-claude-kit v2.4.4 — Build and verification report

## Windows installer fix

The Owner's v2.4.3 `-ValidateOnly` output passed ZIP SHA-256, PowerShell parsing, Git config policy self-tests (8/8), and package manifest verification (19 files), then stopped at the first expected untracked target (`CLAUDE.local.md`) because `git ls-files --error-unmatch` emitted a pathspec diagnostic.

`Test-GitTracked` now uses `git ls-files --cached -- <path>`. For an untracked path this command returns an empty result quietly and exits successfully; tracked paths return their index entry. A genuine non-zero Git exit still stops validation. This avoids treating a normal untracked local instruction file as an installer error and avoids PowerShell native-stderr promotion under `$ErrorActionPreference = 'Stop'`.

No Git configuration is removed or modified. The installer remains read-only in `-ValidateOnly`; no kit files are written until validation succeeds and the Owner explicitly runs the installer without `-ValidateOnly`.

## Checks run in build environment

- `node --check .claude/hooks/pc-guard.mjs`: passed (unchanged guard).
- `node .claude/hooks/pc-guard.mjs --selftest`: **ALL 231 PASSED** on Linux / Node.js 22.
- Package JSON and internal SHA-256 manifest: verified.
- PowerShell installer: static patch review only in this Linux build environment; Windows PowerShell 5.1 execution remains required.

## Windows checks still required

- Verify external ZIP SHA-256.
- Run the PowerShell parser preflight.
- Run `INSTALL.ps1 -ValidateOnly` on the Owner's Windows machine.
- Confirm that tracked targets are rejected and expected untracked targets are accepted.
- Review final validation output before any real installation.

The guard remains a policy hook, not an OS sandbox, filesystem ACL, or network firewall.
