#!/usr/bin/env node
/**
 * Paperclip AI-OS policy guard for Claude Code PreToolUse.
 *
 * IMPORTANT: this is a policy guard, not an OS sandbox. Keep Claude Code's
 * permission prompts enabled and never expose mutating MCP tools in analysis.
 * Exit 0 = allow, exit 2 = intentional deny. Internal errors fail closed.
 *
 * PC_GUARD_PHASE=analysis (default): repository inspection only.
 * PC_GUARD_PHASE=development: UI-only edits and approved test commands.
 * Optional Owner-only, one-session overrides: tooling, deps, commit, backend.
 * Do not set an override unless the Owner explicitly approved that action.
 */
import { readFileSync, realpathSync, lstatSync, readlinkSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = realpathSync(path.resolve(SCRIPT_DIR, '..', '..'));
const SEP = path.sep;
const SENSITIVE_BASENAMES = new Set([
  '.env', '.npmrc', '.pypirc', '.netrc', '.git-credentials', 'credentials', 'credentials.json',
  'secrets.json', 'secret.json', 'auth.json', 'token.json',
  'id_rsa', 'id_ed25519', 'known_hosts.old'
]);
const SAFE_ENV_EXAMPLES = new Set(['.env.example', '.env.sample', '.env.template']);
const ALLOWED_SKILLS = new Set([
  'pc-api-map', 'pc-company-launch-flow', 'pc-integration-matrix',
  'pc-live-work-rules', 'pc-provider-setup', 'pc-rtl-i18n-review',
  'pc-step-gate', 'pc-upstream-merge'
]);
const AYoub_IDS = new Set([
  '7c080b2b-6022-4855-a1d3-1b3e6bb37d7a',
  'b98d5302-d288-40f0-b46d-1ac41b6f5abf'
]);

const norm = (value) => String(value ?? '').replace(/\\/g, '/').toLowerCase();
const basename = (value) => path.basename(String(value ?? '')).toLowerCase();

function fail(message) { return { decision: 'block', reason: message }; }
function allow() { return { decision: 'allow', reason: '' }; }

function realpathThroughExistingParent(candidate, depth = 0) {
  if (depth > 40) throw new Error('Too many symlink hops while resolving a path.');
  let cursor = path.resolve(candidate);
  const tail = [];
  while (true) {
    try {
      const stat = lstatSync(cursor);
      if (stat.isSymbolicLink()) {
        const target = readlinkSync(cursor);
        const resolvedTarget = path.resolve(path.dirname(cursor), target);
        return realpathThroughExistingParent(path.resolve(resolvedTarget, ...tail), depth + 1);
      }
      const realExisting = realpathSync.native(cursor);
      return path.resolve(realExisting, ...tail);
    } catch (error) {
      if (error?.code !== 'ENOENT' && error?.code !== 'ENOTDIR') throw error;
      const parent = path.dirname(cursor);
      if (parent === cursor) return path.resolve(candidate);
      tail.unshift(path.basename(cursor));
      cursor = parent;
    }
  }
}

function resolveRepoPath(rawPath, cwd = ROOT) {
  if (typeof rawPath !== 'string' || !rawPath.trim()) return null;
  const raw = rawPath.trim().replace(/^['"]|['"]$/g, '');
  // Reject URI-like paths and device/UNC paths rather than guessing.
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(raw) || /^\\\\[?.\\]/.test(raw)) return null;
  const base = cwd && path.isAbsolute(cwd) ? cwd : ROOT;
  const candidate = path.isAbsolute(raw) ? path.resolve(raw) : path.resolve(base, raw);
  return realpathThroughExistingParent(candidate);
}

function isInsideRoot(candidate) {
  if (!candidate) return false;
  const relative = path.relative(ROOT, candidate);
  const key = relative.toLowerCase();
  return key === '' || (key !== '..' && !key.startsWith(`..${SEP}`) && !path.isAbsolute(relative));
}

function isSensitivePath(candidate) {
  if (!candidate) return false;
  const p = norm(candidate);
  const base = path.posix.basename(p);
  if (SAFE_ENV_EXAMPLES.has(base)) return false;
  if (SENSITIVE_BASENAMES.has(base)) return true;
  if (/^\.env(?:\..+)?$/i.test(base) || /(?:^|[._-])[^/]*\.env(?:\..+)?$/i.test(base)) return true;
  if (/(?:^|[._-])(?:secret|secrets|credential|credentials|token|tokens|api[-_]?key|private[-_]?key)(?:$|[._-])/i.test(base)) return true;
  if (/\.(?:pem|key|p12|pfx|keystore|jks|ppk)$/i.test(base)) return true;
  if (/(^|\/)(?:\.ssh|\.aws|\.azure|\.kube)(?:\/|$)/i.test(p)) return true;
  if (/(^|\/)\.docker\/config\.json$/i.test(p)) return true;
  if (/(^|\/)\.config\/(?:gcloud|gh)(?:\/|$)/i.test(p)) return true;
  if (/(^|\/)application_default_credentials\.json$/i.test(p)) return true;
  return false;
}

function isRestrictedBulkFile(candidate) {
  const p = norm(candidate);
  const base = path.posix.basename(p);
  return new Set(['pnpm-lock.yaml', 'package-lock.json', 'npm-shrinkwrap.json', 'yarn.lock', 'bun.lock', 'bun.lockb']).has(base)
    || /\.(?:min\.(?:js|css)|map)$/i.test(base);
}

function isSensitiveGlob(pattern) {
  if (typeof pattern !== 'string' || !pattern) return false;
  const p = norm(pattern).replace(/^!/, '');
  // Boundaries also include brace alternatives, e.g. **/{.env,*.ts}.
  if (/(?:^|[\/{,])(?:[^/]*\.)?env(?:$|[.*?}]|\/)|(?:^|[\/{,])(?:\.npmrc|\.netrc|[^/]*(?:secret|secrets|credential|token|api[-_]?key|private[-_]?key)[^/]*|id_rsa|id_ed25519|\.git-credentials)(?:$|[\/},]|[.*?])/i.test(p)) return true;
  if (/\.(?:pem|key|p12|pfx|keystore|jks|ppk)(?:$|[?*},])/i.test(p)) return true;
  return false;
}

const SAFE_SEARCH_EXTENSIONS = new Set([
  'ts', 'tsx', 'js', 'jsx', 'mjs', 'cjs', 'css', 'scss', 'html', 'md', 'mdx',
  'py', 'go', 'rs', 'sql', 'java', 'kt', 'swift', 'rb', 'php', 'vue', 'svelte',
  'graphql', 'proto'
]);
const SAFE_RG_TYPES = new Set([
  'ts', 'typescript', 'tsx', 'js', 'javascript', 'jsx', 'css', 'html', 'md',
  'markdown', 'py', 'go', 'rust', 'java', 'kotlin', 'swift', 'ruby', 'php'
]);

function isSafeSourceGlob(pattern) {
  if (typeof pattern !== 'string' || !pattern || pattern.length > 180) return false;
  const p = norm(pattern);
  if (p.startsWith('!') || p.startsWith('/') || /^[a-z]:/i.test(p) || /(?:^|\/)\.\.(?:\/|$)/.test(p)) return false;
  if (/[\[\]]/.test(p) || /(?:^|\/)\.claude(?:\/|$)|(?:^|\/)\.git(?:\/|$)/.test(p)) return false;
  if (isSensitiveGlob(p) || /\*\*?\/\*\*?$/.test(p) || p === '*' || p === '**') return false;
  let extensions = [];
  const brace = p.match(/\.\{([a-z0-9,]+)\}$/i);
  if (brace) extensions = brace[1].split(',');
  else {
    const match = p.match(/\.([a-z0-9]+)$/i);
    if (match) extensions = [match[1]];
  }
  return extensions.length > 0 && extensions.every((ext) => SAFE_SEARCH_EXTENSIONS.has(ext));
}

function isProtectedSearchRoot(candidate) {
  const p = norm(candidate);
  return /(?:^|\/)\.claude(?:\/|$)/i.test(p)
    || /(?:^|\/)\.git(?:\/|$)/i.test(p)
    || isSensitivePath(candidate)
    || isProtectedLocalConfigPath(candidate);
}

function isSafeSourceFilePath(rawPath) {
  const ext = path.posix.extname(norm(rawPath)).replace(/^\./, '');
  return SAFE_SEARCH_EXTENSIONS.has(ext);
}

function isProtectedLocalConfigPath(candidate) {
  const p = norm(candidate);
  return /(?:^|\/)\.git(?:\/|$)/i.test(p)
    || /(?:^|\/)\.claude\/settings(?:\.local)?\.json$/i.test(p)
    || /(?:^|\/)\.claude\.json$/i.test(p);
}

function hasGeminiCredentialMutation(value) {
  return /(?:GEMINI_API_KEY|GOOGLE_GENERATIVE_AI_API_KEY|GOOGLE_API_KEY)\s*[:=]/i.test(String(value ?? ''));
}

function isGeminiConfigPath(filePath) {
  const p = norm(filePath);
  const configLike = /(?:^|\/)(?:[^/]*(?:settings|config|auth|provider)[^/]*\.(?:json|jsonc|ya?ml|toml)|opencode\.(?:json|jsonc)|configlibrary)(?:$|\/)/i.test(p);
  return configLike && /gemini|google|opencode|configlibrary/i.test(p);
}

function extractPaths(tool, input) {
  const out = [];
  const add = (v) => {
    if (typeof v === 'string' && v.trim()) out.push(v);
  };
  add(input.file_path);
  add(input.notebook_path);
  add(input.path);
  add(input.directory);
  if (Array.isArray(input.edits)) for (const item of input.edits) add(item?.file_path || item?.path);
  if (Array.isArray(input.files)) for (const item of input.files) add(typeof item === 'string' ? item : item?.file_path || item?.path);
  // Grep/Glob path is the search root and must be checked just like Read.file_path.
  if (tool === 'Grep' || tool === 'Glob') add(input.path || '.');
  return [...new Set(out)];
}

function checkReadPath(tool, input, cwd) {
  const paths = extractPaths(tool, input);
  const pattern = tool === 'Glob' ? String(input.pattern ?? '') : '';
  const glob = tool === 'Grep' ? String(input.glob ?? '') : '';
  const safeCwd = resolveRepoPath('.', cwd);
  if (!safeCwd || !isInsideRoot(safeCwd)) return fail('PC-GUARD: working directory is outside the repository.');
  if (tool === 'Read' && paths.length === 0) return fail('PC-GUARD: Read did not provide a file path; blocked by default.');
  if (tool === 'Grep' && (!input.path || typeof input.path !== 'string')) return fail('PC-GUARD: Grep must name an explicit repository path; unscoped searches are blocked.');
  if (tool === 'Glob' && !pattern) return fail('PC-GUARD: Glob did not provide a search pattern; blocked by default.');
  if (isSensitiveGlob(pattern) || isSensitiveGlob(glob)) return fail('PC-GUARD: search pattern can target credential/secret files.');
  if (tool === 'Glob' && !isSafeSourceGlob(pattern)) return fail('PC-GUARD: Glob is limited to explicit source/document extensions; broad, hidden, brace-sensitive, and parent-traversal patterns are blocked.');
  for (const raw of paths) {
    const resolved = resolveRepoPath(raw, cwd);
    if (!resolved || !isInsideRoot(resolved)) {
      return fail(`PC-GUARD: read path is outside the repository or cannot be safely resolved: ${raw}`);
    }
    if (isSensitivePath(resolved) || isProtectedLocalConfigPath(resolved)) {
      return fail('PC-GUARD: credential, local Claude settings, and Git-internal files are off limits. Use approved read-only Git commands for repository metadata.');
    }
    if (tool === 'Read' && isRestrictedBulkFile(resolved)) return fail('PC-GUARD: large lockfiles, minified bundles, and source maps are excluded from routine analysis; inspect manifests or source files instead.');
    if ((tool === 'Grep' || tool === 'Glob') && isProtectedSearchRoot(resolved)) return fail('PC-GUARD: Grep/Glob may not search inside .claude, .git, or protected directories; read individual approved files instead.');
    if (/(^|[\\/])node_modules([\\/]|$)/i.test(resolved)) {
      return fail('PC-GUARD: do not read node_modules; inspect the source package instead.');
    }
  }
  if (tool === 'Grep') {
    const basePath = resolveRepoPath(input.path, cwd);
    if (glob) {
      if (!isSafeSourceGlob(glob)) return fail('PC-GUARD: Grep glob must restrict search to approved source/document extensions (for example **/*.ts or **/*.md).');
    } else if (!isSafeSourceFilePath(input.path)) {
      return fail('PC-GUARD: directory searches require an explicit safe source/document glob; exact file searches must name an approved source/document extension.');
    }
    if (!basePath || isProtectedSearchRoot(basePath)) return fail('PC-GUARD: Grep base path is protected or cannot be safely resolved.');
  }
  if (tool === 'Glob') {
    const basePath = resolveRepoPath(input.path || '.', cwd);
    if (!basePath || !isInsideRoot(basePath)) return fail('PC-GUARD: Glob base path is outside the repository.');
    if (isProtectedSearchRoot(basePath)) return fail('PC-GUARD: Glob cannot search protected directories.');
  }
  return allow();
}

function checkWritePath(tool, input, cwd, phase, overrides) {
  const paths = extractPaths(tool, input);
  if (paths.length === 0) return fail(`PC-GUARD: ${tool} did not provide a verifiable target path; blocked by default.`);
  for (const raw of paths) {
    const resolved = resolveRepoPath(raw, cwd);
    if (!resolved || !isInsideRoot(resolved)) {
      return fail(`PC-GUARD: write path is outside the repository or cannot be safely resolved: ${raw}`);
    }
    if (isSensitivePath(resolved)) return fail('PC-GUARD: writes to secret/credential files are permanently blocked.');
    if (isProtectedLocalConfigPath(resolved)) return fail('PC-GUARD: local settings and Git internals are protected from direct file access.');
    if (/(^|[\\/])node_modules([\\/]|$)/i.test(resolved)) return fail('PC-GUARD: never modify node_modules.');
    if (/(^|[\\/])\.git([\\/]|$)/i.test(resolved)) return fail('PC-GUARD: never edit Git internals.');
    if (isGeminiConfigPath(resolved)) return fail('PC-GUARD: Gemini/provider configuration is Owner-managed and protected.');
    const relative = path.relative(ROOT, resolved).replace(/\\/g, '/');
    const underUi = /^ui\//i.test(relative);
    const toolingFile = /^\.claude\/(?:skills|agents)\//i.test(relative) || relative === 'CLAUDE.local.md';
    const backendFile = /^(?:server|packages|cli|docker|scripts|migrations|db)\//i.test(relative);
    const dependencyFile = /(?:^|\/)(?:package\.json|pnpm-lock\.yaml|package-lock\.json|npm-shrinkwrap\.json|yarn\.lock|bun\.lockb?|pnpm-workspace\.yaml)$/i.test(relative);
    if (phase === 'analysis') return fail('PC-GUARD: Phase 1 is READ-ONLY. No file edits or writes are allowed. Wait for Owner approval and a new development session.');
    if (dependencyFile) {
      if (overrides.has('deps')) continue;
      return fail('PC-GUARD: dependency manifests and lockfiles require explicit Owner approval and PC_GUARD_ALLOW=deps in a new session.');
    }
    if (underUi) continue;
    if (toolingFile && overrides.has('tooling')) continue;
    if (backendFile && overrides.has('backend')) continue;
    return fail(`PC-GUARD: write outside the approved UI scope is blocked: ${relative}. Backend work requires explicit Owner approval and PC_GUARD_ALLOW=backend in a new session.`);
  }
  const payload = JSON.stringify(input);
  if (hasGeminiCredentialMutation(payload)) return fail('PC-GUARD: edits containing provider credential assignments are Owner-managed.');
  if (isGeminiConfigPath(paths[0]) && /(?:gemini|google)/i.test(payload)) return fail('PC-GUARD: Gemini/provider configuration files are Owner-managed. UI labels and model names in ordinary UI components are allowed.');
  return allow();
}

function hasDynamicExpansion(raw) {
  let quote = null;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (quote) {
      if (ch === quote) quote = null;
      else if (quote === '"' && ch === '$') return true;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
    } else {
      if (ch === '$') return true;
      if (ch === '%' && /[A-Za-z_]/.test(raw[i + 1] || '')) {
        const close = raw.indexOf('%', i + 1);
        if (close > i + 1 && /^[A-Za-z_][A-Za-z0-9_]*$/.test(raw.slice(i + 1, close))) return true;
      }
      if (ch === '~' && (i === 0 || /\s/.test(raw[i - 1])) && (raw[i + 1] === '/' || raw[i + 1] === '\\' || !raw[i + 1])) return true;
    }
  }
  return false;
}

function tokenizeCommand(command) {
  const raw = String(command ?? '').trim();
  if (!raw) return null;
  // No chaining, redirection, command substitution, variable/home expansion,
  // command grouping, or multiline scripts. Single-quoted literals remain safe.
  if (/[\r\n;|&<>`]/.test(raw) || hasDynamicExpansion(raw) || /\$[({]/.test(raw)) return null;
  if (/(^|\s)(?:sudo|su|cmd(?:\.exe)?\s+\/c|powershell(?:\.exe)?\s+-(?:command|enc|encodedcommand)|pwsh\s+-(?:command|enc|encodedcommand))\b/i.test(raw)) return null;
  const tokens = [];
  let current = '';
  let quote = null;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (quote) {
      if (ch === quote) quote = null;
      else current += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
    } else if (/\s/.test(ch)) {
      if (current) { tokens.push(current); current = ''; }
    } else {
      current += ch;
    }
  }
  if (quote) return null;
  if (current) tokens.push(current);
  return tokens;
}

function readGitConfig() {
  try { return readFileSync(path.join(ROOT, '.git', 'config'), 'utf8'); }
  catch { return ''; }
}

function getConfiguredRemoteNames() {
  const gitConfig = readGitConfig();
  return new Set([...gitConfig.matchAll(/^\s*\[remote\s+"([^"]+)"\]/gmi)].map((m) => m[1].toLowerCase()));
}

function configuredRemoteHasEmbeddedCredentials() {
  const gitConfig = readGitConfig();
  return /https?:\/\/[^\s/]+@/i.test(gitConfig) || /(?:access[_-]?token|password|oauth[_-]?token|api[_-]?key|secret|auth)=/i.test(gitConfig) || /(?:^|\s)url\s*=\s*[^\s?]+\?[^\s]*/i.test(gitConfig);
}

function parseGitInvocation(tokens, cwd) {
  let i = 1;
  while (i < tokens.length) {
    const token = tokens[i];
    if (token === '-C') {
      const target = resolveRepoPath(tokens[i + 1] || '', cwd);
      if (!target || !isInsideRoot(target)) return { error: 'PC-GUARD: git -C may only target a directory inside this repository.' };
      i += 2;
      continue;
    }
    if (token === '--no-pager' || token === '--no-optional-locks') { i++; continue; }
    // Deny all other global Git flags. In particular -c/--config-env/--exec-path
    // can alter execution or configuration before the subcommand is parsed.
    if (token.startsWith('-')) return { error: `PC-GUARD: Git global option ${token} is not permitted.` };
    return { command: token.toLowerCase(), args: tokens.slice(i + 1) };
  }
  return { command: '', args: [] };
}

function onlyAllowedArgs(args, allowedFlags, valueFlags = new Set()) {
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (valueFlags.has(arg)) {
      if (!args[i + 1] || args[i + 1].startsWith('-')) return false;
      i++;
      continue;
    }
    if (arg.startsWith('--') && arg.includes('=')) {
      const key = arg.slice(0, arg.indexOf('='));
      if (!allowedFlags.has(key)) return false;
      continue;
    }
    if (arg.startsWith('-') && !allowedFlags.has(arg)) return false;
  }
  return true;
}

function checkGitDiffSafety(args, cwd) {
  // `git diff` without a summary flag can print the contents of every changed
  // tracked file, including a tracked .env. Content output is therefore allowed
  // only for explicit, literal UI source/document paths. Summary-only output is
  // safe without pathspecs because it does not print file contents.
  const summaryFlags = new Set(['--name-only', '--name-status', '--stat', '--numstat', '--shortstat']);
  const summaryOnly = args.some((arg) => summaryFlags.has(arg));
  const separator = args.indexOf('--');
  const pathspecs = separator >= 0 ? args.slice(separator + 1) : [];

  if (separator >= 0 && pathspecs.length === 0) {
    return fail('PC-GUARD: git diff -- requires at least one explicit, safe UI path; otherwise use a summary flag such as --stat or --name-only.');
  }

  // Any token after `--` is a Git pathspec, not a revision. Do not accept Git
  // pathspec magic, wildcards, absolute paths, traversal, or paths outside ui/.
  for (const rawPath of pathspecs) {
    if (typeof rawPath !== 'string' || !rawPath || rawPath.startsWith(':(')
      || /[*?\[\]{}]/.test(rawPath) || rawPath.startsWith('/') || /^[a-z]:/i.test(rawPath)
      || /(?:^|[\\/])\.\.(?:[\\/]|$)/.test(rawPath)) {
      return fail('PC-GUARD: git diff pathspecs must be literal repository-relative UI files; Git pathspec magic, wildcard, absolute, and traversal paths are blocked.');
    }
    const resolved = resolveRepoPath(rawPath, cwd);
    if (!resolved || !isInsideRoot(resolved)) return fail(`PC-GUARD: git diff pathspec is outside the repository: ${rawPath}`);
    const relative = path.relative(ROOT, resolved).replace(/\\/g, '/');
    if (!/^ui\//i.test(relative) || !isSafeSourceFilePath(relative)
      || isSensitivePath(resolved) || isProtectedLocalConfigPath(resolved)
      || isRestrictedBulkFile(resolved) || /(^|\/)node_modules(\/|$)/i.test(relative)) {
      return fail(`PC-GUARD: git diff content is limited to explicit, non-sensitive UI source/document files: ${rawPath}`);
    }
  }

  if (!summaryOnly && pathspecs.length > 0 && !args.includes('--no-textconv')) {
    return fail('PC-GUARD: raw-content git diff must include --no-textconv so configured text conversion programs cannot run.');
  }
  if (!summaryOnly && pathspecs.length === 0) {
    return fail('PC-GUARD: unrestricted git diff may print secrets from any changed tracked file. Use --stat/--name-only or specify a safe UI file after --.');
  }
  return allow();
}

function checkGit(tokens, overrides, context = {}, cwd = ROOT, phase = 'analysis') {
  const parsed = parseGitInvocation(tokens, cwd);
  if (parsed.error) return fail(parsed.error);
  const { command: sub, args } = parsed;
  const blocked = new Set(['fetch', 'pull', 'merge', 'rebase', 'push', 'cherry-pick', 'revert', 'am', 'reset', 'clean', 'switch', 'checkout', 'worktree', 'filter-branch', 'update-ref', 'gc', 'prune', 'config', 'credential', 'submodule']);
  if (blocked.has(sub)) return fail(`PC-GUARD: git ${sub} is blocked. The Owner manages upstream and destructive Git operations.`);
  if (sub === 'commit' && phase === 'analysis') return fail('PC-GUARD: commits are forbidden during the read-only analysis phase.');
  if (sub === 'commit' && !overrides.has('commit')) return fail('PC-GUARD: commits require explicit Owner approval and PC_GUARD_ALLOW=commit in a new session.');
  const readOnly = new Set(['status', 'rev-parse', 'log', 'branch', 'tag', 'remote', 'ls-files', 'ls-remote', 'version', 'describe', 'diff']);
  if (!readOnly.has(sub) && !(sub === 'commit' && overrides.has('commit'))) return fail(`PC-GUARD: git ${sub || '(unknown)'} is not on the read-only allowlist.`);

  const simpleFlags = {
    status: new Set(['--short', '-s', '--branch', '-b', '--porcelain', '--untracked-files', '--ignore-submodules', '--no-renames']),
    'rev-parse': new Set(['--show-toplevel', '--show-prefix', '--is-inside-work-tree', '--is-bare-repository', '--abbrev-ref', '--short', '--verify', '--symbolic-full-name']),
    log: new Set(['--oneline', '--decorate', '--all', '--graph', '--no-decorate', '--first-parent', '--no-merges', '--merges', '--reverse', '--topo-order', '--date-order']),
    branch: new Set(['-a', '-r', '-v', '-vv', '--all', '--remotes', '--list', '--show-current', '--verbose']),
    tag: new Set(['-l', '--list', '--contains', '--points-at', '--merged', '--no-merged', '-n', '--sort']),
    remote: new Set(['-v', '--verbose']),
    'ls-files': new Set(['--cached', '--others', '--stage', '--error-unmatch', '--full-name', '--deduplicate', '--modified', '--deleted', '--unmerged', '--killed', '--resolve-undo', '--exclude-standard']),
    'ls-remote': new Set(['--heads', '--tags', '--refs', '--symref', '--quiet', '-q', '--exit-code']),
    version: new Set([]),
    describe: new Set(['--tags', '--always', '--dirty', '--long', '--exact-match']),
    diff: new Set(['--name-only', '--name-status', '--stat', '--numstat', '--shortstat', '--check', '--no-ext-diff', '--no-textconv', '--no-renames', '--cached', '--staged', '--merge-base', '--relative', '--'])
  };
  if (sub === 'commit') return fail('PC-GUARD: do not commit through the Claude Code hook; the Owner commits manually after reviewing the full diff.');
  if (sub === 'remote') {
    if (args.some((a) => !['-v', '--verbose'].includes(a))) return fail('PC-GUARD: git remote permits listing only; adding/changing/removing remotes is blocked.');
    const containsSecrets = context.remoteHasCredentials ?? configuredRemoteHasEmbeddedCredentials();
    if (containsSecrets) return fail('PC-GUARD: git remote -v is blocked because a configured URL may contain embedded credentials. Use `git remote` for names only.');
  } else if (sub === 'ls-remote') {
    const remotes = context.remoteNames || getConfiguredRemoteNames();
    const remoteArg = args.find((a) => !a.startsWith('-'));
    if (!remoteArg || !remotes.has(remoteArg.toLowerCase())) return fail('PC-GUARD: git ls-remote is allowed only for a configured remote name.');
    if (configuredRemoteHasUnsafeTransport(remoteArg, context)) return fail('PC-GUARD: git ls-remote is blocked for non-HTTPS, rewritten, or command-backed remote configurations.');
    if (args.some((a) => a.startsWith('--upload-pack') || a.startsWith('--exec'))) return fail('PC-GUARD: custom Git upload/exec commands are blocked.');
  } else if (sub === 'branch') {
    if (args.some((a) => /^-[dDmMcCfF]$/.test(a) || ['--delete', '--move', '--copy', '--force'].includes(a))) return fail('PC-GUARD: git branch is allowed only in list/read-only mode.');
    if (args.some((a) => !simpleFlags.branch.has(a) && !a.startsWith('--sort='))) return fail('PC-GUARD: git branch accepts list-only flags.');
  } else if (sub === 'tag') {
    if (args.some((a) => ['-a', '-s', '-u', '-m', '-f', '-d', '--delete', '--force'].includes(a))) return fail('PC-GUARD: git tag creation and deletion are blocked.');
    if (args.some((a) => !simpleFlags.tag.has(a) && !a.startsWith('--sort='))) return fail('PC-GUARD: git tag accepts list-only options.');
  } else {
    const allowed = simpleFlags[sub] || new Set();
    const argsOk = args.every((a) => {
      if (sub === 'log' && /^-\d+$/.test(a)) return true;
      if (allowed.has(a) || !a.startsWith('-')) return true;
      if (a.startsWith('--') && a.includes('=')) return allowed.has(a.slice(0, a.indexOf('=')));
      return false;
    });
    if (!argsOk) return fail(`PC-GUARD: unsupported or unsafe arguments to git ${sub}.`);
    if (args.some((a) => ['--untracked-files', '--ignore-submodules', '--abbrev-ref'].includes(a))) {
      for (let i = 0; i < args.length; i++) {
        if (['--untracked-files', '--ignore-submodules', '--abbrev-ref'].includes(args[i])) {
          if (!args[i + 1] || args[i + 1].startsWith('-')) return fail(`PC-GUARD: git ${sub} option ${args[i]} requires a safe value.`);
          i++;
        }
      }
    }
  }
  if (sub === 'diff') {
    if (args.some((a) => ['--ext-diff', '--textconv', '--output', '--output='].includes(a) || a.startsWith('--output='))) {
      return fail('PC-GUARD: external diff/textconv and output-file options are blocked.');
    }
    const safety = checkGitDiffSafety(args, cwd);
    if (safety.decision === 'block') return safety;
  }
  if (sub === 'ls-remote' && args.some((a) => a.startsWith('-'))) {
    const safe = new Set(['--heads', '--tags', '--refs', '--symref', '--quiet', '-q', '--exit-code']);
    if (args.some((a) => a.startsWith('-') && !safe.has(a))) return fail('PC-GUARD: unsupported git ls-remote options.');
  }
  return allow();
}

function parseRemoteConfig(configOverride = null) {
  const config = typeof configOverride === 'string' ? configOverride : readGitConfig();
  const remotes = new Map();
  let section = '';
  for (const line of config.split(/\r?\n/)) {
    const sectionMatch = line.match(/^\s*\[remote\s+"([^"]+)"\]\s*$/i);
    if (sectionMatch) { section = sectionMatch[1].toLowerCase(); if (!remotes.has(section)) remotes.set(section, {}); continue; }
    if (/^\s*\[/.test(line)) { section = ''; continue; }
    if (!section) continue;
    const entry = line.match(/^\s*(url|vcs|uploadpack)\s*=\s*(.*?)\s*$/i);
    if (entry) remotes.get(section)[entry[1].toLowerCase()] = entry[2];
  }
  return remotes;
}

function isApprovedStockGitExecutionEntry(section, key, value) {
  // Narrow exceptions for the exact stock Git for Windows `astextplain`
  // driver and standard Git LFS filters. Do not allow arbitrary commands in
  // custom diff/filter sections or modified LFS command strings.
  const sectionName = String(section || '').replace(/\s+/g, ' ').trim().toLowerCase();
  const keyName = String(key || '').trim().toLowerCase();
  const valueName = String(value || '').replace(/\s+/g, ' ').trim().toLowerCase();
  if (sectionName === 'diff "astextplain"' && keyName === 'textconv' && valueName === 'astextplain') return true;
  if (sectionName === 'filter "lfs"') {
    if (keyName === 'clean' && valueName === 'git-lfs clean -- %f') return true;
    if (keyName === 'smudge' && valueName === 'git-lfs smudge -- %f') return true;
    if (keyName === 'process' && valueName === 'git-lfs filter-process') return true;
  }
  return false;
}

function hasUnsafeGitExecutionConfig(text) {
  // Reject configurable execution hooks, except the exact stock Git for Windows
  // astextplain textconv and Git LFS filter entries. Raw-content git diff must
  // explicitly disable textconv; credential/network commands remain restricted.
  let section = '';
  for (const line of String(text || '').split(/\r?\n/)) {
    const match = line.match(/^\s*\[([^\]]+)\]\s*$/);
    if (match) {
      section = match[1].toLowerCase().trim();
      if (/^(?:include|includeif|pager|fsmonitor)(?:\s|$)/.test(section)) return true;
      continue;
    }
    const entry = line.match(/^\s*([a-z][a-z0-9.-]*)\s*=\s*(.*?)\s*$/i);
    if (!entry) continue;
    const key = entry[1].toLowerCase();
    const value = entry[2].trim().toLowerCase();
    const baseSection = section.replace(/\s+["'][^"']*["']\s*$/, '').trim();
    if (baseSection === 'core' && ['fsmonitor', 'pager'].includes(key) && !['false', 'no', '0', ''].includes(value)) return true;
    if (baseSection === 'diff' && ['external', 'textconv', 'command'].includes(key) && !['false', 'no', '0', ''].includes(value)) {
      if (isApprovedStockGitExecutionEntry(section, key, value)) continue;
      return true;
    }
    if (baseSection === 'filter' && ['process', 'smudge', 'clean'].includes(key) && value) {
      if (isApprovedStockGitExecutionEntry(section, key, value)) continue;
      return true;
    }
  }
  return false;
}

function gitConfigCandidatePaths() {
  const home = String(process.env.HOME || process.env.USERPROFILE || '').trim();
  const xdg = String(process.env.XDG_CONFIG_HOME || (home ? path.join(home, '.config') : '')).trim();
  return [
    path.join(ROOT, '.git', 'config'),
    home ? path.join(home, '.gitconfig') : '',
    xdg ? path.join(xdg, 'git', 'config') : '',
    process.env.PROGRAMDATA ? path.join(process.env.PROGRAMDATA, 'Git', 'config') : '',
    process.env.ProgramFiles ? path.join(process.env.ProgramFiles, 'Git', 'etc', 'gitconfig') : ''
  ].filter(Boolean);
}

function hasUnsafeGitExecutionConfigAnywhere(context = {}) {
  if (typeof context.gitExecutionConfigText === 'string') return hasUnsafeGitExecutionConfig(context.gitExecutionConfigText);
  for (const configPath of gitConfigCandidatePaths()) {
    try { if (hasUnsafeGitExecutionConfig(readFileSync(configPath, 'utf8'))) return true; } catch { /* absent or inaccessible config is not printed */ }
  }
  return false;
}

function hasUnsafeGitConfig(text) {
  // `ls-remote` can indirectly execute credential helpers and custom transport,
  // pager, diff, fsmonitor, filter, or URL-rewrite commands from Git config.
  // Be conservative: if these settings are present, do not run Git remotely.
  return /^\s*\[(?:url\s+|include\s*\]|includeif\s+)/im.test(text)
    || /^\s*(?:insteadOf|path|uploadpack|vcs|helper|sshcommand|pager|external|textconv|process|smudge|clean|fsmonitor|askpass|proxy|extraheader)\s*=/im.test(text)
    || /^\s*\[(?:credential|diff|filter|fsmonitor|pager|http)(?:\s+|\])/im.test(text)
    || /^\s*\[(?:core)\]/im.test(text) && /^\s*(?:sshcommand|pager|fsmonitor)\s*=/im.test(text);
}

function configuredRemoteHasUnsafeTransport(remoteName, context = {}) {
  const gitConfig = typeof context.remoteConfigText === 'string' ? context.remoteConfigText : readGitConfig();
  if (hasUnsafeGitConfig(gitConfig)) return true;
  const home = String(process.env.HOME || process.env.USERPROFILE || '').trim();
  const xdg = String(process.env.XDG_CONFIG_HOME || (home ? path.join(home, '.config') : '')).trim();
  const candidateConfigs = [
    home ? path.join(home, '.gitconfig') : '',
    xdg ? path.join(xdg, 'git', 'config') : '',
    process.env.PROGRAMDATA ? path.join(process.env.PROGRAMDATA, 'Git', 'config') : '',
    process.env.ProgramFiles ? path.join(process.env.ProgramFiles, 'Git', 'etc', 'gitconfig') : ''
  ].filter(Boolean);
  for (const configPath of candidateConfigs) {
    try { if (hasUnsafeGitConfig(readFileSync(configPath, 'utf8'))) return true; } catch { /* absent or inaccessible configs are not printed */ }
  }
  const remote = parseRemoteConfig(gitConfig).get(String(remoteName).toLowerCase());
  if (!remote || !remote.url || remote.vcs || remote.uploadpack) return true;
  try {
    const url = new URL(remote.url);
    return !['https:', 'http:'].includes(url.protocol) || !!url.username || !!url.password || !!url.search || !!url.hash;
  } catch { return true; }
}

function isAllowedOllamaGet(tokens, env, tool) {
  const configured = String(env.PC_OLLAMA_URL || '').trim();
  if (!configured) return false;
  const executable = basename(tokens[0]);
  if (!['curl', 'curl.exe'].includes(executable)) return false;
  // In Windows PowerShell, `curl` can be an alias for Invoke-WebRequest;
  // require the native executable by its explicit name.
  if (tool === 'PowerShell' && executable !== 'curl.exe') return false;
  const urls = tokens.filter((t) => /^https?:\/\//i.test(t));
  if (urls.length !== 1) return false;
  try {
    const actual = new URL(urls[0]);
    const base = new URL(configured);
    const validBase = base.pathname === '/' && base.search === '' && base.hash === '' && !base.username && !base.password && !actual.username && !actual.password;
    const validPath = ['/api/tags', '/api/version'].includes(actual.pathname.replace(/\/$/, ''));
    if (!validBase || !validPath || actual.origin !== base.origin || actual.search !== '' || actual.hash !== '') return false;

    const rawArgs = tokens.slice(1);
    // --disable must be the first curl argument, before URL or any option,
    // so user-level .curlrc/_curlrc files cannot alter the request.
    if (rawArgs[0] !== '--disable') return false;
    const args = rawArgs.slice(1).filter((t) => t !== urls[0]);
    for (let i = 1; i < args.length; i++) {
      const arg = args[i];
      if (/^-[fsS]+$/.test(arg) || ['--fail', '--silent', '--show-error'].includes(arg)) continue;
      if (['--max-time', '--connect-timeout'].includes(arg) && /^\d+(?:\.\d+)?$/.test(args[i + 1] || '')) { i++; continue; }
      // No custom methods, data, headers, cookies, output, redirects or config files.
      return false;
    }
    return true;
  } catch { return false; }
}

function validatePowerShellRead(tokens, cwd) {
  const exe = basename(tokens[0]).replace(/\.exe$/i, '');
  const args = tokens.slice(1);
  if (['get-location', 'pwd'].includes(exe)) return args.length === 0 ? allow() : fail('PC-GUARD: Get-Location/pwd accepts no arguments in the safe PowerShell profile.');
  if (['get-content', 'cat', 'type'].includes(exe)) {
    let pathValue = null;
    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      if (arg.toLowerCase() === '-raw') continue;
      if (['-literalpath', '-path'].includes(arg.toLowerCase())) {
        if (pathValue !== null || !args[i + 1]) return fail('PC-GUARD: PowerShell content readers require exactly one explicit path.');
        pathValue = args[++i];
        continue;
      }
      if (arg.startsWith('-')) return fail(`PC-GUARD: PowerShell content-reader option ${arg} is not allowed.`);
      if (pathValue !== null) return fail('PC-GUARD: PowerShell content readers accept only one path.');
      pathValue = arg;
    }
    if (!pathValue) return fail('PC-GUARD: PowerShell content readers require one explicit file path.');
    if (/^[A-Za-z][A-Za-z0-9_-]*:(?![\\/])/i.test(pathValue)) return fail('PC-GUARD: PowerShell provider paths (Env:, Registry:, Variable:, Cert:, etc.) are blocked.');
    return validateReadCommandPaths([tokens[0], pathValue], cwd);
  }
  if (['get-childitem', 'ls', 'dir'].includes(exe)) {
    let pathValue = '.';
    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      if (['-literalpath', '-path'].includes(arg.toLowerCase())) {
        if (!args[i + 1] || pathValue !== '.') return fail('PC-GUARD: Get-ChildItem accepts only one explicit path.');
        pathValue = args[++i];
        continue;
      }
      if (arg.startsWith('-')) return fail(`PC-GUARD: PowerShell directory option ${arg} is not permitted (recursion/force and provider switches are blocked).`);
      if (pathValue !== '.') return fail('PC-GUARD: Get-ChildItem accepts only one path.');
      pathValue = arg;
    }
    if (/^[A-Za-z][A-Za-z0-9_-]*:(?![\\/])/i.test(pathValue)) return fail('PC-GUARD: PowerShell provider paths are blocked.');
    if (/[*?]/.test(pathValue)) return fail('PC-GUARD: wildcard directory enumeration is blocked in the strict PowerShell profile.');
    return validateReadCommandPaths([tokens[0], pathValue], cwd);
  }
  return fail('PC-GUARD: PowerShell reader command is not on the strict read-only allowlist.');
}

function validateReadCommandPaths(tokens, cwd) {
  const executable = basename(tokens[0]);
  const contentReaders = new Set(['cat', 'type', 'get-content', 'head', 'tail', 'more', 'less', 'wc']);
  if (executable === 'wc' && tokens.some((t) => /^--files0/i.test(t))) return fail('PC-GUARD: wc --files0-from is blocked.');
  if (['ls', 'dir'].includes(executable) && tokens.slice(1).some((token) => token === '-R' || token === '--recursive' || /^-[^-]*R/.test(token))) {
    return fail('PC-GUARD: recursive directory listings are blocked; inspect one directory at a time.');
  }
  if (executable === 'tail' && tokens.slice(1).some((token) => ['-f', '-F', '--follow', '--retry'].includes(token) || token.startsWith('--follow='))) {
    return fail('PC-GUARD: follow-mode tail is blocked because it can remain running indefinitely.');
  }
  for (const token of tokens.slice(1)) {
    if (contentReaders.has(executable) && /[*?]/.test(token)) return fail('PC-GUARD: wildcard content reads are blocked; name one exact file at a time.');
    if (isSensitiveGlob(token)) return fail('PC-GUARD: command references a credential/secret file pattern.');
    if (/^~/.test(token) || /^[A-Za-z][A-Za-z0-9_-]*:(?![\/])/i.test(token)) return fail('PC-GUARD: home expansion and non-filesystem provider paths are blocked.');
    if (/^-/i.test(token)) continue;
    if (isSensitivePath(token)) return fail('PC-GUARD: command references a credential/secret file.');
    if (isRestrictedBulkFile(token)) return fail('PC-GUARD: package lockfiles, minified bundles, and source maps are excluded from analysis reads.');
    if (token === '.' || token === '..' || token.includes('/') || token.includes('\\') || /^[a-z]:/i.test(token)) {
      const resolved = resolveRepoPath(token, cwd);
      if (!resolved || !isInsideRoot(resolved)) return fail(`PC-GUARD: shell read path is outside the repository: ${token}`);
      if (isSensitivePath(resolved) || isProtectedLocalConfigPath(resolved)) return fail('PC-GUARD: command references a protected local/Git configuration file.');
      if (/(^|[\\/])node_modules([\\/]|$)/i.test(resolved)) return fail('PC-GUARD: node_modules access is blocked.');
    }
  }
  return allow();
}

// Parse search tools using a restrictive option allowlist. Options that read an
// external patterns file or launch a preprocessor are never accepted.
function checkSearchCommand(exe, tokens, cwd, env) {
  const name = exe.replace(/\.exe$/i, '');
  if (!['rg', 'grep', 'egrep', 'fgrep', 'select-string', 'findstr'].includes(name)) return null;
  const args = tokens.slice(1);
  const positional = [];
  if (name === 'select-string') {
    let pathSeen = false;
    let patternSeen = false;
    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      if (/^-?(?:Path|LiteralPath)$/i.test(arg)) {
        const value = args[++i];
        if (!value || /[*?]/.test(value)) return fail('PC-GUARD: Select-String requires one exact -Path/-LiteralPath value; wildcards are blocked.');
        const resolved = resolveRepoPath(value, cwd);
        if (!resolved || !isInsideRoot(resolved) || isProtectedSearchRoot(resolved) || /(^|[\\/])node_modules([\\/]|$)/i.test(resolved) || !isSafeSourceFilePath(value)) return fail('PC-GUARD: Select-String requires one approved source/document file path.');
        pathSeen = true;
        continue;
      }
      if (/^-Pattern$/i.test(arg)) {
        if (!args[i + 1]) return fail('PC-GUARD: Select-String -Pattern requires a value.');
        i++;
        patternSeen = true;
        continue;
      }
      if (/^-(?:SimpleMatch|CaseSensitive|List|Quiet|AllMatches|NotMatch|NoEmphasis)$/i.test(arg)) continue;
      return fail(`PC-GUARD: Select-String option ${arg} is not permitted; recursion, include/exclude files, and pattern-file options are blocked.`);
    }
    return pathSeen && patternSeen ? allow() : fail('PC-GUARD: Select-String requires explicit -Path and -Pattern values.');
  }
  if (name === 'findstr') {
    let sawPattern = false;
    let sawPath = false;
    for (const arg of args) {
      if (/^\/(?:s|g:|f:|off|p|a:)/i.test(arg)) return fail(`PC-GUARD: findstr option ${arg} is not permitted (recursive and pattern/file-list options are blocked).`);
      if (/^\/[inlrxc]/i.test(arg)) continue;
      if (!sawPattern) { sawPattern = true; continue; }
      if (/[*?]/.test(arg)) return fail('PC-GUARD: wildcard file arguments are blocked for findstr.');
      const resolved = resolveRepoPath(arg, cwd);
      if (!resolved || !isInsideRoot(resolved) || isProtectedSearchRoot(resolved) || /(^|[\\/])node_modules([\\/]|$)/i.test(resolved) || !isSafeSourceFilePath(arg)) return fail('PC-GUARD: findstr requires approved source/document files.');
      sawPath = true;
    }
    return sawPattern && sawPath ? allow() : fail('PC-GUARD: findstr requires a search pattern and explicit repository file path.');
  }
  const globOptions = new Set(['-g', '--glob', '--iglob']);
  let safeGlobFilter = false;
  let safeTypeFilter = false;
  const valueOptions = name === 'rg'
    ? new Set(['-g', '--glob', '--iglob', '-m', '--max-count', '-A', '--after-context', '-B', '--before-context', '-C', '--context', '-t', '--type'])
    : new Set();
  const allowedLong = name === 'rg'
    ? new Set(['--no-config', '--line-number', '--ignore-case', '--fixed-strings', '--word-regexp', '--line-regexp', '--invert-match', '--files-with-matches', '--files-without-match', '--count', '--count-matches', '--heading', '--no-heading', '--glob-case-insensitive', '--color'])
    : new Set(['--line-number', '--ignore-case', '--fixed-strings', '--word-regexp', '--line-regexp', '--invert-match', '--extended-regexp', '--basic-regexp', '--perl-regexp', '--color']);
  // ripgrep's -L means --follow (follow symbolic links), unlike grep's -L
  // which means files-without-matches. Never allow rg -L in a repository guard.
  const allowedShort = name === 'rg'
    ? new Set(['-n', '-i', '-F', '-w', '-x', '-v', '-l', '-c', '-N', '-H', '-h', '-S'])
    : new Set(['-n', '-i', '-F', '-w', '-x', '-v', '-E', '-G', '-P', '-H', '-h', '-c', '-l', '-L', '-q', '-s']);
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--') { positional.push(...args.slice(i + 1)); break; }
    if (valueOptions.has(arg)) {
      const value = args[i + 1];
      if (!value || value.startsWith('-')) return fail(`PC-GUARD: ${arg} requires a safe explicit value.`);
      if (globOptions.has(arg)) {
        if (!isSafeSourceGlob(value)) return fail('PC-GUARD: search globs must restrict matches to approved source/document extensions.');
        safeGlobFilter = true;
      }
      if (['-t', '--type'].includes(arg)) {
        if (!SAFE_RG_TYPES.has(value.toLowerCase())) return fail('PC-GUARD: ripgrep type filters are limited to approved source/document types.');
        safeTypeFilter = true;
      }
      if (['-m', '--max-count', '-A', '--after-context', '-B', '--before-context', '-C', '--context'].includes(arg) && !/^\d+$/.test(value)) return fail(`PC-GUARD: ${arg} must use a numeric value.`);
      i++;
      continue;
    }
    if (arg.startsWith('--')) {
      const key = arg.includes('=') ? arg.slice(0, arg.indexOf('=')) : arg;
      if (!allowedLong.has(key)) return fail(`PC-GUARD: search option ${key} is not permitted (external preprocessors, pattern files, and config files are blocked).`);
      if (key === '--color' && arg.includes('=') && !['never', 'auto', 'always'].includes(arg.split('=')[1])) return fail('PC-GUARD: invalid --color value.');
      if (key === '--glob-case-insensitive' || key === '--no-ignore-dot' || key === '--no-ignore-vcs' || key === '--no-config' || key === '--line-number' || key === '--ignore-case' || key === '--fixed-strings' || key === '--word-regexp' || key === '--line-regexp' || key === '--invert-match' || key === '--files-with-matches' || key === '--files-without-match' || key === '--count' || key === '--count-matches' || key === '--heading' || key === '--no-heading' || key === '--extended-regexp' || key === '--basic-regexp' || key === '--perl-regexp') {
        if (arg.includes('=')) return fail(`PC-GUARD: ${key} does not accept an inline value.`);
      }
      continue;
    }
    if (arg.startsWith('-') && arg !== '-') {
      if (/^-[A-Za-z]+$/.test(arg)) {
        for (const ch of arg.slice(1)) if (!allowedShort.has(`-${ch}`)) return fail(`PC-GUARD: search short option ${arg} is not permitted.`);
        continue;
      }
      return fail(`PC-GUARD: search option ${arg} is not permitted.`);
    }
    positional.push(arg);
  }
  if (name === 'rg' && env.RIPGREP_CONFIG_PATH) return fail('PC-GUARD: RIPGREP_CONFIG_PATH is set; clear it before using ripgrep so external config cannot add unsafe options.');
  if (positional.length < 2) return fail(`PC-GUARD: ${name} requires a search pattern and at least one explicit repository path.`);
  for (const rawPath of positional.slice(1)) {
    if (/[*?]/.test(rawPath)) return fail('PC-GUARD: wildcard path arguments are blocked for search commands; use a specific source directory.');
    const resolved = resolveRepoPath(rawPath, cwd);
    if (!resolved || !isInsideRoot(resolved)) return fail(`PC-GUARD: search path is outside the repository: ${rawPath}`);
    if (isProtectedSearchRoot(resolved) || /(^|[\\/])node_modules([\\/]|$)/i.test(resolved)) return fail('PC-GUARD: search path targets a protected directory or file.');
    if (!safeGlobFilter && !safeTypeFilter && !isSafeSourceFilePath(rawPath)) return fail('PC-GUARD: recursive search requires an explicit approved source/document extension filter (for example -g *.tsx or -t ts).');
  }
  return allow();
}

// ---- v2.1 additions: pipelines, strict pnpm parsing, recursive-search hardening ----
const PIPE_FILTERS = new Set(['head', 'tail', 'wc', 'sort', 'uniq']);

// Quote-aware split on a single "|". Returns null for "||" or empty stages.
function splitPipeline(raw) {
  const stages = [];
  let current = '';
  let quote = null;
  for (let i = 0; i < raw.length; i++) {
    const ch = raw[i];
    if (quote) {
      current += ch;
      if (ch === quote) quote = null;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
      current += ch;
    } else if (ch === '|') {
      if (raw[i + 1] === '|') return null;
      stages.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  stages.push(current.trim());
  if (stages.some((stage) => !stage) || stages.length > 4) return null;
  return stages;
}

// A later pipeline stage may only trim/count the output of the first stage:
// no file arguments, no output files, no follow mode.
function validateFilterStage(stage) {
  if (/[\r\n;&<>`]/.test(stage) || /\$[({]/.test(stage) || /["']/.test(stage)) return 'filter stages must be plain (no quotes, redirection or substitution)';
  const tokens = stage.split(/\s+/);
  const name = basename(tokens[0]).replace(/\.exe$/i, '');
  if (!PIPE_FILTERS.has(name)) return `"${tokens[0]}" is not an approved pipe filter (head, tail, wc, sort, uniq only)`;
  for (const token of tokens.slice(1)) {
    if (/^-?\d+$/.test(token)) continue;
    if (/^-{1,2}[A-Za-z][A-Za-z-]*$/.test(token)) {
      if (/^-[A-Za-z]*[fF]/.test(token) && ['tail'].includes(name)) return 'tail follow mode is blocked';
      if (/^--(follow|output|files0|random|compress)/i.test(token)) return `option ${token} is blocked in pipe filters`;
      if (name === 'sort' && (/^-[A-Za-z]*[oT]/.test(token) || /^--(output|temporary|batch)/i.test(token))) return 'sort output/temp options are blocked';
      continue;
    }
    return `pipe filter argument "${token}" is not allowed; filters may not take file arguments`;
  }
  return null;
}

const PNPM_SAFE_ACTIONS = new Set(['typecheck', 'test', 'test:run', 'lint', 'build']);
const PNPM_SAFE_TEST_FLAGS = new Set(['--run', '--passwithnotests', '--reporter=verbose', '--reporter=default', '--reporter=dot']);
const TEST_FILE_RE = /^[\w@.\/-]+\.(?:test|spec)\.(?:ts|tsx|js|jsx|mjs|cjs)$/i;

// Strict shape: pnpm --filter @paperclipai/ui [run] <action> [-- ] [safe flags | test files under ui/]
// (The previous check only looked at the LAST token, so "pnpm ... exec <anything> test" passed.)
function validatePnpmUi(tokens) {
  const t = tokens.map((x) => x.trim());
  if (t[1] !== '--filter' || String(t[2] || '').toLowerCase() !== '@paperclipai/ui') {
    return 'only "pnpm --filter @paperclipai/ui <typecheck|test|lint|build>" is approved';
  }
  let i = 3;
  if (String(t[i] || '').toLowerCase() === 'run') i++;
  const action = String(t[i] || '').toLowerCase();
  if (!PNPM_SAFE_ACTIONS.has(action)) return `pnpm action "${t[i] || ''}" is not approved (exec, dlx, run <script> and install are blocked)`;
  const rest = t.slice(i + 1);
  if (!rest.length) return true;
  if (!action.startsWith('test')) return 'extra arguments are only allowed for test runs';
  for (const arg of rest) {
    if (arg === '--') continue;
    if (PNPM_SAFE_TEST_FLAGS.has(arg.toLowerCase())) continue;
    if (TEST_FILE_RE.test(arg) && !arg.includes('..') && !arg.startsWith('/') && !arg.startsWith('-') && !/^[a-z]:/i.test(arg)) continue;
    return `test argument "${arg}" is not allowed (use --run, --reporter=verbose|default|dot, or a relative *.test.ts(x) path under ui/)`;
  }
  return true;
}

function hasRiskyGitEnvironment(env) {
  const dangerous = /^(?:GIT_CONFIG(?:_|$)|GIT_DIR$|GIT_WORK_TREE$|GIT_INDEX_FILE$|GIT_OBJECT_DIRECTORY$|GIT_ALTERNATE_OBJECT_DIRECTORIES$|GIT_EXEC_PATH$|GIT_EXTERNAL_DIFF$|GIT_DIFF_OPTS$|GIT_PAGER$|GIT_SSH(?:_.*)?$|GIT_ASKPASS(?:_.*)?$|SSH_ASKPASS(?:_.*)?$|GIT_TRACE(?:_.*)?$|GIT_CEILING_DIRECTORIES$|GIT_DISCOVERY_ACROSS_FILESYSTEM$|PAGER$|GIT_OPTIONAL_LOCKS$)/i;
  return Object.entries(env || {}).some(([key, value]) => dangerous.test(key) && String(value ?? '').length > 0);
}

function hasRiskyNodeEnvironment(env) {
  // The installed Windows launcher clears these before spawning the pinned node.exe.
  // Direct invocation with preload/module overrides is denied as defense in depth.
  const dangerous = /^(?:NODE_OPTIONS|NODE_PATH|NODE_V8_COVERAGE|NODE_EXTRA_CA_CERTS)$/i;
  return Object.entries(env || {}).some(([key, value]) => dangerous.test(key) && String(value ?? '').trim() !== '');
}

function checkBash(tool, input, cwd, phase, overrides, env, context) {
  const raw = String(input.command ?? input.script ?? input.code ?? '');
  // The PowerShell tool is intentionally restricted to simple literal commands.
  // Reject expression/array/subexpression syntax rather than attempting to parse it.
  if (tool === 'PowerShell' && /[@(){};,]/.test(raw)) return fail('PC-GUARD: PowerShell expressions, arrays, script blocks and multi-value syntax are blocked; use simple literal read commands only.');
  if (raw.includes('|') && !raw.includes('||')) {
    const stages = splitPipeline(raw);
    if (!stages || stages.length < 2) return fail('PC-GUARD: shell chaining, redirection, substitutions, multiline scripts, and shell wrappers are blocked. Run one simple command at a time.');
    for (const filter of stages.slice(1)) {
      const problem = validateFilterStage(filter);
      if (problem) return fail(`PC-GUARD: pipelines may only trim the output of one approved command with head/tail/wc/sort/uniq: ${problem}.`);
    }
    return checkBash(tool, { ...input, command: stages[0] }, cwd, phase, overrides, env, context);
  }
  const tokens = tokenizeCommand(raw);
  if (!tokens) return fail('PC-GUARD: shell chaining, redirection, substitutions, multiline scripts, and shell wrappers are blocked. Run one simple command at a time.');
  const exe = basename(tokens[0]);
  const lower = raw.toLowerCase();
  if (AYoub_IDS.size && [...AYoub_IDS].some((id) => lower.includes(id))) return fail('PC-GUARD: the protected existing Paperclip agent/company identifier was referenced in a shell command.');
  if (/\bayoub\b/i.test(raw) && /(curl|wget|invoke-|docker|psql|sqlite|pnpm|npm|node|python|http|api|post|patch|delete|put)/i.test(raw)) {
    return fail('PC-GUARD: shell commands that interact with the protected agent "ayoub" are blocked.');
  }
  if (/(?:-x\s*['"]?(?:post|put|patch|delete)|--request\s+['"]?(?:post|put|patch|delete)|-method\s+['"]?(?:post|put|patch|delete)|--data(?:-raw|-binary)?\b|\s- body\b|\s-body\b|\.post\s*\(|\.patch\s*\(|\.delete\s*\(|requests\.(?:post|put|patch|delete)\s*\(|httpx\.(?:post|put|patch|delete)\s*\()/i.test(raw)) {
    return fail('PC-GUARD: mutating HTTP/API requests are blocked in every phase.');
  }
  if (/\b(?:gemini_api_key|google_generative_ai_api_key|google_api_key)\b/i.test(raw) && /(?:set-content|add-content|out-file|tee|sed|node|python|write|edit)/i.test(raw)) {
    return fail('PC-GUARD: Gemini credential/provider configuration is Owner-managed.');
  }
  if (/\b(?:rm|del|erase|rmdir|remove-item|set-content|add-content|out-file|new-item|move-item|copy-item|tee|truncate|chmod|chown|sed\s+-i|perl\s+-i|install)\b/i.test(raw) || /\b(?:>>?|2>)/.test(raw)) {
    return fail('PC-GUARD: shell-based file modifications are blocked. Use the approved Edit/Write tools for UI files in a development session.');
  }
  if (/\b(?:docker\s+(?:compose\s+)?(?:up|down|run|rm|stop|kill|restart|exec|start|volume|system)|podman\s+(?:run|exec|stop|rm))\b/i.test(raw)) {
    return fail('PC-GUARD: Docker lifecycle/exec commands are Owner-only and must not touch the live Paperclip instance.');
  }
  if (/\b(?:pnpm|npm|yarn)\s+(?:add|remove|rm|uninstall|update|upgrade|up|install|i)\b/i.test(raw) && !overrides.has('deps')) {
    return fail('PC-GUARD: dependency installation or changes require explicit Owner approval and PC_GUARD_ALLOW=deps in a new session.');
  }

  if (exe === 'git' || exe === 'git.exe') {
    if (hasRiskyGitEnvironment(env)) return fail('PC-GUARD: Git/SSH/pager environment overrides are set; clear GIT_CONFIG*, GIT_EXEC_PATH, GIT_SSH*, ASKPASS, GIT_TRACE*, PAGER and repository redirection variables before Git inspection.');
    if (hasRiskyNodeEnvironment(env)) return fail('PC-GUARD: unsafe Node.js environment overrides are set. Use the installed PowerShell launcher, which clears NODE_OPTIONS, NODE_PATH and related variables before starting the guard.');
    if (hasUnsafeGitExecutionConfigAnywhere(context)) return fail('PC-GUARD: Git configuration contains include, fsmonitor, pager, external diff/textconv, or filter execution settings. Review them manually before any Git inspection.');
    return checkGit(tokens, overrides, context, cwd, phase);
  }
  if (['curl', 'curl.exe', 'irm', 'invoke-restmethod', 'wget', 'wget.exe', 'iwr', 'invoke-webrequest'].includes(exe)) {
    if (phase === 'analysis' && isAllowedOllamaGet(tokens, env, tool)) return allow();
    return fail('PC-GUARD: network access is blocked except GET /api/tags or /api/version on an explicitly configured PC_OLLAMA_URL during Phase 1.');
  }

  const searchResult = checkSearchCommand(exe, tokens, cwd, env);
  if (searchResult) return searchResult;
  const safeRead = new Set([
    'pwd', 'ls', 'dir', 'get-childitem', 'get-location', 'get-content', 'cat', 'type', 'head', 'tail',
    'findstr', 'stat', 'file', 'where.exe', 'wc'
  ]);
  if (safeRead.has(exe)) return tool === 'PowerShell' ? validatePowerShellRead(tokens, cwd) : validateReadCommandPaths(tokens, cwd);
  if (['node', 'node.exe', 'claude', 'claude.exe', 'pnpm', 'pnpm.cmd', 'npm', 'npm.cmd'].includes(exe)) {
    if (tokens.length === 2 && ['--version', '-v', 'version'].includes(tokens[1].toLowerCase())) return allow();
    if (phase === 'development' && overrides.has('deps') && /^(?:pnpm|pnpm\.cmd|npm|npm\.cmd)$/i.test(exe) && /^(?:install|i|add|remove|rm|uninstall)$/i.test(tokens[1] || '')) return allow();
    if (phase === 'development' && exe.startsWith('pnpm')) {
      const verdict = validatePnpmUi(tokens);
      if (verdict === true) return allow();
      return fail(`PC-GUARD: ${verdict}.`);
    }
  }
  if (exe === 'docker' || exe === 'docker.exe') {
    if (phase === 'analysis' && ['ps', 'port'].includes((tokens[1] || '').toLowerCase())) return allow();
    return fail('PC-GUARD: Docker command not on the read-only allowlist.');
  }
  return fail(`PC-GUARD: command/tool "${tokens[0]}" is not on the ${phase} allowlist.`);
}

export function evaluate(input, env = process.env, context = {}) {
  const phase = String(env.PC_GUARD_PHASE || 'analysis').toLowerCase();
  if (!['analysis', 'development'].includes(phase)) return fail('PC-GUARD: invalid PC_GUARD_PHASE. Use analysis or development.');
  const overrides = new Set(String(env.PC_GUARD_ALLOW || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean));
  const tool = String(input?.tool_name || '');
  const ti = input?.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const cwd = input?.cwd || ROOT;

  if (['Read', 'Grep', 'Glob'].includes(tool)) return checkReadPath(tool, ti, cwd);
  if (['Edit', 'Write', 'MultiEdit', 'NotebookEdit'].includes(tool)) return checkWritePath(tool, ti, cwd, phase, overrides);
  if (['Bash', 'PowerShell'].includes(tool)) return checkBash(tool, ti, cwd, phase, overrides, env, context);
  if (tool === 'Agent' || tool === 'Task') {
    const selected = String(ti.subagent_type || ti.agent_type || ti.name || '').toLowerCase();
    return selected === 'pc-explorer'
      ? allow()
      : fail('PC-GUARD: only the read-only pc-explorer subagent is allowed.');
  }
  if (tool === 'Skill') {
    const selected = String(ti.skill || ti.name || '').toLowerCase();
    return ALLOWED_SKILLS.has(selected)
      ? allow()
      : fail('PC-GUARD: only the eight reviewed pc-* project skills are allowed.');
  }
  if (tool === 'ExitPlanMode') {
    return phase === 'development'
      ? allow()
      : fail('PC-GUARD: leaving plan mode is blocked during the read-only analysis phase.');
  }
  if (tool === 'AskUserQuestion' || tool === 'EnterPlanMode') return allow();
  // TodoWrite only edits Claude's own in-memory task list; it touches no files, shell or network.
  if (tool === 'TodoWrite') return allow();
  return fail(`PC-GUARD: tool "${tool || '(unknown)'}" is not approved by the current policy. MCP and other tools are deny-by-default.`);
}

function runSelfTest() {
  const root = ROOT;
  const f = (tool, relPath, extra = {}) => ({ tool_name: tool, cwd: root, tool_input: { file_path: path.join(root, relPath), ...extra } });
  const b = (command) => ({ tool_name: 'Bash', cwd: root, tool_input: { command } });
  const tests = [
    ['default phase is analysis', f('Write', 'ui/src/new.tsx'), {}, true],
    ['analysis: read UI file allowed', f('Read', 'ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['analysis: write UI file blocked', f('Write', 'ui/src/new.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['development: write UI file allowed', f('Write', 'ui/src/new.tsx'), { PC_GUARD_PHASE: 'development' }, false],
    ['development: write server blocked', f('Write', 'server/src/new.ts'), { PC_GUARD_PHASE: 'development' }, true],
    ['development: backend explicit override', f('Write', 'server/src/new.ts'), { PC_GUARD_PHASE: 'development', PC_GUARD_ALLOW: 'backend' }, false],
    ['development: dependency manifest blocked without override', f('Edit', 'package.json'), { PC_GUARD_PHASE: 'development' }, true],
    ['development: dependency manifest allowed with override', f('Edit', 'package.json'), { PC_GUARD_PHASE: 'development', PC_GUARD_ALLOW: 'deps' }, false],
    ['development: UI dependency file also needs override', f('Edit', 'ui/package.json'), { PC_GUARD_PHASE: 'development' }, true],
    ['analysis: write server blocked', f('Write', 'server/src/new.ts'), { PC_GUARD_PHASE: 'analysis', PC_GUARD_ALLOW: 'backend' }, true],
    ['path traversal outside root blocked', { tool_name: 'Write', cwd: root, tool_input: { file_path: path.join(root, 'ui', '..', '..', 'outside.txt') } }, { PC_GUARD_PHASE: 'development' }, true],
    ['read outside repository blocked', { tool_name: 'Read', cwd: root, tool_input: { file_path: path.resolve(root, '..', 'outside.txt') } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['read .env blocked', f('Read', 'server/.env'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['read .env.example allowed', f('Read', '.env.example'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['grep .env glob blocked', { tool_name: 'Grep', cwd: root, tool_input: { path: path.join(root, 'ui'), glob: '**/.env*', pattern: 'KEY' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['Glob path traversal blocked', { tool_name: 'Glob', cwd: root, tool_input: { path: path.join(root, 'ui'), pattern: '../../../outside/**' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['read private key blocked', f('Read', 'keys/id_ed25519'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['write node_modules blocked', f('Write', 'ui/node_modules/x.js'), { PC_GUARD_PHASE: 'development' }, true],
    ['write .git internals blocked', f('Write', '.git/config'), { PC_GUARD_PHASE: 'development' }, true],
    ['Gemini env configuration blocked', f('Write', 'ui/.env.local'), { PC_GUARD_PHASE: 'development' }, true],
    ['ordinary Gemini model identifier allowed in UI source', f('Edit', 'ui/src/config.ts', { new_string: 'google/gemini-3.8-flash' }), { PC_GUARD_PHASE: 'development' }, false],
    ['read ayoub mention allowed', b('rg -g "*.tsx" ayoub ui/src'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['ayoub interaction command blocked', b('curl http://localhost/api/agents/ayoub'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['protected agent id blocked', b('curl http://localhost/api/agents/7c080b2b-6022-4855-a1d3-1b3e6bb37d7a'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git config core.fsmonitor blocks read command', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, true, { gitExecutionConfigText: '[core]\n fsmonitor = C:/tools/watch.exe\n' }],
    ['git config external diff blocks read command', b('git diff --stat'), { PC_GUARD_PHASE: 'analysis' }, true, { gitExecutionConfigText: '[diff]\n external = C:/tools/diff.exe\n' }],
    ['git diff-driver textconv blocks read command', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, true, { gitExecutionConfigText: '[diff \"unsafe\"]\n textconv = C:/tools/textconv.exe\n' }],
    ['git diff-driver command blocks read command', b('git diff --stat'), { PC_GUARD_PHASE: 'analysis' }, true, { gitExecutionConfigText: '[diff \"unsafe\"]\n command = C:/tools/diff.exe\n' }],
    ['git config include blocks read command', b('git log -5 --oneline'), { PC_GUARD_PHASE: 'analysis' }, true, { gitExecutionConfigText: '[include]\n path = C:/temp/extra.gitconfig\n' }],
    ['stock Git LFS process filter is recognized', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, false, { gitExecutionConfigText: '[filter "lfs"]\n process = git-lfs filter-process\n' }],
    ['stock Git for Windows astextplain textconv is recognized', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, false, { gitExecutionConfigText: '[diff \"astextplain\"]\n textconv = astextplain\n' }],
    ['stock Git LFS clean and smudge filters are recognized', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, false, { gitExecutionConfigText: '[filter \"lfs\"]\n clean = git-lfs clean -- %f\n smudge = git-lfs smudge -- %f\n' }],
    ['Owner reported Git for Windows defaults are recognized together', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, false, { gitExecutionConfigText: '[credential]\n helper = manager\n[diff \"astextplain\"]\n textconv = astextplain\n[filter \"lfs\"]\n clean = git-lfs clean -- %f\n smudge = git-lfs smudge -- %f\n process = git-lfs filter-process\n required = true\n' }],
    ['modified Git LFS process command remains blocked', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, true, { gitExecutionConfigText: '[filter \"lfs\"]\n process = powershell -File C:/temp/bad.ps1\n' }],
    ['custom diff textconv remains blocked', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, true, { gitExecutionConfigText: '[diff \"custom\"]\n textconv = C:/tools/convert.exe\n' }],
    ['git status allowed', b('git status --short'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['step-gate complete untracked status allowed', b('git status --short --untracked-files=all'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git --no-pager log allowed', b('git --no-pager log -5 --oneline'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git env override blocks', b('git status --short'), { PC_GUARD_PHASE: 'analysis', GIT_CONFIG_COUNT: '1' }, true],
    ['Node preload environment blocks direct hook execution', b('git status --short'), { PC_GUARD_PHASE: 'analysis', NODE_OPTIONS: '--require C:/temp/preload.js' }, true],
    ['Node module path override blocks direct hook execution', b('git status --short'), { PC_GUARD_PHASE: 'analysis', NODE_PATH: 'C:/temp/modules' }, true],
    ['git rev-parse allowed', b('git rev-parse HEAD'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git log allowed', b('git log -5 --oneline'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git diff summary allowed', b('git diff --name-only pc-ai-os-base'), { PC_GUARD_PHASE: 'development' }, false],
    ['step-gate staged file inventory allowed', b('git diff --cached --name-only'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['step-gate untracked file inventory allowed', b('git ls-files --others --exclude-standard'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git diff stat baseline summary allowed', b('git diff pc-ai-os-base --stat'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git diff unrestricted content blocked', b('git diff'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff tracked env pathspec blocked', b('git diff -- server/.env'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff staged tracked env pathspec blocked', b('git diff --cached -- server/.env'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff Claude local settings pathspec blocked', b('git diff -- .claude/settings.local.json'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff UI source path allowed only with no-textconv', b('git diff --no-textconv -- ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git diff UI content requires no-textconv', b('git diff -- ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff UI env path blocked', b('git diff -- ui/.env.local'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff Git pathspec magic blocked', b('git diff -- :(glob)**/*.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff wildcard UI pathspec blocked', b('git diff -- ui/src/*.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff outside UI source path blocked', b('git diff -- server/src/routes.ts'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff parent traversal path blocked', b('git diff -- ../outside.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff nested parent traversal to server secret blocked', b('git diff -- ui/src/../../server/.env'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff output redirection blocked', b('git diff --output=report.txt'), { PC_GUARD_PHASE: 'development' }, true],
    ['git branch create blocked', b('git branch feature-x'), { PC_GUARD_PHASE: 'development' }, true],
    ['git branch list allowed', b('git branch --all'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git tag create blocked', b('git tag v9.9.9'), { PC_GUARD_PHASE: 'development' }, true],
    ['git tag list allowed', b('git tag --list'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['git -C outside blocked', b('git -C ../outside status'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git fetch blocked', b('git fetch origin'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git merge blocked', b('git merge upstream/main'), { PC_GUARD_PHASE: 'development' }, true],
    ['git commit requires override', b('git commit -m test'), { PC_GUARD_PHASE: 'development' }, true],
    ['git commit remains Owner-terminal-only', b('git commit -m test'), { PC_GUARD_PHASE: 'development', PC_GUARD_ALLOW: 'commit' }, true],
    ['git commit override still blocked in analysis', b('git commit -m test'), { PC_GUARD_PHASE: 'analysis', PC_GUARD_ALLOW: 'commit' }, true],
    ['git ls-remote blocked when safe remote config cannot be verified', b('git ls-remote upstream --tags'), { PC_GUARD_PHASE: 'analysis' }, true, { remoteNames: new Set(['upstream']) }],
    ['git ls-remote unconfigured remote blocked', b('git ls-remote random --tags'), { PC_GUARD_PHASE: 'analysis' }, true, { remoteNames: new Set(['origin']) }],
    ['shell command chain blocked', b('git status; pnpm test'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['shell redirect blocked', b('echo test > ui/a.txt'), { PC_GUARD_PHASE: 'development' }, true],
    ['node arbitrary script blocked', b('node -e "require(\'fs\').writeFileSync(\'x\',\'y\')"'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm install blocked', b('pnpm install'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm UI typecheck allowed in development', b('pnpm --filter @paperclipai/ui typecheck'), { PC_GUARD_PHASE: 'development' }, false],
    ['pnpm UI typecheck blocked in analysis', b('pnpm --filter @paperclipai/ui typecheck'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['docker ps allowed read-only', b('docker ps'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['docker compose up blocked', b('docker compose up -d'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['curl arbitrary GET blocked', b('curl http://example.com'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['known Ollama tags GET allowed', b('curl --disable -fsS http://127.0.0.1:11434/api/tags'), { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, false],
    ['Ollama other endpoint blocked', b('curl -fsS http://127.0.0.1:11434/api/pull'), { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, true],
    ['Ollama custom header blocked', b('curl -H @.env http://127.0.0.1:11434/api/tags'), { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, true],
    ['Ollama request body blocked', b('curl -d secret http://127.0.0.1:11434/api/tags'), { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, true],
    ['Ollama POST method blocked', b('irm -Method POST http://127.0.0.1:11434/api/tags'), { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, true],
    ['Ollama redirect option blocked', b('curl -L http://127.0.0.1:11434/api/tags'), { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, true],
    ['unknown MCP tool blocked', { tool_name: 'mcp__paperclip__resume_agent', cwd: root, tool_input: { agentId: 'x' } }, { PC_GUARD_PHASE: 'development' }, true],
    ['only pc-explorer agent allowed', { tool_name: 'Agent', cwd: root, tool_input: { subagent_type: 'pc-explorer' } }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['other subagent blocked', { tool_name: 'Agent', cwd: root, tool_input: { subagent_type: 'general-purpose' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell read command allowed', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-ChildItem ui' } }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['wildcard Get-Content blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content *' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['recursive grep blocked', b('grep -r GEMINI .'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg hidden search blocked', b('rg --hidden GEMINI ui'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['find execution blocked', b('find . -exec node script.js {} +'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['read Git internal config blocked', f('Read', '.git/config'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['read local Claude settings blocked', f('Read', '.claude/settings.local.json'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['write local Claude settings blocked', f('Write', '.claude/settings.local.json'), { PC_GUARD_PHASE: 'development', PC_GUARD_ALLOW: 'tooling' }, true],
    ['unscoped Grep blocked', { tool_name: 'Grep', cwd: root, tool_input: { pattern: 'router' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['unscoped rg search blocked', b('rg router'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['approved project Skill allowed', { tool_name: 'Skill', cwd: root, tool_input: { skill: 'pc-company-launch-flow' } }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['unapproved Skill blocked', { tool_name: 'Skill', cwd: root, tool_input: { skill: 'dangerous-skill' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['ExitPlanMode blocked in analysis', { tool_name: 'ExitPlanMode', cwd: root, tool_input: {} }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['ExitPlanMode allowed in development', { tool_name: 'ExitPlanMode', cwd: root, tool_input: {} }, { PC_GUARD_PHASE: 'development' }, false],
    ['remote verbose with credentials blocked', b('git remote -v'), { PC_GUARD_PHASE: 'analysis' }, true, { remoteHasCredentials: true }],
    ['remote with credential helper configuration blocked', b('git ls-remote origin --tags'), { PC_GUARD_PHASE: 'analysis' }, true, { remoteNames: new Set(['origin']), remoteConfigText: '[credential]\n helper = manager-core\n[remote "origin"]\n url = https://example.test/repo.git\n' }],
    // ---- v2.1 regression and feature tests ----
    ['TodoWrite allowed', { tool_name: 'TodoWrite', cwd: root, tool_input: { todos: [] } }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['Task tool with pc-explorer allowed', { tool_name: 'Task', cwd: root, tool_input: { subagent_type: 'pc-explorer' } }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['Task tool with other subagent blocked', { tool_name: 'Task', cwd: root, tool_input: { subagent_type: 'general-purpose' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['WebFetch still blocked', { tool_name: 'WebFetch', cwd: root, tool_input: { url: 'https://example.com' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['unknown Task* tool still blocked', { tool_name: 'TaskCreate', cwd: root, tool_input: {} }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['EnterPlanMode allowed in analysis', { tool_name: 'EnterPlanMode', cwd: root, tool_input: {} }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['pipe: rg | head allowed', b('rg -g "*.tsx" useState ui/src | head -20'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['pipe: git diff | tail allowed', b('git diff --stat | tail -5'), { PC_GUARD_PHASE: 'development' }, false],
    ['pipe: cat | head allowed', b('cat ui/package.json | head -30'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['pipe: git log | wc allowed', b('git log --oneline | wc -l'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['pipe: to sh blocked', b('cat ui/package.json | sh'), { PC_GUARD_PHASE: 'development' }, true],
    ['pipe: to tee blocked', b('git log | tee out.txt'), { PC_GUARD_PHASE: 'development' }, true],
    ['pipe: to xargs blocked', b('rg x ui/src | xargs rm'), { PC_GUARD_PHASE: 'development' }, true],
    ['pipe: head with file argument blocked', b('git log | head server/notes.txt'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['pipe: sort -o blocked', b('git log | sort -o out.txt'), { PC_GUARD_PHASE: 'development' }, true],
    ['pipe: tail -f blocked', b('git log | tail -f'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['pipe: || chaining blocked', b('git status || git log'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['pipe: dangerous first stage blocked', b('curl -X POST http://localhost:3100/api/x | head'), { PC_GUARD_PHASE: 'development' }, true],
    ['pipe: first stage reading .env blocked', b('cat server/.env | head'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['pipe: five stages blocked', b('git log | head -50 | tail -40 | sort | uniq | wc -l'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['pipe: quoted pipe in pattern blocked', b('grep "a|b" ui/src/App.tsx | head'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['wc single file allowed', b('wc -l ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['wc wildcard blocked', b('wc -l ui/src/*.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['wc files0-from blocked', b('wc --files0-from=list.txt'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['pnpm typecheck allowed (dev)', b('pnpm --filter @paperclipai/ui typecheck'), { PC_GUARD_PHASE: 'development' }, false],
    ['pnpm test allowed (dev)', b('pnpm --filter @paperclipai/ui test'), { PC_GUARD_PHASE: 'development' }, false],
    ['pnpm run test allowed (dev)', b('pnpm --filter @paperclipai/ui run test'), { PC_GUARD_PHASE: 'development' }, false],
    ['pnpm single test file allowed', b('pnpm --filter @paperclipai/ui test -- src/i18n/direction.test.ts'), { PC_GUARD_PHASE: 'development' }, false],
    ['pnpm test --run with file allowed', b('pnpm --filter @paperclipai/ui test --run src/context/DirectionContext.test.tsx'), { PC_GUARD_PHASE: 'development' }, false],
    ['pnpm test in analysis blocked', b('pnpm --filter @paperclipai/ui test'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['pnpm exec ... test blocked (old bypass)', b('pnpm --filter @paperclipai/ui exec node -e "console.log(1)" test'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm exec curl --json blocked (old bypass)', b('pnpm --filter @paperclipai/ui exec curl --json {} http://localhost:3100/api/agents/x/resume test'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm dlx blocked (old bypass)', b('pnpm --filter @paperclipai/ui dlx some-package build'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm run arbitrary script blocked (old bypass)', b('pnpm --filter @paperclipai/ui run evil test'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm test with traversal path blocked', b('pnpm --filter @paperclipai/ui test -- ../server/x.test.ts'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm test with absolute path blocked', b('pnpm --filter @paperclipai/ui test -- /etc/x.test.ts'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm test with unknown flag blocked', b('pnpm --filter @paperclipai/ui test --coverage'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm typecheck with extra args blocked', b('pnpm --filter @paperclipai/ui typecheck --foo'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm other package blocked', b('pnpm --filter @paperclipai/server test'), { PC_GUARD_PHASE: 'development' }, true],
    ['pnpm install blocked', b('pnpm install'), { PC_GUARD_PHASE: 'development' }, true],
    ['grep -rn . blocked (old bypass)', b('grep -rn KEY .'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['grep -Rin dir blocked (old bypass)', b('grep -Rin KEY server'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['grep -d recurse blocked (old bypass)', b('grep -d recurse KEY .'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['grep --directories=recurse blocked', b('grep --directories=recurse KEY .'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['grep exact file allowed', b('grep -n useState ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['grep regex wildcard in pattern allowed', b('grep -n "use.*State" ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['grep wildcard file argument blocked', b('grep -n KEY ui/src/*'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['findstr /s blocked', b('findstr /s KEY .'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['Select-String -Recurse blocked (old bypass)', b('select-string -Path server/* -Pattern KEY -Recurse'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['Select-String exact file allowed', b('Select-String -Path ui/src/App.tsx -Pattern useState'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['rg glob for .env blocked', b('rg -g "*.env" KEY ui'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg glob for tsx allowed', b('rg -g "*.tsx" useState ui/src'), { PC_GUARD_PHASE: 'analysis' }, false],
    // v2.3 exploit regression tests
    ['rg --pre external program blocked', b('rg --pre powershell -e SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg symlink following short flag -L blocked', b('rg -L -g "*.tsx" SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg symlink following long flag blocked', b('rg --follow -g "*.tsx" SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg combined short flag following symlinks blocked', b('rg -nL -g "*.tsx" SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['grep -L files-without-match remains allowed', b('grep -L SECRET ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['rg --pre-glob blocked', b('rg --pre-glob *.md --pre node SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg -f pattern-file blocked', b('rg -f server/.env SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg --file= pattern-file blocked', b('rg --file=server/.env SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['grep -f pattern-file blocked', b('grep -f server/.env SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['grep --file= pattern-file blocked', b('grep --file=server/.env SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['grep --exclude-from blocked', b('grep --exclude-from=server/.env SECRET ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git --config-env blocked', b('git --config-env=diff.external=PC_DIFF_COMMAND diff'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git -c global config override blocked', b('git -c diff.external=cmd diff'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff --ext-diff blocked', b('git diff --ext-diff'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['git diff --textconv blocked', b('git diff --textconv'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['Grep outside repository blocked', { tool_name: 'Grep', cwd: root, tool_input: { path: path.resolve(root, '..'), pattern: 'secret' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['Grep .git path blocked', { tool_name: 'Grep', cwd: root, tool_input: { path: path.join(root, '.git'), pattern: 'remote' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['Grep secret glob blocked', { tool_name: 'Grep', cwd: root, tool_input: { path: path.join(root, 'ui'), glob: '*.env', pattern: 'KEY' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['Glob broad all-files pattern blocked', { tool_name: 'Glob', cwd: root, tool_input: { path: root, pattern: '**/*' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['Glob source extension pattern allowed', { tool_name: 'Glob', cwd: root, tool_input: { path: root, pattern: '**/*.tsx' } }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['Bash read .git/config blocked', b('cat .git/config'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['Bash read Claude settings blocked', b('cat .claude/settings.local.json'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['Bash read .env wildcard blocked', b('cat server/.env*'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['recursive ls blocked', b('ls -R .'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['tail follow blocked', b('tail -f ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['read .env suffix blocked', f('Read', 'server/secrets.env'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['read credential-named file blocked', f('Read', 'server/api-key.json'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['read lockfile blocked', f('Read', 'pnpm-lock.yaml'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['cat root lockfile blocked', b('cat pnpm-lock.yaml'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell root lockfile blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content pnpm-lock.yaml' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['read minified bundle blocked', f('Read', 'ui/dist/app.min.js'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['read source map blocked', f('Read', 'ui/dist/app.js.map'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg config environment blocks search', b('rg -g "*.tsx" useState ui/src'), { PC_GUARD_PHASE: 'analysis', RIPGREP_CONFIG_PATH: 'C:/temp/rg.conf' }, true],
    ['Select-String exact file allowed', b('Select-String -Path ui/src/App.tsx -Pattern useState'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['Select-String file-list option blocked', b('Select-String -Path ui/src/App.tsx -Pattern x -IncludeFrom server/.env'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['findstr pattern-file option blocked', b('findstr /g:server/.env KEY ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['findstr exact file allowed', b('findstr /n useState ui/src/App.tsx'), { PC_GUARD_PHASE: 'analysis' }, false],
    // v2.4.1 regression coverage: shell expansion, PowerShell providers, Git env, search scope, symlink traversal, and Git diff disclosure
    ['home variable expansion blocked', b('cat "$HOME/private.txt"'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['home tilde expansion blocked', b('cat ~/private.txt'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['Windows environment expansion blocked', b('type %USERPROFILE%\\private.txt'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell Env provider blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content Env:GOOGLE_API_KEY' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell explicit Env provider blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content -Path Env:GOOGLE_API_KEY' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell path-colon parameter blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content -Path:server/.env' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell environment variable expansion blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content "$env:GOOGLE_API_KEY"' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell literal source path allowed', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content -LiteralPath ui/src/App.tsx' } }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['PowerShell wildcard Get-ChildItem blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-ChildItem ui/*' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell Env enumeration blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-ChildItem Env:' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell unapproved reader blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Item .env' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell array expression blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: "Get-Content @('server/.env')" } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell subexpression blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content (Join-Path $HOME private.txt)' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['PowerShell semicolon statement blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'Get-Content ui/src/App.tsx; Get-Content server/.env' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['Git global config env blocked', b('git status --short'), { PC_GUARD_PHASE: 'analysis', GIT_CONFIG_GLOBAL: 'C:/temp/evil.gitconfig' }, true],
    ['Git exec path env blocked', b('git status --short'), { PC_GUARD_PHASE: 'analysis', GIT_EXEC_PATH: 'C:/temp/git-exec' }, true],
    ['Git SSH command env blocked', b('git status --short'), { PC_GUARD_PHASE: 'analysis', GIT_SSH_COMMAND: 'cmd /c whoami' }, true],
    ['Git trace env blocked', b('git status --short'), { PC_GUARD_PHASE: 'analysis', GIT_TRACE_CURL: '1' }, true],
    ['Git alternate object directory env blocked', b('git status --short'), { PC_GUARD_PHASE: 'analysis', GIT_ALTERNATE_OBJECT_DIRECTORIES: 'C:/temp/objects' }, true],
    ['Git askpass env blocked', b('git status --short'), { PC_GUARD_PHASE: 'analysis', GIT_ASKPASS: 'C:/temp/askpass.exe' }, true],
    ['PAGER override blocked', b('git log --oneline'), { PC_GUARD_PHASE: 'analysis', PAGER: 'cmd /c whoami' }, true],
    ['rg recursive without extension filter blocked', b('rg SECRET ui/src'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg json extension search blocked', b('rg -g "*.json" SECRET .'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['rg safe source extension filter allowed', b('rg -g "*.tsx" useState ui/src'), { PC_GUARD_PHASE: 'analysis' }, false],
    ['rg search of Claude config directory blocked', b('rg -g "*.md" token .claude'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['Grep root recursive search without safe glob blocked', { tool_name: 'Grep', cwd: root, tool_input: { path: '.', pattern: 'token' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['Grep root recursive source glob allowed', { tool_name: 'Grep', cwd: root, tool_input: { path: '.', glob: '**/*.tsx', pattern: 'useState' } }, { PC_GUARD_PHASE: 'analysis' }, false],
    ['Glob brace pattern including sensitive name blocked', { tool_name: 'Glob', cwd: root, tool_input: { path: '.', pattern: '**/{.env,*.tsx}' } }, { PC_GUARD_PHASE: 'analysis' }, true],
    ['Select-String non-source file blocked', b('Select-String -Path server/config.json -Pattern token'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['findstr non-source file blocked', b('findstr token server/config.json'), { PC_GUARD_PHASE: 'analysis' }, true],
    ['Ollama curl config option must be first', b('curl http://127.0.0.1:11434/api/tags --disable -fsS'), { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, true],
    ['Ollama curl missing disable blocked', b('curl -fsS http://127.0.0.1:11434/api/tags'), { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, true],
    ['PowerShell curl alias blocked', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'curl --disable -fsS http://127.0.0.1:11434/api/tags' } }, { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, true],
    ['PowerShell curl.exe explicit safe GET allowed', { tool_name: 'PowerShell', cwd: root, tool_input: { command: 'curl.exe --disable -fsS http://127.0.0.1:11434/api/tags' } }, { PC_GUARD_PHASE: 'analysis', PC_OLLAMA_URL: 'http://127.0.0.1:11434' }, false],
    ['ordinary Gemini UI label allowed', f('Edit', 'ui/src/pages/Providers.tsx', { new_string: 'Gemini google/gemini-3.8-flash' }), { PC_GUARD_PHASE: 'development' }, false],
    ['Gemini credential assignment blocked', f('Edit', 'ui/src/pages/Providers.tsx', { new_string: 'GOOGLE_API_KEY=secret-value' }), { PC_GUARD_PHASE: 'development' }, true],
  ];
  let failures = 0;
  for (const [label, input, env, expectedBlocked, context] of tests) {
    const result = evaluate(input, env, context || {});
    const blocked = result.decision === 'block';
    const passed = blocked === expectedBlocked;
    if (!passed) failures++;
    console.log(`${passed ? 'PASS' : 'FAIL'} ${label}${passed ? '' : ` (expected ${expectedBlocked ? 'BLOCK' : 'ALLOW'}, got ${result.decision}: ${result.reason})`}`);
  }
  console.log(failures ? `${failures} FAILED` : `ALL ${tests.length} PASSED (phase default: analysis; root: ${ROOT})`);
  process.exit(failures ? 1 : 0);
}

function isMainModule() {
  const entry = process.argv[1];
  if (!entry) return false;
  const invokedPath = path.resolve(entry);
  const modulePath = path.resolve(fileURLToPath(import.meta.url));
  return process.platform === 'win32'
    ? invokedPath.toLowerCase() === modulePath.toLowerCase()
    : invokedPath === modulePath;
}

// Keep evaluate() importable for isolated regression tests. Only a direct
// `node pc-guard.mjs` invocation may consume stdin or exit the host process.
if (isMainModule()) {
  if (process.argv.includes('--selftest')) {
    runSelfTest();
  } else {
    try {
      const stdin = readFileSync(0, 'utf8');
      const input = JSON.parse(stdin || '{}');
      const result = evaluate(input);
      if (result.decision === 'block') {
        process.stderr.write(`pc-guard BLOCKED: ${result.reason}\n`);
        process.exit(2);
      }
      process.exit(0);
    } catch (error) {
      process.stderr.write(`pc-guard internal error (fail-closed): ${error?.message || 'unknown error'}\n`);
      process.exit(2);
    }
  }
}
