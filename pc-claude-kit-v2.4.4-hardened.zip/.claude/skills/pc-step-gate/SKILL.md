---
name: pc-step-gate
description: Mandatory acceptance gate before reporting any project step as complete, before saying tests passed, or when the Owner asks for a status/review. Checks the exact approved scope, tracked/staged/untracked files, secrets, protected agent/Gemini state, tests, and manual UI review.
---

# Step gate — no claim of completion without evidence

Run this after each Owner-approved development step. Do not run it to justify changes during Phase 1; Phase 1 permits no changes.

## 1. Confirm the approved scope
- Identify the exact baseline tag/commit confirmed by the Owner (the current expected tag is `pc-ai-os-base`; verify that it exists before using it).
- Run `git status --short --untracked-files=all`.
- Run `git diff --name-only pc-ai-os-base` and `git diff --cached --name-only`.
- Include every untracked file from `git status`; `git diff` does not report untracked files.
- Review the full file list. Default allowed path is `ui/` only. Any `.claude/`, root, backend, schema, migration, adapter, lockfile, or Docker change requires the corresponding explicit Owner approval before it can remain.
- Do not automatically revert anything. Report out-of-scope paths and stop for the Owner's decision.

## 2. Dependencies and generated files
- Check changes to `ui/package.json`, root package manifests, and lockfiles. Any dependency or lockfile change requires explicit approval.
- Confirm no build artifacts, temporary probes, debug dumps, generated screenshots, or accidental files remain.

## 3. Secrets and protected state
- Inspect changed files for credential-like strings without printing the matched value. Report only the file and line, with the value redacted.
- Confirm no `.env`, private key, auth store, or credential file was read/changed/added.
- Confirm no request, code path, setting, or command was added that starts/resumes/invokes/reconfigures the protected `ayoub` agent or changes its company/lifecycle.
- Confirm no existing Gemini provider, key, endpoint, auth store, or model configuration was modified.
- If a check could reveal a secret, do not paste its raw output. Redact it first.

## 4. Quality checks
- Read the package scripts before selecting commands. Never guess the package manager or test command.
- Run the narrowest relevant typecheck, unit test, and lint/build command that proves the step. Show exact command and result summary.
- A skipped, blocked, timed-out, missing, or broken test is `Not run` / `Cannot be determined`, not Passed.
- Never weaken/delete a test or suppress an error to make the suite pass.

## 5. Behavior and regressions
- List the existing pages/routes actually rechecked.
- Confirm loading, empty, error, and permission-denied states where relevant.
- For Live Work, verify real-time, historical, inferred, and unavailable data classes separately. Do not claim collaboration without evidence linking agents to shared work/events.
- For i18n/RTL and dark/light, state what automated tests prove and what still needs a human visual check. Test narrow viewport behavior where the UI changed.

## Report template
| Check | Result | Evidence |
|---|---|---|

Then provide:
- files changed (include tracked, staged, and untracked; one line each);
- `git diff --stat` and staged diff stat if relevant;
- tests actually run, tests not run, and exact failures;
- secret/protected-agent/Gemini self-check (no secret values);
- manual checks still required;
- open questions.

STOP after the report and wait for the Owner. Suggest starting the next approved step in a fresh session (`/clear` or restart) so phase/override environment variables are not accidentally carried forward.
