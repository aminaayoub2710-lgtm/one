---
name: pc-api-map
description: Candidate map of Paperclip UI files, API routes, and known gaps from earlier repository analysis. Use before exploring work on Live Work, company creation, employees, tasks, approvals, costs, adapters, or models. Every entry is a hint that must be verified in the current checkout.
---

# Paperclip API map — UNVERIFIED HINTS ONLY

This map was compiled from earlier analysis and may contain stale paths, changed APIs, or incorrect conclusions. It is not an authority and is not evidence. Before relying on any item, search the current repository and read the exact implementation/schema/tests. If it is wrong, report the correction to the Owner. Do not invent a replacement route.

## Candidate frontend paths (verify before use)
- `ui/src/App.tsx`: earlier report found a large route table and feature flags.
- `ui/src/context/LiveUpdatesProvider.tsx`: earlier report identified websocket/react-query update handling.
- `ui/src/pages/DashboardLive.tsx`, `OrgChart.tsx`, `Costs.tsx`, `Approvals.tsx`, `AgentDetail.tsx`, `Companies.tsx`, `NewAgentSetup.tsx`.
- `ui/src/components/OnboardingWizard.tsx`: earlier report suggested it creates an agent rather than a complete company; verify its actual submit path.
- `ui/src/components/AgentConfigForm.tsx`: earlier report suggested it contains adapter/model configuration.
- Candidate i18n/theme/RTL paths previously reported: `ui/src/i18n/locales.ts`, `ui/src/context/ThemeContext.tsx`, `ui/src/i18n/direction.ts`, `ui/src/context/DirectionContext.tsx`, `ui/src/lib/rtl.css`. Do not assume these files still exist or are the current source of truth.

## Candidate API routes (verify route registration, schemas, service and tests)
- Live: `/api/companies/:companyId/events/ws`, `/api/companies/:id/live-runs`, `/api/heartbeat-runs/:id/events?afterSeq=`, company activity/audit routes.
- Org/employee: company org route, agent configuration/runtime-state routes, and company adapter model routes.
- Company lifecycle: `POST /api/companies`, company update route, `POST /api/companies/:id/agent-hires`, approval routes, and agent pause/resume routes.
- Costs: candidate by-agent, by-agent-model, by-provider, by-biller, summary, finance-summary, window-spend, and quota-window routes.
- Tasks/projects: candidate `/api/projects` and `/api/issues` routes.
- Adapters: candidate adapter listing and adapter test-environment routes.

## Candidate gaps reported previously (not confirmed)
- No dedicated safe company proposal/launch API.
- No server-side pre-launch execution barrier.
- No agent-to-agent chat API.
- No provider/Ollama health endpoint.
- No provider-reported costs for some local inference paths.
- Adapter schemas may not allow per-employee custom base URL or credentials.

## Verification method
For each candidate, search route registration, request/response schemas, service implementation, authorization checks, worker/heartbeat call sites, and tests. A frontend API client alone does not prove server support. A UI gate alone does not prove server-side enforcement.

For each feature, classify it as:
- **Confirmed:** source and tests show the behavior.
- **Partially supported:** some required parts exist; list exact gaps.
- **Requires implementation:** no sufficient existing implementation.
- **Cannot be determined from the current codebase:** runtime-only behavior or evidence is missing.

Phase 1 is read-only. Never call mutating endpoints, start an app, run migrations, or start/resume/invoke an agent to test a hypothesis.
