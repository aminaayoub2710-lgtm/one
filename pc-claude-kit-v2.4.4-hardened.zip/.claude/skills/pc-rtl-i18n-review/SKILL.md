---
name: pc-rtl-i18n-review
description: Review Arabic/English localization, directionality, dark/light themes, accessibility, and responsive behavior for every new or changed UI screen. Verify the current repository architecture before making changes.
---

# Localization and responsive UI review

First inspect the current UI package and identify the actual i18n library, locale source of truth, direction provider, theme implementation, CSS approach, and existing RTL tests. Earlier path names in `pc-api-map` are only hints. Do not create a second language/direction state or replace the project's design system without evidence.

## Arabic and RTL
- All user-visible strings must use the existing localization mechanism. Add translations to every supported locale required by the project; for this product, Arabic and English are required unless the Owner changes scope.
- Direction should follow the existing language/direction source of truth. Do not set `dir` independently in random components.
- Prefer logical CSS properties: `margin-inline`, `padding-inline`, `inset-inline`, `text-align: start/end`, and logical border/radius utilities supported by the actual CSS stack.
- Avoid left/right spacing assumptions and `flex-row-reverse` hacks unless the existing layout specifically requires them.
- Mirror direction-bearing icons (back/forward, directional chevrons, arrows) only. Do not mirror logos, checkmarks, media controls, or chart axes by default.
- Keep IDs, URLs, commands, file paths, code, and model names in LTR isolation inside Arabic content.
- Use the project's existing pluralization rules; do not hand-code singular/plural conditionals for Arabic.
- Format dates, numbers, currency, and percentages with locale-aware APIs and respect the Owner's digit-format preference if specified.

## Themes and accessibility
- Use existing theme tokens and components. Avoid new hard-coded colors and duplicated theme state.
- Preserve visible focus, keyboard navigation, semantic labels, contrast, and screen-reader names.
- Check dialogs, menus, dropdowns, toasts, tables, charts, overflow, truncation, and scrollbars in both directions.

## Responsive review
- Follow current breakpoints and layout conventions after verifying them.
- Test desktop, tablet/narrow, and mobile-sized layouts for clipping, overflow, unusable tables, and inaccessible navigation.

## Evidence
- Unit tests can prove language/direction state and localization wiring, not visual correctness.
- Report automated results separately from Owner-required manual visual checks in Arabic and English, RTL and LTR, dark and light, and narrow viewport sizes.
