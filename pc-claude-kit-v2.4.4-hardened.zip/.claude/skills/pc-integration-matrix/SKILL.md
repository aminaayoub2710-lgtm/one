---
name: pc-integration-matrix
description: Build and maintain an evidence-based integration, capability, credential, and per-employee permission matrix for GitHub, browser, files, terminal, email, databases, APIs, Ollama, and cloud model providers.
---

# Integration and tool-permission matrix

Do not treat an integration name in a settings page as proof that the capability works. Inspect the connector/adapter registry, tool schemas, authorization paths, credential storage, runtime dispatch, audit events, and tests. Mark each capability as native, partial, external integration required, or unavailable.

## Required matrix fields
For each integration, report:
1. What it enables (read, write, execute, send, delete, admin).
2. Which AI roles genuinely need it and why.
3. How access is granted (per employee, per company, per user, global server config, or external OAuth).
4. Whether scopes can be least-privilege and individually revoked.
5. Where credentials/tokens are stored and whether they are encrypted/redacted.
6. Whether use is auditable (actor, tool, target, timestamp, outcome).
7. Whether execution is sandboxed and what host/container/network it can reach.
8. Whether the capability exists in this checkout or requires implementation.

## Integration-specific review

| Integration | Typical capability to investigate | Required safety boundary |
|---|---|---|
| GitHub | Read repositories, issues and PRs; create branches/commits/PRs if approved | Per-company/per-employee repository scope, minimal OAuth scopes, explicit approval for writes/merges/releases |
| Browser | Search and interact with public or authenticated sites | Isolated browser profile, no Owner personal cookies by default, domain allowlist and approval for purchases/submissions/destructive actions |
| Files | Read, create, edit and export company documents/assets | Company workspace allowlist; no unrestricted host filesystem or secret-store access |
| Terminal | Run build/test/deploy/automation commands | Container/sandbox, command policy, filesystem/network restrictions, resource limits, audited command and output |
| Email | Read inbox, draft, send and organize mail | Draft-first; explicit send approval; mailbox-scoped OAuth; redact sensitive content |
| Databases | Query or modify business data | Per-role DB identity, least privilege, read-only by default, tenant isolation, audit log and approval for destructive writes |
| APIs | Call external services and internal endpoints | Per-integration secret storage, endpoint allowlist, HTTP method policy, rate limits, logging without secrets |
| Ollama | Run local/remote models and list installed models | Network isolation; Ollama API has no built-in authentication; health/model discovery is read-only; never expose raw unauthenticated API |
| Cloud model providers | Inference through Claude/Gemini/OpenAI/etc. | Server-side credential handling, per-provider budgets/quotas, key rotation, per-employee model selection only where schema supports it |

## Per-employee access policy
- Define tools at the role/employee level where supported. Do not assume all employees inherit the same permissions.
- Start with no tools, then grant the minimum capabilities needed by that role.
- Separate read from write and execution privileges.
- Require explicit Owner approval for email sending, repository writes/merges/releases, production deployments, database mutations, purchases, public posts, permission changes, and destructive actions.
- Record tool invocation, target, actor, approval reference, result, and failure without logging credentials or private prompt content unnecessarily.
- Provide a visible way for the Owner to revoke tools/credentials and pause an employee. Verify server-side behavior, not just hidden buttons.

## Output
Deliver a matrix with columns: Integration | Capability | AI roles | Access scope | Credential handling | Auditability | Sandbox/network boundary | Status | Evidence/gap. Use Confirmed, Partially supported, Requires implementation, or Cannot be determined from the current codebase. Keep all UNKNOWN deployment facts as UNKNOWN until the Owner answers. Never test write-capable integrations in Phase 1.
