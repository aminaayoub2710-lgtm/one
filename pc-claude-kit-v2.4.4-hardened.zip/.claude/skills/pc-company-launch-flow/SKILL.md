---
name: pc-company-launch-flow
description: Safety specification for the AI-only company lifecycle: idea, proposal, Owner review, structure approval, non-running employee creation, and a separate explicit launch. Use for company creation, CEO planning, hires, approvals, first tasks, pause/resume, and anything that could start an employee.
---

# Mandatory lifecycle: propose -> review -> approve -> create paused -> launch

The company contains AI employees only. The Owner is the only human and is not an employee. No AI employee may execute any task before the Owner explicitly launches the company.

## 1. Proposal generation (no Paperclip employee may run)
- First inspect the code for a non-agent planning service or a safe direct model-call mechanism that does not create, activate, schedule, or invoke a Paperclip agent/heartbeat.
- A CEO is an employee. **Never create or run a CEO to generate the pre-launch proposal.** There is no CEO exception.
- If no safe non-agent planning mechanism exists, mark proposal generation `Requires implementation` or offer an Owner-editable manual draft. Explain the missing API/service and request backend approval if required. Do not fake a proposal or call an employee to produce it.

## 2. Owner review and structure approval
The proposal may include company purpose, departments, roles, reporting lines, CEO, employee responsibilities, model/provider choices, tools, permission boundaries, budgets, risks, and expected costs. The Owner must be able to edit the proposal and explicitly approve the proposed structure. This approval is **not** permission to launch.

## 3. Create employees in a verified non-running state
Before implementing, inspect the real schemas, routes, lifecycle service, heartbeat scheduler, dispatch/worker paths, run endpoints, hire-approval flow, and startup behavior.
- Confirm whether the company can be created as `draft`/`paused` or with an enforced launch hold.
- Confirm whether each new employee can remain paused/inactive with no scheduled heartbeat, no queued run, and no manual/API execution before launch.
- Confirm whether direct API calls can bypass the gate.
- Do not assume a UI disabled button, a hidden route, a `setup` hold, or a `paused` company flag is sufficient. Trace the server-side enforcement.
- Do not create an active company and plan to pause it afterward; that creates a race window in which dispatch or a heartbeat could start an employee.
- If safe non-running creation and server-side enforcement are not confirmed, stop. Mark `Requires implementation`, describe the exact backend changes, and wait for the Owner's approval under the backend-change rule.
- Do not test this against the live instance or any instance containing the protected `ayoub` agent. Only use an isolated throwaway environment after the Owner explicitly authorizes starting it.

## 4. Launch is a separate, explicit Owner action
Before launch, show a final summary: organization, employee count, managers, models/providers, tools/permissions, budget and cost estimates, and any unavailable information. Require a distinct Owner confirmation for `Launch Company`.
- Prefer a dedicated server-side launch operation that verifies the Owner's authority and atomically releases the launch hold / schedules execution.
- If no such operation exists, do not simulate security with a frontend-only button. Document the server-side gap and request approval for backend work.
- Structure approval, hire approval, and launch approval are separate decisions. Do not merge them into one confirmation.

## 5. After launch
Only after server-side launch succeeds may the system enable heartbeats/dispatch, assign operational tasks, and allow the CEO and other employees to work. Show actual run/event state and surface launch failures without pretending the company started.

## Evidence checklist
For every lifecycle claim, provide source references for:
- company creation defaults and schema;
- employee/hire creation and approval behavior;
- paused/draft/setup-hold semantics;
- heartbeat scheduling and cancellation;
- worker dispatch and manual run entry points;
- server-side authorization and launch transition;
- tests covering pre-launch blocking and post-launch execution.

Use labels: Confirmed | Partially supported | Requires implementation | Cannot be determined from the current codebase. Do not perform lifecycle experiments in Phase 1. Do not start or modify `ayoub` or change any Gemini configuration.
