---
name: pc-upstream-merge
description: Safe process for reviewing and selectively integrating upstream Paperclip changes into the pinned AI-OS fork. Use when the Owner asks to inspect versions, plan an update, handle conflicts, or change the baseline.
---

# Selective upstream maintenance

The Owner has chosen a pinned baseline with periodic, selective upstream integration. Do not update automatically. Do not fetch/pull/merge/rebase/push/checkout/reset or mutate Git state from Claude Code; the guard blocks those operations. The Owner performs approved network and Git mutations in their own terminal.

## Before considering an update (read-only)
1. Verify current commit, branch, tags, and configured remotes using read-only Git commands.
2. Verify the baseline tag/commit (expected local label: `pc-ai-os-base`) actually exists. Do not assume the label is present or points to the intended commit.
3. Identify which configured remote is the real upstream. Do not assume `origin` is upstream or that it is hosted on GitHub.
4. If the Owner explicitly authorizes upstream version inspection, use `git ls-remote` only against an already configured remote name, and only when its URL is a verified HTTP(S) URL without embedded credentials, query strings, URL rewrite rules, or custom helper commands. If the guard cannot verify this, ask the Owner to inspect the remote manually. Do not add a remote or fetch objects during analysis.
5. Distinguish local tags/commits from remote refs. A remote tag visible through `ls-remote` is not present locally until the Owner fetches it.

## Owner-run integration procedure (only after separate approval)
1. Ensure the working tree is clean, including untracked files.
2. Create an Owner-managed safety tag/backup and a dedicated trial branch.
3. Fetch the selected upstream tag and merge it into the trial branch manually. Never use `-X ours` or `-X theirs`.
4. Resolve conflicts file-by-file. Inspect all original files changed by the AI-OS work and identify API/schema behavior changes that may invalidate `pc-api-map`.
5. Run `pc-step-gate`, update evidence maps, and test the affected UI, RTL, themes, real-time events, and launch-safety behavior.
6. Only after the Owner reviews the trial and explicitly approves should the main development branch move forward.
7. Retain the old baseline tag and create a new, clearly named baseline tag only after approval.

## Merge-friendly implementation rules
- Prefer new modules/files over broad rewrites of original Paperclip files.
- Keep original-file edits small and clearly scoped.
- Do not hide a real upstream conflict by deleting existing Paperclip functionality.
- Never re-baseline just because a newer tag exists. Evaluate security fixes, API compatibility, migration requirements, test coverage, and merge cost first.
