---
name: pc-provider-setup
description: Investigate per-employee models and provider connectivity for Ollama, LM Studio, Gemini, Claude, OpenAI and compatible endpoints. Use for adapter configuration, model selection, Docker networking, provider health, credentials, tool-calling and inference costs.
---

# Providers and per-employee model configuration

Treat provider support as a codebase question, not an assumption. Inspect the built-in adapter registry, adapter schemas, runtime configuration validation, UI configuration forms, server-side environment loading, and tests. Classify each field independently: provider, model, endpoint/base URL, variant, credentials, and permitted tools.

## Ollama facts and security
- Ollama normally listens on `127.0.0.1:11434` by default. The bind address can be changed with `OLLAMA_HOST`.
- The standard Ollama API does not provide built-in authentication. Anyone who can reach an exposed API may be able to use the models and management endpoints. Do not expose it to an untrusted LAN or the public internet. Use network isolation, firewall rules, VPN, or an authenticated reverse proxy if remote access is truly needed.
- Do not set `OLLAMA_HOST=0.0.0.0` as a casual fix. First identify which process/container needs access and restrict network reachability.
- Model discovery can use the read-only `GET /api/tags`; version discovery can use `GET /api/version`. Do not use pull, delete, create, generate, or other mutating/runtime endpoints during Phase 1.

## Deployment topologies — do not guess which one the Owner uses
1. **Paperclip on Windows host, Ollama on Windows host:** a loopback URL may work if both processes share the same host/network namespace. Verify the actual listening address and port.
2. **Paperclip in Docker, Ollama on Windows host:** `localhost` inside the Paperclip container is the container itself, not Windows. `host.docker.internal` is commonly used to reach the host from Docker Desktop, but it must be verified in the actual container/network. Ollama must listen on an address reachable from that container; a loopback-only bind may reject the connection. Do not change the bind address without an explicit security plan.
3. **Paperclip and Ollama in the same Compose/network:** use the Ollama service name and container port on a private Docker network. Do not publish the Ollama port to every host interface unless required and protected.
4. **Remote Ollama server:** use a private routed network/VPN or authenticated TLS reverse proxy, strict firewall/IP allowlists, and credentials at the proxy. Never assume the remote endpoint is safe because it is on a LAN.

## Owner deployment facts
Treat these as unknown until confirmed by the Owner or exact configuration evidence:
- Where Ollama runs: Windows host / Docker / remote.
- Ollama address and port.
- Current `OLLAMA_HOST` bind setting.
- Docker network and host reachability.
- Whether a reverse proxy/authentication layer exists.

Do not ask for or print API keys. Do not read `.env` or auth files. Redact credential values.

## Adapter and OpenCode notes
- `opencode_local` is an adapter/runtime path, not proof that Paperclip has native first-class Ollama health or model-management support.
- Verify whether Ollama is a native built-in adapter in this checkout, a provider exposed through OpenCode, or an OpenAI-compatible endpoint. Do not conflate those choices.
- If using OpenCode provider configuration, verify its exact schema and how provider environment variables reach the Paperclip process/container. Do not assume a Windows user's authentication/config is visible inside Docker.
- Verify the model ID against the server's real list. Never change the existing Gemini provider/configuration without explicit Owner instruction.

## Tool calling and model suitability
A text response is not proof that an agent can use tools. Small local models may fail to select tools, emit malformed arguments, or ignore tool instructions. When the Owner authorizes runtime testing, use an isolated throwaway employee/environment and a harmless task that requires one specific tool. Record the actual tool-call event/result. Do not run this test in Phase 1 or against `ayoub`.

## Provider health UI
- Do not invent a provider-health endpoint or a green "connected" status.
- If the backend has no health/model-discovery API, label the feature `Requires implementation` and propose a read-only server-side health endpoint after approval.
- Only show model lists and status from real responses; include last-checked time and connection errors.

## Cost treatment
- Separate provider-reported charges, token-derived estimates, local inference, and unavailable data.
- Do not assume every adapter reports input/output tokens or cost.
- Never display `0` for unknown cost. Local inference still has hardware/electricity costs; if unmeasured, label monetary cost unavailable rather than free.
