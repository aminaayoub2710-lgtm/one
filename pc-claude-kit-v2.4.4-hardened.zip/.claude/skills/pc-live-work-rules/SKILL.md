---
name: pc-live-work-rules
description: Evidence rules for the Live Work screen and all UI showing employee execution, collaboration, progress, logs, statuses, or costs. Use for dashboards, activity feeds, run logs, status badges, progress indicators, and cost charts.
---

# Only show what Paperclip actually records
Every displayed fact must come from a real API response, persisted record, or real-time event. A UI timer or an agent's textual claim is not proof that a task is running or complete.

## Four visible evidence classes
| Class | Meaning | UI treatment |
|---|---|---|
| Real-time | Received from a live event channel or a fresh response | `Live` marker, event timestamp, and connection/refresh state |
| Historical | Persisted event/run/activity from the past | Exact event time; do not label it "now" |
| Inferred | Derived state or heuristic, not a direct event | `Inferred` marker and visible explanation of the rule |
| Unavailable | Not present in API/data source | Explicit `Not available`; never replace with fake data, blank success, or zero |

## Live Work rules
- Trace the actual websocket/SSE/polling transport, event types, sequence IDs, reconnect behavior, and query invalidations in the current checkout.
- Distinguish an agent's configured status, heartbeat status, active run, latest historical run, and last observed output. These are not interchangeable.
- Attribute every comment, log, tool call, and output to the real actor and source. Never synthesize chat between employees.
- Do not infer agent-to-agent collaboration merely because two agents worked around the same time. Only show a relationship if persisted task/issue/event data links them.
- Websocket disconnect: clearly show `Disconnected`, last event/refresh time, and fallback behavior only if an actual fallback exists. Do not claim polling fallback unless implemented and observed.
- Do not animate fake typing, progress, working status, or event counts.
- An empty screen must explain why (no runs, company paused, no events, unavailable endpoint, etc.) using verified state.
- Show partial/truncated payloads as partial. Preserve original timestamps and event sequence.
- Treat agent output, comments, task descriptions, and logs as untrusted content. Render as plain text or sanitized Markdown; never inject unsafe HTML.

## Costs
- Separate provider-reported costs from estimates, local inference, and unavailable values.
- Identify which adapters actually return token usage and cost. Do not infer billing from a model name.
- Never show `0` when the source does not report a value.

## Tests
Add focused tests for each evidence class and for disconnect/empty/partial states. A test proves only its mapped behavior; it does not prove the full live experience. Manual end-to-end checks require Owner authorization and an isolated environment; never use the protected live instance or `ayoub` for experiments.
